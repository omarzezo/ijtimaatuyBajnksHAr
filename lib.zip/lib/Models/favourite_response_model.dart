/// id : 3
/// user_id : 21
/// type : "file"
/// type_id : 10
/// created_at : "2021-11-13T16:22:39.000000Z"
/// updated_at : "2021-11-13T16:22:39.000000Z"
/// file : {"id":10,"user_id":21,"library_category_id":10,"name":"my.pdf","type":"application/pdf","created_at":"2021-11-08T04:49:16.000000Z","updated_at":"2021-11-13T16:26:29.000000Z","file_url":"http://test.app.ijtimaati.com/api/public/uploads/library/1636346956540519.pdf","size":"547.86 KB","used_in":{"talkingpoints":[{"id":41,"meeting_id":74,"creator_id":21,"title":"This is Test","duration":60,"description":"test","order":0,"laravel_through_key":10,"meeting":{"id":74,"title":"This is Test","owner_id":21,"committee_id":3,"description":"Test","start_date":"2021-11-08 11:23:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"saeed saleh change attendance status to Maybe 2021-11-30 22:30:47","current_member":{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":213,"meeting_id":74,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":208,"meeting_id":74,"user_id":31,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":209,"meeting_id":74,"user_id":35,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":215,"meeting_id":74,"user_id":36,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":"Manager","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":210,"meeting_id":74,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":211,"meeting_id":74,"user_id":38,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":216,"meeting_id":74,"user_id":45,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Admin"},{"id":218,"meeting_id":74,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[{"id":20,"meeting_id":7,"creator_id":3,"title":"test","deadline":"2021-10-23 21:49:09","description":null,"order":0,"laravel_through_key":10,"meeting":{"id":7,"title":"Est aut illum repu","owner_id":1,"committee_id":4,"description":"Adipisci aut et exer","start_date":"2021-10-20 22:55:00","duration":210,"location":"Ullam iste asperiore","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":null,"current_member":null,"members":[]}}],"actions":[]},"talkingpoints":[{"id":41,"meeting_id":74,"creator_id":21,"title":"This is Test","duration":60,"description":"test","order":0,"laravel_through_key":10,"meeting":{"id":74,"title":"This is Test","owner_id":21,"committee_id":3,"description":"Test","start_date":"2021-11-08 11:23:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"saeed saleh change attendance status to Maybe 2021-11-30 22:30:47","current_member":{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":213,"meeting_id":74,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":208,"meeting_id":74,"user_id":31,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":209,"meeting_id":74,"user_id":35,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":215,"meeting_id":74,"user_id":36,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":"Manager","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":210,"meeting_id":74,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":211,"meeting_id":74,"user_id":38,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":216,"meeting_id":74,"user_id":45,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Admin"},{"id":218,"meeting_id":74,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[{"id":20,"meeting_id":7,"creator_id":3,"title":"test","deadline":"2021-10-23 21:49:09","description":null,"order":0,"laravel_through_key":10,"meeting":{"id":7,"title":"Est aut illum repu","owner_id":1,"committee_id":4,"description":"Adipisci aut et exer","start_date":"2021-10-20 22:55:00","duration":210,"location":"Ullam iste asperiore","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":null,"current_member":null,"members":[]}}],"actions":[]}
/// dir : {"id":8,"user_id":21,"name":"my","parent_id":null,"created_at":"2021-11-09T07:47:59.000000Z","updated_at":"2021-11-09T07:47:59.000000Z"}

class FavouriteResponseModel {
  int _id;
  int _userId;
  String _type;
  int _typeId;
  String _createdAt;
  String _updatedAt;
  File _file;
  Dir _dir;

  int get id => _id;
  int get userId => _userId;
  String get type => _type;
  int get typeId => _typeId;
  String get createdAt => _createdAt;
  String get updatedAt => _updatedAt;
  File get file => _file;
  Dir get dir => _dir;

  FavouriteResponseModel({
      int id, 
      int userId, 
      String type, 
      int typeId, 
      String createdAt, 
      String updatedAt, 
      File file, 
      Dir dir}){
    _id = id;
    _userId = userId;
    _type = type;
    _typeId = typeId;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
    _file = file;
    _dir = dir;
}

  FavouriteResponseModel.fromJson(dynamic json) {
    _id = json['id'];
    _userId = json['user_id'];
    _type = json['type'];
    _typeId = json['type_id'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
    _file = json['file'] != null ? File.fromJson(json['file']) : null;
    _dir = json['dir'] != null ? Dir.fromJson(json['dir']) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['user_id'] = _userId;
    map['type'] = _type;
    map['type_id'] = _typeId;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    if (_file != null) {
      map['file'] = _file.toJson();
    }
    if (_dir != null) {
      map['dir'] = _dir.toJson();
    }
    return map;
  }

}

/// id : 8
/// user_id : 21
/// name : "my"
/// parent_id : null
/// created_at : "2021-11-09T07:47:59.000000Z"
/// updated_at : "2021-11-09T07:47:59.000000Z"

class Dir {
  int _id;
  int _userId;
  String _name;
  dynamic _parentId;
  String _createdAt;
  String _updatedAt;

  int get id => _id;
  int get userId => _userId;
  String get name => _name;
  dynamic get parentId => _parentId;
  String get createdAt => _createdAt;
  String get updatedAt => _updatedAt;

  Dir({
      int id, 
      int userId, 
      String name, 
      dynamic parentId, 
      String createdAt, 
      String updatedAt}){
    _id = id;
    _userId = userId;
    _name = name;
    _parentId = parentId;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
}

  Dir.fromJson(dynamic json) {
    _id = json['id'];
    _userId = json['user_id'];
    _name = json['name'];
    _parentId = json['parent_id'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['user_id'] = _userId;
    map['name'] = _name;
    map['parent_id'] = _parentId;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    return map;
  }

}

/// id : 10
/// user_id : 21
/// library_category_id : 10
/// name : "my.pdf"
/// type : "application/pdf"
/// created_at : "2021-11-08T04:49:16.000000Z"
/// updated_at : "2021-11-13T16:26:29.000000Z"
/// file_url : "http://test.app.ijtimaati.com/api/public/uploads/library/1636346956540519.pdf"
/// size : "547.86 KB"
/// used_in : {"talkingpoints":[{"id":41,"meeting_id":74,"creator_id":21,"title":"This is Test","duration":60,"description":"test","order":0,"laravel_through_key":10,"meeting":{"id":74,"title":"This is Test","owner_id":21,"committee_id":3,"description":"Test","start_date":"2021-11-08 11:23:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"saeed saleh change attendance status to Maybe 2021-11-30 22:30:47","current_member":{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":213,"meeting_id":74,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":208,"meeting_id":74,"user_id":31,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":209,"meeting_id":74,"user_id":35,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":215,"meeting_id":74,"user_id":36,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":"Manager","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":210,"meeting_id":74,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":211,"meeting_id":74,"user_id":38,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":216,"meeting_id":74,"user_id":45,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Admin"},{"id":218,"meeting_id":74,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[{"id":20,"meeting_id":7,"creator_id":3,"title":"test","deadline":"2021-10-23 21:49:09","description":null,"order":0,"laravel_through_key":10,"meeting":{"id":7,"title":"Est aut illum repu","owner_id":1,"committee_id":4,"description":"Adipisci aut et exer","start_date":"2021-10-20 22:55:00","duration":210,"location":"Ullam iste asperiore","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":null,"current_member":null,"members":[]}}],"actions":[]}
/// talkingpoints : [{"id":41,"meeting_id":74,"creator_id":21,"title":"This is Test","duration":60,"description":"test","order":0,"laravel_through_key":10,"meeting":{"id":74,"title":"This is Test","owner_id":21,"committee_id":3,"description":"Test","start_date":"2021-11-08 11:23:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"saeed saleh change attendance status to Maybe 2021-11-30 22:30:47","current_member":{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":213,"meeting_id":74,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":208,"meeting_id":74,"user_id":31,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":209,"meeting_id":74,"user_id":35,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":215,"meeting_id":74,"user_id":36,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":"Manager","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":210,"meeting_id":74,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":211,"meeting_id":74,"user_id":38,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":216,"meeting_id":74,"user_id":45,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Admin"},{"id":218,"meeting_id":74,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}]
/// decisions : [{"id":20,"meeting_id":7,"creator_id":3,"title":"test","deadline":"2021-10-23 21:49:09","description":null,"order":0,"laravel_through_key":10,"meeting":{"id":7,"title":"Est aut illum repu","owner_id":1,"committee_id":4,"description":"Adipisci aut et exer","start_date":"2021-10-20 22:55:00","duration":210,"location":"Ullam iste asperiore","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":null,"current_member":null,"members":[]}}]
/// actions : []

class File {
  int _id;
  int _userId;
  int _libraryCategoryId;
  String _name;
  String _type;
  String _createdAt;
  String _updatedAt;
  String _fileUrl;
  String _size;
  Used_in _usedIn;
  List<Talkingpoints> _talkingpoints;
  List<Decisions> _decisions;
  List<dynamic> _actions;

  int get id => _id;
  int get userId => _userId;
  int get libraryCategoryId => _libraryCategoryId;
  String get name => _name;
  String get type => _type;
  String get createdAt => _createdAt;
  String get updatedAt => _updatedAt;
  String get fileUrl => _fileUrl;
  String get size => _size;
  Used_in get usedIn => _usedIn;
  List<Talkingpoints> get talkingpoints => _talkingpoints;
  List<Decisions> get decisions => _decisions;
  List<dynamic> get actions => _actions;

  File({
      int id, 
      int userId, 
      int libraryCategoryId, 
      String name, 
      String type, 
      String createdAt, 
      String updatedAt, 
      String fileUrl, 
      String size, 
      Used_in usedIn, 
      List<Talkingpoints> talkingpoints, 
      List<Decisions> decisions, 
      List<dynamic> actions}){
    _id = id;
    _userId = userId;
    _libraryCategoryId = libraryCategoryId;
    _name = name;
    _type = type;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
    _fileUrl = fileUrl;
    _size = size;
    _usedIn = usedIn;
    _talkingpoints = talkingpoints;
    _decisions = decisions;
    _actions = actions;
}

  File.fromJson(dynamic json) {
    _id = json['id'];
    _userId = json['user_id'];
    _libraryCategoryId = json['library_category_id'];
    _name = json['name'];
    _type = json['type'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
    _fileUrl = json['file_url'];
    _size = json['size'];
    _usedIn = json['used_in'] != null ? Used_in.fromJson(json['used_in']) : null;
    if (json['talkingpoints'] != null) {
      _talkingpoints = [];
      json['talkingpoints'].forEach((v) {
        _talkingpoints.add(Talkingpoints.fromJson(v));
      });
    }
    if (json['decisions'] != null) {
      _decisions = [];
      json['decisions'].forEach((v) {
        _decisions.add(Decisions.fromJson(v));
      });
    }
    if (json['actions'] != null) {
      _actions = [];
      json['actions'].forEach((v) {
        // _actions.add(dynamic.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['user_id'] = _userId;
    map['library_category_id'] = _libraryCategoryId;
    map['name'] = _name;
    map['type'] = _type;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    map['file_url'] = _fileUrl;
    map['size'] = _size;
    if (_usedIn != null) {
      map['used_in'] = _usedIn.toJson();
    }
    if (_talkingpoints != null) {
      map['talkingpoints'] = _talkingpoints.map((v) => v.toJson()).toList();
    }
    if (_decisions != null) {
      map['decisions'] = _decisions.map((v) => v.toJson()).toList();
    }
    if (_actions != null) {
      map['actions'] = _actions.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 20
/// meeting_id : 7
/// creator_id : 3
/// title : "test"
/// deadline : "2021-10-23 21:49:09"
/// description : null
/// order : 0
/// laravel_through_key : 10
/// meeting : {"id":7,"title":"Est aut illum repu","owner_id":1,"committee_id":4,"description":"Adipisci aut et exer","start_date":"2021-10-20 22:55:00","duration":210,"location":"Ullam iste asperiore","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":null,"current_member":null,"members":[]}

class Decisions {
  int _id;
  int _meetingId;
  int _creatorId;
  String _title;
  String _deadline;
  dynamic _description;
  int _order;
  int _laravelThroughKey;
  Meeting _meeting;

  int get id => _id;
  int get meetingId => _meetingId;
  int get creatorId => _creatorId;
  String get title => _title;
  String get deadline => _deadline;
  dynamic get description => _description;
  int get order => _order;
  int get laravelThroughKey => _laravelThroughKey;
  Meeting get meeting => _meeting;

  Decisions({
      int id, 
      int meetingId, 
      int creatorId, 
      String title, 
      String deadline, 
      dynamic description, 
      int order, 
      int laravelThroughKey, 
      Meeting meeting}){
    _id = id;
    _meetingId = meetingId;
    _creatorId = creatorId;
    _title = title;
    _deadline = deadline;
    _description = description;
    _order = order;
    _laravelThroughKey = laravelThroughKey;
    _meeting = meeting;
}

  Decisions.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _creatorId = json['creator_id'];
    _title = json['title'];
    _deadline = json['deadline'];
    _description = json['description'];
    _order = json['order'];
    _laravelThroughKey = json['laravel_through_key'];
    _meeting = json['meeting'] != null ? Meeting.fromJson(json['meeting']) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['creator_id'] = _creatorId;
    map['title'] = _title;
    map['deadline'] = _deadline;
    map['description'] = _description;
    map['order'] = _order;
    map['laravel_through_key'] = _laravelThroughKey;
    if (_meeting != null) {
      map['meeting'] = _meeting.toJson();
    }
    return map;
  }

}

/// id : 7
/// title : "Est aut illum repu"
/// owner_id : 1
/// committee_id : 4
/// description : "Adipisci aut et exer"
/// start_date : "2021-10-20 22:55:00"
/// duration : 210
/// location : "Ullam iste asperiore"
/// meeting_status_id : 3
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// attendance_status : null
/// last_activity : null
/// current_member : null
/// members : []

class Meeting {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _attendanceStatus;
  dynamic _lastActivity;
  dynamic _currentMember;
  List<dynamic> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get attendanceStatus => _attendanceStatus;
  dynamic get lastActivity => _lastActivity;
  dynamic get currentMember => _currentMember;
  List<dynamic> get members => _members;

  Meeting({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic attendanceStatus, 
      dynamic lastActivity, 
      dynamic currentMember, 
      List<dynamic> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Meeting.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'];
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        // _members.add(dynamic.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    map['current_member'] = _currentMember;
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 41
/// meeting_id : 74
/// creator_id : 21
/// title : "This is Test"
/// duration : 60
/// description : "test"
/// order : 0
/// laravel_through_key : 10
/// meeting : {"id":74,"title":"This is Test","owner_id":21,"committee_id":3,"description":"Test","start_date":"2021-11-08 11:23:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"saeed saleh change attendance status to Maybe 2021-11-30 22:30:47","current_member":{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":213,"meeting_id":74,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":208,"meeting_id":74,"user_id":31,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":209,"meeting_id":74,"user_id":35,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":215,"meeting_id":74,"user_id":36,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":"Manager","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":210,"meeting_id":74,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":211,"meeting_id":74,"user_id":38,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":216,"meeting_id":74,"user_id":45,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Admin"},{"id":218,"meeting_id":74,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}

class Talkingpoints {
  int _id;
  int _meetingId;
  int _creatorId;
  String _title;
  int _duration;
  String _description;
  int _order;
  int _laravelThroughKey;
  Meeting _meeting;

  int get id => _id;
  int get meetingId => _meetingId;
  int get creatorId => _creatorId;
  String get title => _title;
  int get duration => _duration;
  String get description => _description;
  int get order => _order;
  int get laravelThroughKey => _laravelThroughKey;
  Meeting get meeting => _meeting;

  Talkingpoints({
      int id, 
      int meetingId, 
      int creatorId, 
      String title, 
      int duration, 
      String description, 
      int order, 
      int laravelThroughKey, 
      Meeting meeting}){
    _id = id;
    _meetingId = meetingId;
    _creatorId = creatorId;
    _title = title;
    _duration = duration;
    _description = description;
    _order = order;
    _laravelThroughKey = laravelThroughKey;
    _meeting = meeting;
}

  Talkingpoints.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _creatorId = json['creator_id'];
    _title = json['title'];
    _duration = json['duration'];
    _description = json['description'];
    _order = json['order'];
    _laravelThroughKey = json['laravel_through_key'];
    _meeting = json['meeting'] != null ? Meeting.fromJson(json['meeting']) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['creator_id'] = _creatorId;
    map['title'] = _title;
    map['duration'] = _duration;
    map['description'] = _description;
    map['order'] = _order;
    map['laravel_through_key'] = _laravelThroughKey;
    if (_meeting != null) {
      map['meeting'] = _meeting.toJson();
    }
    return map;
  }

}


/// id : 213
/// meeting_id : 74
/// user_id : 3
/// user_email : null
/// can_edit : 0
/// attendance_status : "Maybe"
/// status_reason : null
/// user : {"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null}
/// type : "Viewer"

class Members {
  int _id;
  int _meetingId;
  int _userId;
  dynamic _userEmail;
  int _canEdit;
  String _attendanceStatus;
  dynamic _statusReason;
  User _user;
  String _type;

  int get id => _id;
  int get meetingId => _meetingId;
  int get userId => _userId;
  dynamic get userEmail => _userEmail;
  int get canEdit => _canEdit;
  String get attendanceStatus => _attendanceStatus;
  dynamic get statusReason => _statusReason;
  User get user => _user;
  String get type => _type;

  Members({
      int id, 
      int meetingId, 
      int userId, 
      dynamic userEmail, 
      int canEdit, 
      String attendanceStatus, 
      dynamic statusReason, 
      User user, 
      String type}){
    _id = id;
    _meetingId = meetingId;
    _userId = userId;
    _userEmail = userEmail;
    _canEdit = canEdit;
    _attendanceStatus = attendanceStatus;
    _statusReason = statusReason;
    _user = user;
    _type = type;
}

  Members.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _userId = json['user_id'];
    _userEmail = json['user_email'];
    _canEdit = json['can_edit'];
    _attendanceStatus = json['attendance_status'];
    _statusReason = json['status_reason'];
    _user = json['user'] != null ? User.fromJson(json['user']) : null;
    _type = json['type'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['user_id'] = _userId;
    map['user_email'] = _userEmail;
    map['can_edit'] = _canEdit;
    map['attendance_status'] = _attendanceStatus;
    map['status_reason'] = _statusReason;
    if (_user != null) {
      map['user'] = _user.toJson();
    }
    map['type'] = _type;
    return map;
  }

}

/// name : "saeed saleh"
/// email : "said.sale7@gmail.com"
/// image : "http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png"
/// position : null
/// team_name : ""
/// role_name : ""
/// committee : null
/// role : null

class User {
  String _name;
  String _email;
  String _image;
  dynamic _position;
  String _teamName;
  String _roleName;
  dynamic _committee;
  dynamic _role;

  String get name => _name;
  String get email => _email;
  String get image => _image;
  dynamic get position => _position;
  String get teamName => _teamName;
  String get roleName => _roleName;
  dynamic get committee => _committee;
  dynamic get role => _role;

  User({
      String name, 
      String email, 
      String image, 
      dynamic position, 
      String teamName, 
      String roleName, 
      dynamic committee, 
      dynamic role}){
    _name = name;
    _email = email;
    _image = image;
    _position = position;
    _teamName = teamName;
    _roleName = roleName;
    _committee = committee;
    _role = role;
}

  User.fromJson(dynamic json) {
    _name = json['name'];
    _email = json['email'];
    _image = json['image'];
    _position = json['position'];
    _teamName = json['team_name'];
    _roleName = json['role_name'];
    _committee = json['committee'];
    _role = json['role'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['name'] = _name;
    map['email'] = _email;
    map['image'] = _image;
    map['position'] = _position;
    map['team_name'] = _teamName;
    map['role_name'] = _roleName;
    map['committee'] = _committee;
    map['role'] = _role;
    return map;
  }

}

/// id : 214
/// meeting_id : 74
/// user_id : 21
/// user_email : null
/// can_edit : 0
/// attendance_status : "Pending"
/// status_reason : null
/// user : {"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null}
/// type : "Viewer"

class Current_member {
  int _id;
  int _meetingId;
  int _userId;
  dynamic _userEmail;
  int _canEdit;
  String _attendanceStatus;
  dynamic _statusReason;
  User _user;
  String _type;

  int get id => _id;
  int get meetingId => _meetingId;
  int get userId => _userId;
  dynamic get userEmail => _userEmail;
  int get canEdit => _canEdit;
  String get attendanceStatus => _attendanceStatus;
  dynamic get statusReason => _statusReason;
  User get user => _user;
  String get type => _type;

  Current_member({
      int id, 
      int meetingId, 
      int userId, 
      dynamic userEmail, 
      int canEdit, 
      String attendanceStatus, 
      dynamic statusReason, 
      User user, 
      String type}){
    _id = id;
    _meetingId = meetingId;
    _userId = userId;
    _userEmail = userEmail;
    _canEdit = canEdit;
    _attendanceStatus = attendanceStatus;
    _statusReason = statusReason;
    _user = user;
    _type = type;
}

  Current_member.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _userId = json['user_id'];
    _userEmail = json['user_email'];
    _canEdit = json['can_edit'];
    _attendanceStatus = json['attendance_status'];
    _statusReason = json['status_reason'];
    _user = json['user'] != null ? User.fromJson(json['user']) : null;
    _type = json['type'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['user_id'] = _userId;
    map['user_email'] = _userEmail;
    map['can_edit'] = _canEdit;
    map['attendance_status'] = _attendanceStatus;
    map['status_reason'] = _statusReason;
    if (_user != null) {
      map['user'] = _user.toJson();
    }
    map['type'] = _type;
    return map;
  }

}

class Used_in {
  List<Talkingpoints> _talkingpoints;
  List<dynamic> _decisions;
  List<dynamic> _actions;

  List<Talkingpoints> get talkingpoints => _talkingpoints;
  List<dynamic> get decisions => _decisions;
  List<dynamic> get actions => _actions;

  Used_in({
    List<Talkingpoints> talkingpoints,
    List<dynamic> decisions,
    List<dynamic> actions}){
    _talkingpoints = talkingpoints;
    _decisions = decisions;
    _actions = actions;
  }

  Used_in.fromJson(dynamic json) {
    if (json['talkingpoints'] != null) {
      _talkingpoints = [];
      json['talkingpoints'].forEach((v) {
        _talkingpoints.add(Talkingpoints.fromJson(v));
      });
    }
    if (json['decisions'] != null) {
      _decisions = [];
      json['decisions'].forEach((v) {
        // _decisions.add(dynamic.fromJson(v));
      });
    }
    if (json['actions'] != null) {
      _actions = [];
      json['actions'].forEach((v) {
        // _actions.add(dynamic.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    if (_talkingpoints != null) {
      map['talkingpoints'] = _talkingpoints.map((v) => v.toJson()).toList();
    }
    if (_decisions != null) {
      map['decisions'] = _decisions.map((v) => v.toJson()).toList();
    }
    if (_actions != null) {
      map['actions'] = _actions.map((v) => v.toJson()).toList();
    }
    return map;
  }

}