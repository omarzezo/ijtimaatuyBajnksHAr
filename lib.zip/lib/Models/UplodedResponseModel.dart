/// id : 2
/// user_id : 26
/// library_category_id : null
/// name : "test rename.pdf"
/// type : "application/pdf"
/// created_at : "2021-11-05T21:10:50.000000Z"
/// updated_at : "2021-11-18T04:11:16.000000Z"
/// hidden : 0
/// file_url : "http://test.app.ijtimaati.com/api/public/uploads/library/1637208676886971.pdf"
/// size : "3.97 KB"
/// used_in : {"talkingpoints":[{"id":64,"meeting_id":60,"creator_id":3,"title":"Amet quis et eligen","duration":60,"description":"Quaerat possimus pr","order":0,"mom_conclusion":null,"mom_active":1,"laravel_through_key":2,"meeting":null}],"decisions":[{"id":38,"meeting_id":74,"creator_id":21,"title":"This Test 2","deadline":"2021-11-07 10:25:42","description":"Test","order":0,"talkingpoint_id":null,"mom_conclusion":null,"mom_active":1,"talkingpoint_subpoint_id":null,"laravel_through_key":2,"meeting":{"id":74,"title":"This is Test","owner_id":21,"committee_id":3,"description":"Test","start_date":"2021-11-08 11:23:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"mom":null,"mom_settings":null,"mom_conclusion":null,"attendance_status":"Pending","last_activity":"saeed saleh change meeting status to Scheduled 2021-12-27 6:31 PM","current_member":{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/1uxcRezT2Y.jpg","position":"Cyber","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},"members":[{"id":213,"meeting_id":74,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/1uxcRezT2Y.jpg","position":"Cyber","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":208,"meeting_id":74,"user_id":31,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":null,"position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":209,"meeting_id":74,"user_id":35,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mazin","email":"mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/dZsgwPPzGx.jpeg","position":"IT Support","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":215,"meeting_id":74,"user_id":36,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":null,"position":"Manager","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":210,"meeting_id":74,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":211,"meeting_id":74,"user_id":38,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":216,"meeting_id":74,"user_id":45,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Admin"},{"id":218,"meeting_id":74,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"}]}}],"actions":[]}
/// talkingpoints : [{"id":64,"meeting_id":60,"creator_id":3,"title":"Amet quis et eligen","duration":60,"description":"Quaerat possimus pr","order":0,"mom_conclusion":null,"mom_active":1,"laravel_through_key":2,"meeting":null}]
/// decisions : [{"id":38,"meeting_id":74,"creator_id":21,"title":"This Test 2","deadline":"2021-11-07 10:25:42","description":"Test","order":0,"talkingpoint_id":null,"mom_conclusion":null,"mom_active":1,"talkingpoint_subpoint_id":null,"laravel_through_key":2,"meeting":{"id":74,"title":"This is Test","owner_id":21,"committee_id":3,"description":"Test","start_date":"2021-11-08 11:23:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"mom":null,"mom_settings":null,"mom_conclusion":null,"attendance_status":"Pending","last_activity":"saeed saleh change meeting status to Scheduled 2021-12-27 6:31 PM","current_member":{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/1uxcRezT2Y.jpg","position":"Cyber","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},"members":[{"id":213,"meeting_id":74,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/1uxcRezT2Y.jpg","position":"Cyber","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":208,"meeting_id":74,"user_id":31,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":null,"position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":209,"meeting_id":74,"user_id":35,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mazin","email":"mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/dZsgwPPzGx.jpeg","position":"IT Support","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":215,"meeting_id":74,"user_id":36,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":null,"position":"Manager","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":210,"meeting_id":74,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":211,"meeting_id":74,"user_id":38,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":216,"meeting_id":74,"user_id":45,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Admin"},{"id":218,"meeting_id":74,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"}]}}]
/// actions : []

class UplodedResponseModel {
  UplodedResponseModel({
      int id, 
      int userId, 
      dynamic libraryCategoryId, 
      String name, 
      String type, 
      String createdAt, 
      String updatedAt, 
      int hidden, 
      String fileUrl, 
      String size, 
      UsedIn usedIn, 
      List<Talkingpoints> talkingpoints, 
      List<Decisions> decisions, 
      List<dynamic> actions,}){
    _id = id;
    _userId = userId;
    _libraryCategoryId = libraryCategoryId;
    _name = name;
    _type = type;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
    _hidden = hidden;
    _fileUrl = fileUrl;
    _size = size;
    _usedIn = usedIn;
    _talkingpoints = talkingpoints;
    _decisions = decisions;
    _actions = actions;
}

  UplodedResponseModel.fromJson(dynamic json) {
    _id = json['id'];
    _userId = json['user_id'];
    _libraryCategoryId = json['library_category_id'];
    _name = json['name'];
    _type = json['type'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
    _hidden = json['hidden'];
    _fileUrl = json['file_url'];
    _size = json['size'];
    _usedIn = json['used_in'] != null ? UsedIn.fromJson(json['usedIn']) : null;
    if (json['talkingpoints'] != null) {
      _talkingpoints = [];
      json['talkingpoints'].forEach((v) {
        _talkingpoints.add(Talkingpoints.fromJson(v));
      });
    }
    if (json['decisions'] != null) {
      _decisions = [];
      json['decisions'].forEach((v) {
        _decisions.add(Decisions.fromJson(v));
      });
    }
    if (json['actions'] != null) {
      _actions = [];
      json['actions'].forEach((v) {
        // _actions.add(Dynamic.fromJson(v));
      });
    }
  }
  int _id;
  int _userId;
  dynamic _libraryCategoryId;
  String _name;
  String _type;
  String _createdAt;
  String _updatedAt;
  int _hidden;
  String _fileUrl;
  String _size;
  UsedIn _usedIn;
  List<Talkingpoints> _talkingpoints;
  List<Decisions> _decisions;
  List<dynamic> _actions;

  int get id => _id;
  int get userId => _userId;
  dynamic get libraryCategoryId => _libraryCategoryId;
  String get name => _name;
  String get type => _type;
  String get createdAt => _createdAt;
  String get updatedAt => _updatedAt;
  int get hidden => _hidden;
  String get fileUrl => _fileUrl;
  String get size => _size;
  UsedIn get usedIn => _usedIn;
  List<Talkingpoints> get talkingpoints => _talkingpoints;
  List<Decisions> get decisions => _decisions;
  List<dynamic> get actions => _actions;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['user_id'] = _userId;
    map['library_category_id'] = _libraryCategoryId;
    map['name'] = _name;
    map['type'] = _type;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    map['hidden'] = _hidden;
    map['file_url'] = _fileUrl;
    map['size'] = _size;
    if (_usedIn != null) {
      map['used_in'] = _usedIn.toJson();
    }
    if (_talkingpoints != null) {
      map['talkingpoints'] = _talkingpoints.map((v) => v.toJson()).toList();
    }
    if (_decisions != null) {
      map['decisions'] = _decisions.map((v) => v.toJson()).toList();
    }
    if (_actions != null) {
      map['actions'] = _actions.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 38
/// meeting_id : 74
/// creator_id : 21
/// title : "This Test 2"
/// deadline : "2021-11-07 10:25:42"
/// description : "Test"
/// order : 0
/// talkingpoint_id : null
/// mom_conclusion : null
/// mom_active : 1
/// talkingpoint_subpoint_id : null
/// laravel_through_key : 2
/// meeting : {"id":74,"title":"This is Test","owner_id":21,"committee_id":3,"description":"Test","start_date":"2021-11-08 11:23:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"mom":null,"mom_settings":null,"mom_conclusion":null,"attendance_status":"Pending","last_activity":"saeed saleh change meeting status to Scheduled 2021-12-27 6:31 PM","current_member":{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/1uxcRezT2Y.jpg","position":"Cyber","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},"members":[{"id":213,"meeting_id":74,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/1uxcRezT2Y.jpg","position":"Cyber","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":208,"meeting_id":74,"user_id":31,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":null,"position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":209,"meeting_id":74,"user_id":35,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mazin","email":"mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/dZsgwPPzGx.jpeg","position":"IT Support","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":215,"meeting_id":74,"user_id":36,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":null,"position":"Manager","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":210,"meeting_id":74,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":211,"meeting_id":74,"user_id":38,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":216,"meeting_id":74,"user_id":45,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Admin"},{"id":218,"meeting_id":74,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"}]}

class Decisions {
  Decisions({
      int id, 
      int meetingId, 
      int creatorId, 
      String title, 
      String deadline, 
      String description, 
      int order, 
      dynamic talkingpointId, 
      dynamic momConclusion, 
      int momActive, 
      dynamic talkingpointSubpointId, 
      int laravelThroughKey, 
      Meeting meeting,}){
    _id = id;
    _meetingId = meetingId;
    _creatorId = creatorId;
    _title = title;
    _deadline = deadline;
    _description = description;
    _order = order;
    _talkingpointId = talkingpointId;
    _momConclusion = momConclusion;
    _momActive = momActive;
    _talkingpointSubpointId = talkingpointSubpointId;
    _laravelThroughKey = laravelThroughKey;
    _meeting = meeting;
}

  Decisions.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _creatorId = json['creator_id'];
    _title = json['title'];
    _deadline = json['deadline'];
    _description = json['description'];
    _order = json['order'];
    _talkingpointId = json['talkingpoint_id'];
    _momConclusion = json['mom_conclusion'];
    _momActive = json['mom_active'];
    _talkingpointSubpointId = json['talkingpoint_subpoint_id'];
    _laravelThroughKey = json['laravel_through_key'];
    _meeting = json['meeting'] != null ? Meeting.fromJson(json['meeting']) : null;
  }
  int _id;
  int _meetingId;
  int _creatorId;
  String _title;
  String _deadline;
  String _description;
  int _order;
  dynamic _talkingpointId;
  dynamic _momConclusion;
  int _momActive;
  dynamic _talkingpointSubpointId;
  int _laravelThroughKey;
  Meeting _meeting;

  int get id => _id;
  int get meetingId => _meetingId;
  int get creatorId => _creatorId;
  String get title => _title;
  String get deadline => _deadline;
  String get description => _description;
  int get order => _order;
  dynamic get talkingpointId => _talkingpointId;
  dynamic get momConclusion => _momConclusion;
  int get momActive => _momActive;
  dynamic get talkingpointSubpointId => _talkingpointSubpointId;
  int get laravelThroughKey => _laravelThroughKey;
  Meeting get meeting => _meeting;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['creator_id'] = _creatorId;
    map['title'] = _title;
    map['deadline'] = _deadline;
    map['description'] = _description;
    map['order'] = _order;
    map['talkingpoint_id'] = _talkingpointId;
    map['mom_conclusion'] = _momConclusion;
    map['mom_active'] = _momActive;
    map['talkingpoint_subpoint_id'] = _talkingpointSubpointId;
    map['laravel_through_key'] = _laravelThroughKey;
    if (_meeting != null) {
      map['meeting'] = _meeting.toJson();
    }
    return map;
  }

}

/// id : 74
/// title : "This is Test"
/// owner_id : 21
/// committee_id : 3
/// description : "Test"
/// start_date : "2021-11-08 11:23:00"
/// duration : 60
/// location : "Muscat"
/// meeting_status_id : 3
/// virtual : 1
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// mom : null
/// mom_settings : null
/// mom_conclusion : null
/// attendance_status : "Pending"
/// last_activity : "saeed saleh change meeting status to Scheduled 2021-12-27 6:31 PM"
/// current_member : {"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/1uxcRezT2Y.jpg","position":"Cyber","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"}
/// members : [{"id":213,"meeting_id":74,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/1uxcRezT2Y.jpg","position":"Cyber","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":208,"meeting_id":74,"user_id":31,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":null,"position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":209,"meeting_id":74,"user_id":35,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mazin","email":"mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/dZsgwPPzGx.jpeg","position":"IT Support","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":215,"meeting_id":74,"user_id":36,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":null,"position":"Manager","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":210,"meeting_id":74,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":211,"meeting_id":74,"user_id":38,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":216,"meeting_id":74,"user_id":45,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Admin"},{"id":218,"meeting_id":74,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"}]

class Meeting {
  Meeting({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      dynamic mom, 
      dynamic momSettings, 
      dynamic momConclusion, 
      String attendanceStatus, 
      String lastActivity, 
      CurrentMember currentMember, 
      List<Members> members,}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _mom = mom;
    _momSettings = momSettings;
    _momConclusion = momConclusion;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Meeting.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _mom = json['mom'];
    _momSettings = json['mom_settings'];
    _momConclusion = json['mom_conclusion'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? CurrentMember.fromJson(json['currentMember']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(Members.fromJson(v));
      });
    }
  }
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  dynamic _mom;
  dynamic _momSettings;
  dynamic _momConclusion;
  String _attendanceStatus;
  String _lastActivity;
  CurrentMember _currentMember;
  List<Members> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  dynamic get mom => _mom;
  dynamic get momSettings => _momSettings;
  dynamic get momConclusion => _momConclusion;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  CurrentMember get currentMember => _currentMember;
  List<Members> get members => _members;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['mom'] = _mom;
    map['mom_settings'] = _momSettings;
    map['mom_conclusion'] = _momConclusion;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 213
/// meeting_id : 74
/// user_id : 3
/// user_email : null
/// can_edit : 0
/// attendance_status : "Maybe"
/// status_reason : null
/// token : null
/// user : {"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":[],"role":null}
/// type : "Viewer"

class Members {
  Members({
      int id, 
      int meetingId, 
      int userId, 
      dynamic userEmail, 
      int canEdit, 
      String attendanceStatus, 
      dynamic statusReason, 
      dynamic token, 
      User user, 
      String type,}){
    _id = id;
    _meetingId = meetingId;
    _userId = userId;
    _userEmail = userEmail;
    _canEdit = canEdit;
    _attendanceStatus = attendanceStatus;
    _statusReason = statusReason;
    _token = token;
    _user = user;
    _type = type;
}

  Members.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _userId = json['user_id'];
    _userEmail = json['user_email'];
    _canEdit = json['can_edit'];
    _attendanceStatus = json['attendance_status'];
    _statusReason = json['status_reason'];
    _token = json['token'];
    _user = json['user'] != null ? User.fromJson(json['user']) : null;
    _type = json['type'];
  }
  int _id;
  int _meetingId;
  int _userId;
  dynamic _userEmail;
  int _canEdit;
  String _attendanceStatus;
  dynamic _statusReason;
  dynamic _token;
  User _user;
  String _type;

  int get id => _id;
  int get meetingId => _meetingId;
  int get userId => _userId;
  dynamic get userEmail => _userEmail;
  int get canEdit => _canEdit;
  String get attendanceStatus => _attendanceStatus;
  dynamic get statusReason => _statusReason;
  dynamic get token => _token;
  User get user => _user;
  String get type => _type;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['user_id'] = _userId;
    map['user_email'] = _userEmail;
    map['can_edit'] = _canEdit;
    map['attendance_status'] = _attendanceStatus;
    map['status_reason'] = _statusReason;
    map['token'] = _token;
    if (_user != null) {
      map['user'] = _user.toJson();
    }
    map['type'] = _type;
    return map;
  }

}

/// name : "saeed saleh"
/// email : "said.sale7@gmail.com"
/// image : "http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png"
/// position : null
/// team_name : ""
/// role_name : ""
/// committee : []
/// role : null

class User {
  User({
      String name, 
      String email, 
      String image, 
      dynamic position, 
      String teamName, 
      String roleName, 
      List<dynamic> committee, 
      dynamic role,}){
    _name = name;
    _email = email;
    _image = image;
    _position = position;
    _teamName = teamName;
    _roleName = roleName;
    _committee = committee;
    _role = role;
}

  User.fromJson(dynamic json) {
    _name = json['name'];
    _email = json['email'];
    _image = json['image'];
    _position = json['position'];
    _teamName = json['team_name'];
    _roleName = json['role_name'];
    if (json['committee'] != null) {
      _committee = [];
      json['committee'].forEach((v) {
        // _committee.add(Dynamic.fromJson(v));
      });
    }
    _role = json['role'];
  }
  String _name;
  String _email;
  String _image;
  dynamic _position;
  String _teamName;
  String _roleName;
  List<dynamic> _committee;
  dynamic _role;

  String get name => _name;
  String get email => _email;
  String get image => _image;
  dynamic get position => _position;
  String get teamName => _teamName;
  String get roleName => _roleName;
  List<dynamic> get committee => _committee;
  dynamic get role => _role;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['email'] = _email;
    map['image'] = _image;
    map['position'] = _position;
    map['team_name'] = _teamName;
    map['role_name'] = _roleName;
    if (_committee != null) {
      map['committee'] = _committee.map((v) => v.toJson()).toList();
    }
    map['role'] = _role;
    return map;
  }

}

/// id : 214
/// meeting_id : 74
/// user_id : 21
/// user_email : null
/// can_edit : 0
/// attendance_status : "Pending"
/// status_reason : null
/// token : null
/// user : {"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/1uxcRezT2Y.jpg","position":"Cyber","team_name":"","role_name":"","committee":[],"role":null}
/// type : "Viewer"

class CurrentMember {
  CurrentMember({
      int id, 
      int meetingId, 
      int userId, 
      dynamic userEmail, 
      int canEdit, 
      String attendanceStatus, 
      dynamic statusReason, 
      dynamic token, 
      User user, 
      String type,}){
    _id = id;
    _meetingId = meetingId;
    _userId = userId;
    _userEmail = userEmail;
    _canEdit = canEdit;
    _attendanceStatus = attendanceStatus;
    _statusReason = statusReason;
    _token = token;
    _user = user;
    _type = type;
}

  CurrentMember.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _userId = json['user_id'];
    _userEmail = json['user_email'];
    _canEdit = json['can_edit'];
    _attendanceStatus = json['attendance_status'];
    _statusReason = json['status_reason'];
    _token = json['token'];
    _user = json['user'] != null ? User.fromJson(json['user']) : null;
    _type = json['type'];
  }
  int _id;
  int _meetingId;
  int _userId;
  dynamic _userEmail;
  int _canEdit;
  String _attendanceStatus;
  dynamic _statusReason;
  dynamic _token;
  User _user;
  String _type;

  int get id => _id;
  int get meetingId => _meetingId;
  int get userId => _userId;
  dynamic get userEmail => _userEmail;
  int get canEdit => _canEdit;
  String get attendanceStatus => _attendanceStatus;
  dynamic get statusReason => _statusReason;
  dynamic get token => _token;
  User get user => _user;
  String get type => _type;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['user_id'] = _userId;
    map['user_email'] = _userEmail;
    map['can_edit'] = _canEdit;
    map['attendance_status'] = _attendanceStatus;
    map['status_reason'] = _statusReason;
    map['token'] = _token;
    if (_user != null) {
      map['user'] = _user.toJson();
    }
    map['type'] = _type;
    return map;
  }

}


/// id : 64
/// meeting_id : 60
/// creator_id : 3
/// title : "Amet quis et eligen"
/// duration : 60
/// description : "Quaerat possimus pr"
/// order : 0
/// mom_conclusion : null
/// mom_active : 1
/// laravel_through_key : 2
/// meeting : null

class Talkingpoints {
  Talkingpoints({
      int id, 
      int meetingId, 
      int creatorId, 
      String title, 
      int duration, 
      String description, 
      int order, 
      dynamic momConclusion, 
      int momActive, 
      int laravelThroughKey, 
      dynamic meeting,}){
    _id = id;
    _meetingId = meetingId;
    _creatorId = creatorId;
    _title = title;
    _duration = duration;
    _description = description;
    _order = order;
    _momConclusion = momConclusion;
    _momActive = momActive;
    _laravelThroughKey = laravelThroughKey;
    _meeting = meeting;
}

  Talkingpoints.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _creatorId = json['creator_id'];
    _title = json['title'];
    _duration = json['duration'];
    _description = json['description'];
    _order = json['order'];
    _momConclusion = json['mom_conclusion'];
    _momActive = json['mom_active'];
    _laravelThroughKey = json['laravel_through_key'];
    _meeting = json['meeting'];
  }
  int _id;
  int _meetingId;
  int _creatorId;
  String _title;
  int _duration;
  String _description;
  int _order;
  dynamic _momConclusion;
  int _momActive;
  int _laravelThroughKey;
  dynamic _meeting;

  int get id => _id;
  int get meetingId => _meetingId;
  int get creatorId => _creatorId;
  String get title => _title;
  int get duration => _duration;
  String get description => _description;
  int get order => _order;
  dynamic get momConclusion => _momConclusion;
  int get momActive => _momActive;
  int get laravelThroughKey => _laravelThroughKey;
  dynamic get meeting => _meeting;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['creator_id'] = _creatorId;
    map['title'] = _title;
    map['duration'] = _duration;
    map['description'] = _description;
    map['order'] = _order;
    map['mom_conclusion'] = _momConclusion;
    map['mom_active'] = _momActive;
    map['laravel_through_key'] = _laravelThroughKey;
    map['meeting'] = _meeting;
    return map;
  }

}

/// talkingpoints : [{"id":64,"meeting_id":60,"creator_id":3,"title":"Amet quis et eligen","duration":60,"description":"Quaerat possimus pr","order":0,"mom_conclusion":null,"mom_active":1,"laravel_through_key":2,"meeting":null}]
/// decisions : [{"id":38,"meeting_id":74,"creator_id":21,"title":"This Test 2","deadline":"2021-11-07 10:25:42","description":"Test","order":0,"talkingpoint_id":null,"mom_conclusion":null,"mom_active":1,"talkingpoint_subpoint_id":null,"laravel_through_key":2,"meeting":{"id":74,"title":"This is Test","owner_id":21,"committee_id":3,"description":"Test","start_date":"2021-11-08 11:23:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"mom":null,"mom_settings":null,"mom_conclusion":null,"attendance_status":"Pending","last_activity":"saeed saleh change meeting status to Scheduled 2021-12-27 6:31 PM","current_member":{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/1uxcRezT2Y.jpg","position":"Cyber","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},"members":[{"id":213,"meeting_id":74,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/1uxcRezT2Y.jpg","position":"Cyber","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":208,"meeting_id":74,"user_id":31,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":null,"position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":209,"meeting_id":74,"user_id":35,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mazin","email":"mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/dZsgwPPzGx.jpeg","position":"IT Support","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":215,"meeting_id":74,"user_id":36,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":null,"position":"Manager","team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":210,"meeting_id":74,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":211,"meeting_id":74,"user_id":38,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"},{"id":216,"meeting_id":74,"user_id":45,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Admin"},{"id":218,"meeting_id":74,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":[],"role":null},"type":"Viewer"}]}}]
/// actions : []

class UsedIn {
  UsedIn({
      List<Talkingpoints> talkingpoints,
      List<Decisions> decisions,
      List<dynamic> actions,}){
    _talkingpoints = talkingpoints;
    _decisions = decisions;
    _actions = actions;
}

  UsedIn.fromJson(dynamic json) {
    if (json['talkingpoints'] != null) {
      _talkingpoints = [];
      json['talkingpoints'].forEach((v) {
        _talkingpoints.add(Talkingpoints.fromJson(v));
      });
    }
    if (json['decisions'] != null) {
      _decisions = [];
      json['decisions'].forEach((v) {
        _decisions.add(Decisions.fromJson(v));
      });
    }
    if (json['actions'] != null) {
      _actions = [];
      json['actions'].forEach((v) {
        // _actions.add(Dynamic.fromJson(v));
      });
    }
  }
  List<Talkingpoints> _talkingpoints;
  List<Decisions> _decisions;
  List<dynamic> _actions;

  List<Talkingpoints> get talkingpoints => _talkingpoints;
  List<Decisions> get decisions => _decisions;
  List<dynamic> get actions => _actions;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_talkingpoints != null) {
      map['talkingpoints'] = _talkingpoints.map((v) => v.toJson()).toList();
    }
    if (_decisions != null) {
      map['decisions'] = _decisions.map((v) => v.toJson()).toList();
    }
    if (_actions != null) {
      map['actions'] = _actions.map((v) => v.toJson()).toList();
    }
    return map;
  }

}



