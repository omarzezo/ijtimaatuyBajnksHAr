/// dirs : [{"id":8,"user_id":21,"name":"my","parent_id":null,"created_at":"2021-11-09T07:47:59.000000Z","updated_at":"2021-11-09T07:47:59.000000Z","dirs":[{"id":10,"user_id":21,"name":"test 1","parent_id":8,"created_at":"2021-11-11T00:11:44.000000Z","updated_at":"2021-11-11T00:11:44.000000Z","dirs":[],"files":[{"id":10,"user_id":21,"library_category_id":10,"name":"my.pdf","type":"application/pdf","created_at":"2021-11-08T04:49:16.000000Z","updated_at":"2021-11-13T16:26:29.000000Z","file_url":"http://test.app.ijtimaati.com/api/public/uploads/library/1636346956540519.pdf","size":"547.86 KB","used_in":{"talkingpoints":[{"id":41,"meeting_id":74,"creator_id":21,"title":"This is Test","duration":60,"description":"test","order":0,"laravel_through_key":10,"meeting":{"id":74,"title":"This is Test","owner_id":21,"committee_id":3,"description":"Test","start_date":"2021-11-08 11:23:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"saeed saleh change attendance status to Maybe 2021-11-30 22:30:47","current_member":{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":213,"meeting_id":74,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":208,"meeting_id":74,"user_id":31,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":209,"meeting_id":74,"user_id":35,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":215,"meeting_id":74,"user_id":36,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":"Manager","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":210,"meeting_id":74,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":211,"meeting_id":74,"user_id":38,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":216,"meeting_id":74,"user_id":45,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Admin"},{"id":218,"meeting_id":74,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[{"id":20,"meeting_id":7,"creator_id":3,"title":"test","deadline":"2021-10-23 21:49:09","description":null,"order":0,"laravel_through_key":10,"meeting":{"id":7,"title":"Est aut illum repu","owner_id":1,"committee_id":4,"description":"Adipisci aut et exer","start_date":"2021-10-20 22:55:00","duration":210,"location":"Ullam iste asperiore","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":null,"current_member":null,"members":[]}}],"actions":[]},"talkingpoints":[{"id":41,"meeting_id":74,"creator_id":21,"title":"This is Test","duration":60,"description":"test","order":0,"laravel_through_key":10,"meeting":{"id":74,"title":"This is Test","owner_id":21,"committee_id":3,"description":"Test","start_date":"2021-11-08 11:23:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"saeed saleh change attendance status to Maybe 2021-11-30 22:30:47","current_member":{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":213,"meeting_id":74,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":208,"meeting_id":74,"user_id":31,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":209,"meeting_id":74,"user_id":35,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":215,"meeting_id":74,"user_id":36,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":"Manager","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":210,"meeting_id":74,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":211,"meeting_id":74,"user_id":38,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":216,"meeting_id":74,"user_id":45,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Admin"},{"id":218,"meeting_id":74,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[{"id":20,"meeting_id":7,"creator_id":3,"title":"test","deadline":"2021-10-23 21:49:09","description":null,"order":0,"laravel_through_key":10,"meeting":{"id":7,"title":"Est aut illum repu","owner_id":1,"committee_id":4,"description":"Adipisci aut et exer","start_date":"2021-10-20 22:55:00","duration":210,"location":"Ullam iste asperiore","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":null,"current_member":null,"members":[]}}],"actions":[]}],"share":[],"fav":[{"id":52,"user_id":21,"type":"dir","type_id":10,"created_at":"2021-11-29T00:26:38.000000Z","updated_at":"2021-11-29T00:26:38.000000Z"}]}],"files":[{"id":86,"user_id":21,"library_category_id":8,"name":"powerpoint.pot","type":"application/vnd.ms-powerpoint","created_at":"2021-11-26T20:40:18.000000Z","updated_at":"2021-11-26T20:40:18.000000Z","file_url":"http://test.app.ijtimaati.com/api/public/uploads/library/1637959218975777.pot","size":"2.00 B","used_in":{"talkingpoints":[],"decisions":[],"actions":[]},"talkingpoints":[],"decisions":[],"actions":[]}],"share":[{"id":1,"name":"saeed saleh","email":"test@test2.ijtimaati.local","role_id":1,"phone":"011118864400","birthdate":"1981-08-20","team":23,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/FaNlH2ba4c.html","status":1,"position":null,"two_auth":"1","verification_code":null,"team_name":"IT Team","role_name":"Organization Admins","pivot":{"type_id":8,"user_id":1},"committee":{"id":23,"name":"IT Team","description":"Ijtimaati","created_at":"2021-10-31T07:30:08.000000Z","updated_at":"2021-11-01T19:34:55.000000Z","deleted_at":null},"role":{"id":1,"name":"Organization Admins","slug":"admin","created_at":"2021-09-12T17:52:27.000000Z","updated_at":"2021-09-12T17:52:27.000000Z"}},{"id":34,"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","role_id":31,"phone":"123112","birthdate":"1990-01-01","team":8,"image":"http://test.app.ijtimaati.com/api/public/avatar.png","status":1,"position":null,"two_auth":"1","verification_code":null,"team_name":"Ijtimaati","role_name":"Role2","pivot":{"type_id":8,"user_id":34},"committee":{"id":8,"name":"Ijtimaati","description":"This is test","created_at":"2021-09-26T07:50:11.000000Z","updated_at":"2021-11-01T06:40:45.000000Z","deleted_at":null},"role":{"id":31,"name":"Role2","slug":"Role2","created_at":"2021-12-05T17:46:39.000000Z","updated_at":"2021-12-05T17:47:07.000000Z"}}],"fav":[{"id":30,"user_id":21,"type":"dir","type_id":8,"created_at":"2021-11-19T10:57:57.000000Z","updated_at":"2021-11-19T10:57:57.000000Z"}]},{"id":34,"user_id":21,"name":"test 2","parent_id":null,"created_at":"2021-11-24T06:27:03.000000Z","updated_at":"2021-11-24T06:27:03.000000Z","dirs":[],"files":[],"share":[],"fav":[{"id":49,"user_id":21,"type":"dir","type_id":34,"created_at":"2021-11-26T20:35:31.000000Z","updated_at":"2021-11-26T20:35:31.000000Z"}]},{"id":42,"user_id":21,"name":"test","parent_id":null,"created_at":"2021-11-26T20:36:32.000000Z","updated_at":"2021-11-26T20:36:32.000000Z","dirs":[],"files":[],"share":[],"fav":[{"id":53,"user_id":21,"type":"dir","type_id":42,"created_at":"2021-12-05T17:29:24.000000Z","updated_at":"2021-12-05T17:29:24.000000Z"}]}]
/// files : [{"id":32,"user_id":21,"library_category_id":null,"name":"MyCV (2) (1) (1).pdf","type":"application/pdf","created_at":"2021-11-14T04:45:15.000000Z","updated_at":"2021-11-23T04:29:51.000000Z","file_url":"http://test.app.ijtimaati.com/api/public/uploads/library/1637641791599106.","size":"38.90 KB","used_in":{"talkingpoints":[{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":32,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":73,"meeting_id":103,"creator_id":21,"title":"Product updates","duration":30,"description":"product updates for all solutions","order":0,"laravel_through_key":32,"meeting":{"id":103,"title":"Ibrahim test 01","owner_id":21,"committee_id":8,"description":"test","start_date":"2021-11-16 17:39:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Ibrahim change attendance status to Going 2021-11-15 17:51:19","current_member":{"id":310,"meeting_id":103,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":310,"meeting_id":103,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":313,"meeting_id":103,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":311,"meeting_id":103,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":312,"meeting_id":103,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":309,"meeting_id":103,"user_id":58,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ibrahim","email":"ibrahim@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":32,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[],"actions":[{"id":29,"meeting_id":160,"creator_id":21,"title":"title","open_till":"2021-12-05 19:14:50","priority":"Low","description":null,"order":0,"laravel_through_key":32,"meeting":{"id":160,"title":"Testing team meeting","owner_id":21,"committee_id":23,"description":"Testing team meeting","start_date":"2021-12-06 23:08:00","duration":1320,"location":null,"meeting_status_id":2,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":"Ahmed Zaid Update this meeting 2021-12-06 21:59:27","current_member":null,"members":[{"id":353,"meeting_id":160,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":351,"meeting_id":160,"user_id":41,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":null,"type":"Admin"},{"id":352,"meeting_id":160,"user_id":78,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mohamed ismail","email":"mohamedismail120827@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}]},"share":[{"id":35,"name":"Mazin F","email":"Mazin@ijtimaati.com","role_id":1,"phone":"97038101","birthdate":"1981-08-22","team":3,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","status":1,"position":"IT Support","two_auth":"1","verification_code":null,"team_name":"Ijtimaati Team","role_name":"Organization Admins","pivot":{"type_id":32,"user_id":35},"committee":{"id":3,"name":"Ijtimaati Team","description":"This is Ijtimaati team","created_at":"2021-09-12T20:48:40.000000Z","updated_at":"2021-11-01T19:33:28.000000Z","deleted_at":null},"role":{"id":1,"name":"Organization Admins","slug":"admin","created_at":"2021-09-12T17:52:27.000000Z","updated_at":"2021-09-12T17:52:27.000000Z"}},{"id":35,"name":"Mazin F","email":"Mazin@ijtimaati.com","role_id":1,"phone":"97038101","birthdate":"1981-08-22","team":3,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","status":1,"position":"IT Support","two_auth":"1","verification_code":null,"team_name":"Ijtimaati Team","role_name":"Organization Admins","pivot":{"type_id":32,"user_id":35},"committee":{"id":3,"name":"Ijtimaati Team","description":"This is Ijtimaati team","created_at":"2021-09-12T20:48:40.000000Z","updated_at":"2021-11-01T19:33:28.000000Z","deleted_at":null},"role":{"id":1,"name":"Organization Admins","slug":"admin","created_at":"2021-09-12T17:52:27.000000Z","updated_at":"2021-09-12T17:52:27.000000Z"}},{"id":35,"name":"Mazin F","email":"Mazin@ijtimaati.com","role_id":1,"phone":"97038101","birthdate":"1981-08-22","team":3,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","status":1,"position":"IT Support","two_auth":"1","verification_code":null,"team_name":"Ijtimaati Team","role_name":"Organization Admins","pivot":{"type_id":32,"user_id":35},"committee":{"id":3,"name":"Ijtimaati Team","description":"This is Ijtimaati team","created_at":"2021-09-12T20:48:40.000000Z","updated_at":"2021-11-01T19:33:28.000000Z","deleted_at":null},"role":{"id":1,"name":"Organization Admins","slug":"admin","created_at":"2021-09-12T17:52:27.000000Z","updated_at":"2021-09-12T17:52:27.000000Z"}},{"id":35,"name":"Mazin F","email":"Mazin@ijtimaati.com","role_id":1,"phone":"97038101","birthdate":"1981-08-22","team":3,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","status":1,"position":"IT Support","two_auth":"1","verification_code":null,"team_name":"Ijtimaati Team","role_name":"Organization Admins","pivot":{"type_id":32,"user_id":35},"committee":{"id":3,"name":"Ijtimaati Team","description":"This is Ijtimaati team","created_at":"2021-09-12T20:48:40.000000Z","updated_at":"2021-11-01T19:33:28.000000Z","deleted_at":null},"role":{"id":1,"name":"Organization Admins","slug":"admin","created_at":"2021-09-12T17:52:27.000000Z","updated_at":"2021-09-12T17:52:27.000000Z"}},{"id":35,"name":"Mazin F","email":"Mazin@ijtimaati.com","role_id":1,"phone":"97038101","birthdate":"1981-08-22","team":3,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","status":1,"position":"IT Support","two_auth":"1","verification_code":null,"team_name":"Ijtimaati Team","role_name":"Organization Admins","pivot":{"type_id":32,"user_id":35},"committee":{"id":3,"name":"Ijtimaati Team","description":"This is Ijtimaati team","created_at":"2021-09-12T20:48:40.000000Z","updated_at":"2021-11-01T19:33:28.000000Z","deleted_at":null},"role":{"id":1,"name":"Organization Admins","slug":"admin","created_at":"2021-09-12T17:52:27.000000Z","updated_at":"2021-09-12T17:52:27.000000Z"}}],"fav":[],"talkingpoints":[{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":32,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":73,"meeting_id":103,"creator_id":21,"title":"Product updates","duration":30,"description":"product updates for all solutions","order":0,"laravel_through_key":32,"meeting":{"id":103,"title":"Ibrahim test 01","owner_id":21,"committee_id":8,"description":"test","start_date":"2021-11-16 17:39:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Ibrahim change attendance status to Going 2021-11-15 17:51:19","current_member":{"id":310,"meeting_id":103,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":310,"meeting_id":103,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":313,"meeting_id":103,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":311,"meeting_id":103,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":312,"meeting_id":103,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":309,"meeting_id":103,"user_id":58,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ibrahim","email":"ibrahim@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":32,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[],"actions":[{"id":29,"meeting_id":160,"creator_id":21,"title":"title","open_till":"2021-12-05 19:14:50","priority":"Low","description":null,"order":0,"laravel_through_key":32,"meeting":{"id":160,"title":"Testing team meeting","owner_id":21,"committee_id":23,"description":"Testing team meeting","start_date":"2021-12-06 23:08:00","duration":1320,"location":null,"meeting_status_id":2,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":"Ahmed Zaid Update this meeting 2021-12-06 21:59:27","current_member":null,"members":[{"id":353,"meeting_id":160,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":351,"meeting_id":160,"user_id":41,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":null,"type":"Admin"},{"id":352,"meeting_id":160,"user_id":78,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mohamed ismail","email":"mohamedismail120827@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}]},{"id":33,"user_id":21,"library_category_id":null,"name":"ibrahim cv .pdf","type":"application/pdf","created_at":"2021-11-14T06:56:10.000000Z","updated_at":"2021-11-24T17:08:45.000000Z","file_url":"http://test.app.ijtimaati.com/api/public/uploads/library/1637598528676077.","size":"232.39 KB","used_in":{"talkingpoints":[{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":33,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":32,"meeting_id":47,"creator_id":21,"title":"Sales and Marketing Status","duration":60,"description":"Last Year Target","order":0,"laravel_through_key":33,"meeting":{"id":47,"title":"Steering Committee Meeting","owner_id":35,"committee_id":3,"description":"Steering Committee Meeting 32","start_date":"2021-12-07 06:00:00","duration":60,"location":"Meeting room","meeting_status_id":2,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Ahmed Zaid change meeting status to Scheduled 2021-12-13 17:56:05","current_member":{"id":111,"meeting_id":47,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":149,"meeting_id":47,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Not going","status_reason":"ssssssss","user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":111,"meeting_id":47,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":303,"meeting_id":47,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":306,"meeting_id":47,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":304,"meeting_id":47,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":305,"meeting_id":47,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":33,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":90,"meeting_id":188,"creator_id":21,"title":"q1","duration":60,"description":"tt","order":0,"laravel_through_key":33,"meeting":{"id":188,"title":"test","owner_id":21,"committee_id":3,"description":"","start_date":"2021-12-14 11:21:00","duration":60,"location":null,"meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Abdullah change attendance status to Going 2021-12-13 10:35:01","current_member":{"id":430,"meeting_id":188,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":429,"meeting_id":188,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":430,"meeting_id":188,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":419,"meeting_id":188,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":420,"meeting_id":188,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":431,"meeting_id":188,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":"Manager","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":421,"meeting_id":188,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":422,"meeting_id":188,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":423,"meeting_id":188,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":424,"meeting_id":188,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":432,"meeting_id":188,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":425,"meeting_id":188,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":426,"meeting_id":188,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":427,"meeting_id":188,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":428,"meeting_id":188,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[],"actions":[]},"share":[{"id":35,"name":"Mazin F","email":"Mazin@ijtimaati.com","role_id":1,"phone":"97038101","birthdate":"1981-08-22","team":3,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","status":1,"position":"IT Support","two_auth":"1","verification_code":null,"team_name":"Ijtimaati Team","role_name":"Organization Admins","pivot":{"type_id":33,"user_id":35},"committee":{"id":3,"name":"Ijtimaati Team","description":"This is Ijtimaati team","created_at":"2021-09-12T20:48:40.000000Z","updated_at":"2021-11-01T19:33:28.000000Z","deleted_at":null},"role":{"id":1,"name":"Organization Admins","slug":"admin","created_at":"2021-09-12T17:52:27.000000Z","updated_at":"2021-09-12T17:52:27.000000Z"}},{"id":3,"name":"saeed saleh","email":"said.sale7@gmail.com","role_id":null,"phone":"01552363216422","birthdate":"1981-08-25","team":3,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","status":1,"position":null,"two_auth":"1","verification_code":null,"team_name":"Ijtimaati Team","role_name":"","pivot":{"type_id":33,"user_id":3},"committee":{"id":3,"name":"Ijtimaati Team","description":"This is Ijtimaati team","created_at":"2021-09-12T20:48:40.000000Z","updated_at":"2021-11-01T19:33:28.000000Z","deleted_at":null},"role":null},{"id":3,"name":"saeed saleh","email":"said.sale7@gmail.com","role_id":null,"phone":"01552363216422","birthdate":"1981-08-25","team":3,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","status":1,"position":null,"two_auth":"1","verification_code":null,"team_name":"Ijtimaati Team","role_name":"","pivot":{"type_id":33,"user_id":3},"committee":{"id":3,"name":"Ijtimaati Team","description":"This is Ijtimaati team","created_at":"2021-09-12T20:48:40.000000Z","updated_at":"2021-11-01T19:33:28.000000Z","deleted_at":null},"role":null},{"id":3,"name":"saeed saleh","email":"said.sale7@gmail.com","role_id":null,"phone":"01552363216422","birthdate":"1981-08-25","team":3,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","status":1,"position":null,"two_auth":"1","verification_code":null,"team_name":"Ijtimaati Team","role_name":"","pivot":{"type_id":33,"user_id":3},"committee":{"id":3,"name":"Ijtimaati Team","description":"This is Ijtimaati team","created_at":"2021-09-12T20:48:40.000000Z","updated_at":"2021-11-01T19:33:28.000000Z","deleted_at":null},"role":null}],"fav":[],"talkingpoints":[{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":33,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":32,"meeting_id":47,"creator_id":21,"title":"Sales and Marketing Status","duration":60,"description":"Last Year Target","order":0,"laravel_through_key":33,"meeting":{"id":47,"title":"Steering Committee Meeting","owner_id":35,"committee_id":3,"description":"Steering Committee Meeting 32","start_date":"2021-12-07 06:00:00","duration":60,"location":"Meeting room","meeting_status_id":2,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Ahmed Zaid change meeting status to Scheduled 2021-12-13 17:56:05","current_member":{"id":111,"meeting_id":47,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":149,"meeting_id":47,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Not going","status_reason":"ssssssss","user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":111,"meeting_id":47,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":303,"meeting_id":47,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":306,"meeting_id":47,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":304,"meeting_id":47,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":305,"meeting_id":47,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":33,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":90,"meeting_id":188,"creator_id":21,"title":"q1","duration":60,"description":"tt","order":0,"laravel_through_key":33,"meeting":{"id":188,"title":"test","owner_id":21,"committee_id":3,"description":"","start_date":"2021-12-14 11:21:00","duration":60,"location":null,"meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Abdullah change attendance status to Going 2021-12-13 10:35:01","current_member":{"id":430,"meeting_id":188,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":429,"meeting_id":188,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":430,"meeting_id":188,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":419,"meeting_id":188,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":420,"meeting_id":188,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":431,"meeting_id":188,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":"Manager","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":421,"meeting_id":188,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":422,"meeting_id":188,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":423,"meeting_id":188,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":424,"meeting_id":188,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":432,"meeting_id":188,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":425,"meeting_id":188,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":426,"meeting_id":188,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":427,"meeting_id":188,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":428,"meeting_id":188,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[],"actions":[]},{"id":72,"user_id":21,"library_category_id":null,"name":"pdf.pdf","type":"application/pdf","created_at":"2021-11-24T06:24:30.000000Z","updated_at":"2021-11-24T06:24:30.000000Z","file_url":"http://test.app.ijtimaati.com/api/public/uploads/library/1637735070830163.pdf","size":"1.09 KB","used_in":{"talkingpoints":[],"decisions":[],"actions":[]},"share":[],"fav":[],"talkingpoints":[],"decisions":[],"actions":[]},{"id":82,"user_id":21,"library_category_id":null,"name":"word.docx","type":"application/vnd.openxmlformats-officedocument.wordprocessingml.document","created_at":"2021-11-26T19:42:06.000000Z","updated_at":"2021-11-26T19:42:06.000000Z","file_url":"http://test.app.ijtimaati.com/api/public/uploads/library/1637955726347277.docx","size":"2.00 B","used_in":{"talkingpoints":[],"decisions":[],"actions":[{"id":17,"meeting_id":63,"creator_id":21,"title":"induction program","open_till":"2021-11-02 09:32:41","priority":"High","description":"introduce kpi's","order":0,"laravel_through_key":82,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}]},"share":[],"fav":[{"id":48,"user_id":21,"type":"file","type_id":82,"created_at":"2021-11-26T19:42:32.000000Z","updated_at":"2021-11-26T19:42:32.000000Z"}],"talkingpoints":[],"decisions":[],"actions":[{"id":17,"meeting_id":63,"creator_id":21,"title":"induction program","open_till":"2021-11-02 09:32:41","priority":"High","description":"introduce kpi's","order":0,"laravel_through_key":82,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}]},{"id":83,"user_id":21,"library_category_id":null,"name":"pdf.pdf","type":"application/pdf","created_at":"2021-11-26T19:52:14.000000Z","updated_at":"2021-11-26T19:52:14.000000Z","file_url":"http://test.app.ijtimaati.com/api/public/uploads/library/1637956334962609.pdf","size":"1.09 KB","used_in":{"talkingpoints":[],"decisions":[],"actions":[]},"share":[],"fav":[],"talkingpoints":[],"decisions":[],"actions":[]},{"id":84,"user_id":21,"library_category_id":null,"name":"word.docx","type":"application/vnd.openxmlformats-officedocument.wordprocessingml.document","created_at":"2021-11-26T19:55:59.000000Z","updated_at":"2021-11-26T19:55:59.000000Z","file_url":"http://test.app.ijtimaati.com/api/public/uploads/library/1637956559257447.docx","size":"2.00 B","used_in":{"talkingpoints":[{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":84,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[],"actions":[]},"share":[],"fav":[],"talkingpoints":[{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":84,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[],"actions":[]},{"id":85,"user_id":21,"library_category_id":null,"name":"powerpoint.pot","type":"application/vnd.ms-powerpoint","created_at":"2021-11-26T20:29:13.000000Z","updated_at":"2021-11-26T20:29:13.000000Z","file_url":"http://test.app.ijtimaati.com/api/public/uploads/library/1637958553902755.pot","size":"2.00 B","used_in":{"talkingpoints":[],"decisions":[],"actions":[]},"share":[],"fav":[],"talkingpoints":[],"decisions":[],"actions":[]},{"id":92,"user_id":21,"library_category_id":null,"name":"file-sample_100kB.doc","type":"application/msword","created_at":"2021-12-05T17:12:20.000000Z","updated_at":"2021-12-05T17:12:20.000000Z","file_url":"http://test.app.ijtimaati.com/api/public/uploads/library/1638724340412031.doc","size":"98.00 KB","used_in":{"talkingpoints":[{"id":83,"meeting_id":160,"creator_id":21,"title":"point 1","duration":120,"description":"point 1 description","order":0,"laravel_through_key":92,"meeting":{"id":160,"title":"Testing team meeting","owner_id":21,"committee_id":23,"description":"Testing team meeting","start_date":"2021-12-06 23:08:00","duration":1320,"location":null,"meeting_status_id":2,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":"Ahmed Zaid Update this meeting 2021-12-06 21:59:27","current_member":null,"members":[{"id":353,"meeting_id":160,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":351,"meeting_id":160,"user_id":41,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":null,"type":"Admin"},{"id":352,"meeting_id":160,"user_id":78,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mohamed ismail","email":"mohamedismail120827@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[],"actions":[]},"share":[],"fav":[],"talkingpoints":[{"id":83,"meeting_id":160,"creator_id":21,"title":"point 1","duration":120,"description":"point 1 description","order":0,"laravel_through_key":92,"meeting":{"id":160,"title":"Testing team meeting","owner_id":21,"committee_id":23,"description":"Testing team meeting","start_date":"2021-12-06 23:08:00","duration":1320,"location":null,"meeting_status_id":2,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":"Ahmed Zaid Update this meeting 2021-12-06 21:59:27","current_member":null,"members":[{"id":353,"meeting_id":160,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":351,"meeting_id":160,"user_id":41,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":null,"type":"Admin"},{"id":352,"meeting_id":160,"user_id":78,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mohamed ismail","email":"mohamedismail120827@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[],"actions":[]}]

class LibaryResponseModel {
  List<LibaryDirs> _dirs;
  List<LibaryFiles> _files;

  List<LibaryDirs> get dirs => _dirs;
  List<LibaryFiles> get files => _files;

  LibaryResponseModel({
      List<LibaryDirs> dirs,
      List<LibaryFiles> files}){
    _dirs = dirs;
    _files = files;
}

  LibaryResponseModel.fromJson(dynamic json) {
    if (json['dirs'] != null) {
      _dirs = [];
      json['dirs'].forEach((v) {
        _dirs.add(LibaryDirs.fromJson(v));
      });
    }
    if (json['files'] != null) {
      _files = [];
      json['files'].forEach((v) {
        _files.add(LibaryFiles.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    if (_dirs != null) {
      map['dirs'] = _dirs.map((v) => v.toJson()).toList();
    }
    if (_files != null) {
      map['files'] = _files.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 32
/// user_id : 21
/// library_category_id : null
/// name : "MyCV (2) (1) (1).pdf"
/// type : "application/pdf"
/// created_at : "2021-11-14T04:45:15.000000Z"
/// updated_at : "2021-11-23T04:29:51.000000Z"
/// file_url : "http://test.app.ijtimaati.com/api/public/uploads/library/1637641791599106."
/// size : "38.90 KB"
/// used_in : {"talkingpoints":[{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":32,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":73,"meeting_id":103,"creator_id":21,"title":"Product updates","duration":30,"description":"product updates for all solutions","order":0,"laravel_through_key":32,"meeting":{"id":103,"title":"Ibrahim test 01","owner_id":21,"committee_id":8,"description":"test","start_date":"2021-11-16 17:39:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Ibrahim change attendance status to Going 2021-11-15 17:51:19","current_member":{"id":310,"meeting_id":103,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":310,"meeting_id":103,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":313,"meeting_id":103,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":311,"meeting_id":103,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":312,"meeting_id":103,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":309,"meeting_id":103,"user_id":58,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ibrahim","email":"ibrahim@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":32,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[],"actions":[{"id":29,"meeting_id":160,"creator_id":21,"title":"title","open_till":"2021-12-05 19:14:50","priority":"Low","description":null,"order":0,"laravel_through_key":32,"meeting":{"id":160,"title":"Testing team meeting","owner_id":21,"committee_id":23,"description":"Testing team meeting","start_date":"2021-12-06 23:08:00","duration":1320,"location":null,"meeting_status_id":2,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":"Ahmed Zaid Update this meeting 2021-12-06 21:59:27","current_member":null,"members":[{"id":353,"meeting_id":160,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":351,"meeting_id":160,"user_id":41,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":null,"type":"Admin"},{"id":352,"meeting_id":160,"user_id":78,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mohamed ismail","email":"mohamedismail120827@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}]}
/// share : [{"id":35,"name":"Mazin F","email":"Mazin@ijtimaati.com","role_id":1,"phone":"97038101","birthdate":"1981-08-22","team":3,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","status":1,"position":"IT Support","two_auth":"1","verification_code":null,"team_name":"Ijtimaati Team","role_name":"Organization Admins","pivot":{"type_id":32,"user_id":35},"committee":{"id":3,"name":"Ijtimaati Team","description":"This is Ijtimaati team","created_at":"2021-09-12T20:48:40.000000Z","updated_at":"2021-11-01T19:33:28.000000Z","deleted_at":null},"role":{"id":1,"name":"Organization Admins","slug":"admin","created_at":"2021-09-12T17:52:27.000000Z","updated_at":"2021-09-12T17:52:27.000000Z"}},{"id":35,"name":"Mazin F","email":"Mazin@ijtimaati.com","role_id":1,"phone":"97038101","birthdate":"1981-08-22","team":3,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","status":1,"position":"IT Support","two_auth":"1","verification_code":null,"team_name":"Ijtimaati Team","role_name":"Organization Admins","pivot":{"type_id":32,"user_id":35},"committee":{"id":3,"name":"Ijtimaati Team","description":"This is Ijtimaati team","created_at":"2021-09-12T20:48:40.000000Z","updated_at":"2021-11-01T19:33:28.000000Z","deleted_at":null},"role":{"id":1,"name":"Organization Admins","slug":"admin","created_at":"2021-09-12T17:52:27.000000Z","updated_at":"2021-09-12T17:52:27.000000Z"}},{"id":35,"name":"Mazin F","email":"Mazin@ijtimaati.com","role_id":1,"phone":"97038101","birthdate":"1981-08-22","team":3,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","status":1,"position":"IT Support","two_auth":"1","verification_code":null,"team_name":"Ijtimaati Team","role_name":"Organization Admins","pivot":{"type_id":32,"user_id":35},"committee":{"id":3,"name":"Ijtimaati Team","description":"This is Ijtimaati team","created_at":"2021-09-12T20:48:40.000000Z","updated_at":"2021-11-01T19:33:28.000000Z","deleted_at":null},"role":{"id":1,"name":"Organization Admins","slug":"admin","created_at":"2021-09-12T17:52:27.000000Z","updated_at":"2021-09-12T17:52:27.000000Z"}},{"id":35,"name":"Mazin F","email":"Mazin@ijtimaati.com","role_id":1,"phone":"97038101","birthdate":"1981-08-22","team":3,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","status":1,"position":"IT Support","two_auth":"1","verification_code":null,"team_name":"Ijtimaati Team","role_name":"Organization Admins","pivot":{"type_id":32,"user_id":35},"committee":{"id":3,"name":"Ijtimaati Team","description":"This is Ijtimaati team","created_at":"2021-09-12T20:48:40.000000Z","updated_at":"2021-11-01T19:33:28.000000Z","deleted_at":null},"role":{"id":1,"name":"Organization Admins","slug":"admin","created_at":"2021-09-12T17:52:27.000000Z","updated_at":"2021-09-12T17:52:27.000000Z"}},{"id":35,"name":"Mazin F","email":"Mazin@ijtimaati.com","role_id":1,"phone":"97038101","birthdate":"1981-08-22","team":3,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","status":1,"position":"IT Support","two_auth":"1","verification_code":null,"team_name":"Ijtimaati Team","role_name":"Organization Admins","pivot":{"type_id":32,"user_id":35},"committee":{"id":3,"name":"Ijtimaati Team","description":"This is Ijtimaati team","created_at":"2021-09-12T20:48:40.000000Z","updated_at":"2021-11-01T19:33:28.000000Z","deleted_at":null},"role":{"id":1,"name":"Organization Admins","slug":"admin","created_at":"2021-09-12T17:52:27.000000Z","updated_at":"2021-09-12T17:52:27.000000Z"}}]
/// fav : []
/// talkingpoints : [{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":32,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":73,"meeting_id":103,"creator_id":21,"title":"Product updates","duration":30,"description":"product updates for all solutions","order":0,"laravel_through_key":32,"meeting":{"id":103,"title":"Ibrahim test 01","owner_id":21,"committee_id":8,"description":"test","start_date":"2021-11-16 17:39:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Ibrahim change attendance status to Going 2021-11-15 17:51:19","current_member":{"id":310,"meeting_id":103,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":310,"meeting_id":103,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":313,"meeting_id":103,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":311,"meeting_id":103,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":312,"meeting_id":103,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":309,"meeting_id":103,"user_id":58,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ibrahim","email":"ibrahim@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":32,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}]
/// decisions : []
/// actions : [{"id":29,"meeting_id":160,"creator_id":21,"title":"title","open_till":"2021-12-05 19:14:50","priority":"Low","description":null,"order":0,"laravel_through_key":32,"meeting":{"id":160,"title":"Testing team meeting","owner_id":21,"committee_id":23,"description":"Testing team meeting","start_date":"2021-12-06 23:08:00","duration":1320,"location":null,"meeting_status_id":2,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":"Ahmed Zaid Update this meeting 2021-12-06 21:59:27","current_member":null,"members":[{"id":353,"meeting_id":160,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":351,"meeting_id":160,"user_id":41,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":null,"type":"Admin"},{"id":352,"meeting_id":160,"user_id":78,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mohamed ismail","email":"mohamedismail120827@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}]

class LibaryFiles {
  int _id;
  int _userId;
  dynamic _libraryCategoryId;
  String _name;
  String _type;
  String _createdAt;
  String _updatedAt;
  String _fileUrl;
  String _size;
  Used_in _usedIn;
  List<Share> _share;
  List<dynamic> _fav;
  List<Talkingpoints> _talkingpoints;
  List<dynamic> _decisions;
  List<Actions> _actions;

  int get id => _id;
  int get userId => _userId;
  dynamic get libraryCategoryId => _libraryCategoryId;
  String get name => _name;
  String get type => _type;
  String get createdAt => _createdAt;
  String get updatedAt => _updatedAt;
  String get fileUrl => _fileUrl;
  String get size => _size;
  Used_in get usedIn => _usedIn;
  List<Share> get share => _share;
  List<dynamic> get fav => _fav;
  List<Talkingpoints> get talkingpoints => _talkingpoints;
  List<dynamic> get decisions => _decisions;
  List<Actions> get actions => _actions;

  LibaryFiles({
      int id, 
      int userId, 
      dynamic libraryCategoryId, 
      String name, 
      String type, 
      String createdAt, 
      String updatedAt, 
      String fileUrl, 
      String size, 
      Used_in usedIn, 
      List<Share> share, 
      List<dynamic> fav, 
      List<Talkingpoints> talkingpoints, 
      List<dynamic> decisions, 
      List<Actions> actions}){
    _id = id;
    _userId = userId;
    _libraryCategoryId = libraryCategoryId;
    _name = name;
    _type = type;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
    _fileUrl = fileUrl;
    _size = size;
    _usedIn = usedIn;
    _share = share;
    _fav = fav;
    _talkingpoints = talkingpoints;
    _decisions = decisions;
    _actions = actions;
}

  LibaryFiles.fromJson(dynamic json) {
    _id = json['id'];
    _userId = json['user_id'];
    _libraryCategoryId = json['library_category_id'];
    _name = json['name'];
    _type = json['type'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
    _fileUrl = json['file_url'];
    _size = json['size'];
    _usedIn = json['used_in'] != null ? Used_in.fromJson(json['used_in']) : null;
    if (json['share'] != null) {
      _share = [];
      json['share'].forEach((v) {
        _share.add(Share.fromJson(v));
      });
    }
    if (json['fav'] != null) {
      _fav = [];
      json['fav'].forEach((v) {
        // _fav.add(dynamic.fromJson(v));
      });
    }
    if (json['talkingpoints'] != null) {
      _talkingpoints = [];
      json['talkingpoints'].forEach((v) {
        _talkingpoints.add(Talkingpoints.fromJson(v));
      });
    }
    if (json['decisions'] != null) {
      _decisions = [];
      json['decisions'].forEach((v) {
        // _decisions.add(dynamic.fromJson(v));
      });
    }
    if (json['actions'] != null) {
      _actions = [];
      json['actions'].forEach((v) {
        _actions.add(Actions.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['user_id'] = _userId;
    map['library_category_id'] = _libraryCategoryId;
    map['name'] = _name;
    map['type'] = _type;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    map['file_url'] = _fileUrl;
    map['size'] = _size;
    if (_usedIn != null) {
      map['used_in'] = _usedIn.toJson();
    }
    if (_share != null) {
      map['share'] = _share.map((v) => v.toJson()).toList();
    }
    if (_fav != null) {
      map['fav'] = _fav.map((v) => v.toJson()).toList();
    }
    if (_talkingpoints != null) {
      map['talkingpoints'] = _talkingpoints.map((v) => v.toJson()).toList();
    }
    if (_decisions != null) {
      map['decisions'] = _decisions.map((v) => v.toJson()).toList();
    }
    if (_actions != null) {
      map['actions'] = _actions.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 29
/// meeting_id : 160
/// creator_id : 21
/// title : "title"
/// open_till : "2021-12-05 19:14:50"
/// priority : "Low"
/// description : null
/// order : 0
/// laravel_through_key : 32
/// meeting : {"id":160,"title":"Testing team meeting","owner_id":21,"committee_id":23,"description":"Testing team meeting","start_date":"2021-12-06 23:08:00","duration":1320,"location":null,"meeting_status_id":2,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":"Ahmed Zaid Update this meeting 2021-12-06 21:59:27","current_member":null,"members":[{"id":353,"meeting_id":160,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":351,"meeting_id":160,"user_id":41,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":null,"type":"Admin"},{"id":352,"meeting_id":160,"user_id":78,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mohamed ismail","email":"mohamedismail120827@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}

class Actions {
  int _id;
  int _meetingId;
  int _creatorId;
  String _title;
  String _openTill;
  String _priority;
  dynamic _description;
  int _order;
  int _laravelThroughKey;
  Meeting _meeting;

  int get id => _id;
  int get meetingId => _meetingId;
  int get creatorId => _creatorId;
  String get title => _title;
  String get openTill => _openTill;
  String get priority => _priority;
  dynamic get description => _description;
  int get order => _order;
  int get laravelThroughKey => _laravelThroughKey;
  Meeting get meeting => _meeting;

  Actions({
      int id, 
      int meetingId, 
      int creatorId, 
      String title, 
      String openTill, 
      String priority, 
      dynamic description, 
      int order, 
      int laravelThroughKey, 
      Meeting meeting}){
    _id = id;
    _meetingId = meetingId;
    _creatorId = creatorId;
    _title = title;
    _openTill = openTill;
    _priority = priority;
    _description = description;
    _order = order;
    _laravelThroughKey = laravelThroughKey;
    _meeting = meeting;
}

  Actions.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _creatorId = json['creator_id'];
    _title = json['title'];
    _openTill = json['open_till'];
    _priority = json['priority'];
    _description = json['description'];
    _order = json['order'];
    _laravelThroughKey = json['laravel_through_key'];
    _meeting = json['meeting'] != null ? Meeting.fromJson(json['meeting']) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['creator_id'] = _creatorId;
    map['title'] = _title;
    map['open_till'] = _openTill;
    map['priority'] = _priority;
    map['description'] = _description;
    map['order'] = _order;
    map['laravel_through_key'] = _laravelThroughKey;
    if (_meeting != null) {
      map['meeting'] = _meeting.toJson();
    }
    return map;
  }

}

/// id : 160
/// title : "Testing team meeting"
/// owner_id : 21
/// committee_id : 23
/// description : "Testing team meeting"
/// start_date : "2021-12-06 23:08:00"
/// duration : 1320
/// location : null
/// meeting_status_id : 2
/// virtual : 1
/// order : "TalkingPoints,Decisions,Actions"
/// attendance_status : null
/// last_activity : "Ahmed Zaid Update this meeting 2021-12-06 21:59:27"
/// current_member : null
/// members : [{"id":353,"meeting_id":160,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":351,"meeting_id":160,"user_id":41,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":null,"type":"Admin"},{"id":352,"meeting_id":160,"user_id":78,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mohamed ismail","email":"mohamedismail120827@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Meeting {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  dynamic _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _attendanceStatus;
  String _lastActivity;
  dynamic _currentMember;
  List<Members> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  dynamic get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  dynamic get currentMember => _currentMember;
  List<Members> get members => _members;

  Meeting({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      dynamic location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic attendanceStatus, 
      String lastActivity, 
      dynamic currentMember, 
      List<Members> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Meeting.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'];
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(Members.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    map['current_member'] = _currentMember;
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 353
/// meeting_id : 160
/// user_id : 34
/// user_email : null
/// can_edit : 1
/// attendance_status : "Going"
/// status_reason : null
/// user : {"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null}
/// type : "Editor"

class Members {
  int _id;
  int _meetingId;
  int _userId;
  dynamic _userEmail;
  int _canEdit;
  String _attendanceStatus;
  dynamic _statusReason;
  User _user;
  String _type;

  int get id => _id;
  int get meetingId => _meetingId;
  int get userId => _userId;
  dynamic get userEmail => _userEmail;
  int get canEdit => _canEdit;
  String get attendanceStatus => _attendanceStatus;
  dynamic get statusReason => _statusReason;
  User get user => _user;
  String get type => _type;

  Members({
      int id, 
      int meetingId, 
      int userId, 
      dynamic userEmail, 
      int canEdit, 
      String attendanceStatus, 
      dynamic statusReason, 
      User user, 
      String type}){
    _id = id;
    _meetingId = meetingId;
    _userId = userId;
    _userEmail = userEmail;
    _canEdit = canEdit;
    _attendanceStatus = attendanceStatus;
    _statusReason = statusReason;
    _user = user;
    _type = type;
}

  Members.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _userId = json['user_id'];
    _userEmail = json['user_email'];
    _canEdit = json['can_edit'];
    _attendanceStatus = json['attendance_status'];
    _statusReason = json['status_reason'];
    _user = json['user'] != null ? User.fromJson(json['user']) : null;
    _type = json['type'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['user_id'] = _userId;
    map['user_email'] = _userEmail;
    map['can_edit'] = _canEdit;
    map['attendance_status'] = _attendanceStatus;
    map['status_reason'] = _statusReason;
    if (_user != null) {
      map['user'] = _user.toJson();
    }
    map['type'] = _type;
    return map;
  }

}

/// name : "Mohammed Tarek"
/// email : "mohammed94.turki@gmail.com"
/// image : "http://test.app.ijtimaati.com/api/public/avatar.png"
/// position : null
/// team_name : ""
/// role_name : ""
/// committee : null
/// role : null

class User {
  String _name;
  String _email;
  String _image;
  dynamic _position;
  String _teamName;
  String _roleName;
  dynamic _committee;
  dynamic _role;

  String get name => _name;
  String get email => _email;
  String get image => _image;
  dynamic get position => _position;
  String get teamName => _teamName;
  String get roleName => _roleName;
  dynamic get committee => _committee;
  dynamic get role => _role;

  User({
      String name, 
      String email, 
      String image, 
      dynamic position, 
      String teamName, 
      String roleName, 
      dynamic committee, 
      dynamic role}){
    _name = name;
    _email = email;
    _image = image;
    _position = position;
    _teamName = teamName;
    _roleName = roleName;
    _committee = committee;
    _role = role;
}

  User.fromJson(dynamic json) {
    _name = json['name'];
    _email = json['email'];
    _image = json['image'];
    _position = json['position'];
    _teamName = json['team_name'];
    _roleName = json['role_name'];
    _committee = json['committee'];
    _role = json['role'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['name'] = _name;
    map['email'] = _email;
    map['image'] = _image;
    map['position'] = _position;
    map['team_name'] = _teamName;
    map['role_name'] = _roleName;
    map['committee'] = _committee;
    map['role'] = _role;
    return map;
  }

}

/// id : 35
/// meeting_id : 63
/// creator_id : 21
/// title : "IT Presentation"
/// duration : 60
/// description : "test"
/// order : 0
/// laravel_through_key : 32
/// meeting : {"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}

class Talkingpoints {
  int _id;
  int _meetingId;
  int _creatorId;
  String _title;
  int _duration;
  String _description;
  int _order;
  int _laravelThroughKey;
  Meeting _meeting;

  int get id => _id;
  int get meetingId => _meetingId;
  int get creatorId => _creatorId;
  String get title => _title;
  int get duration => _duration;
  String get description => _description;
  int get order => _order;
  int get laravelThroughKey => _laravelThroughKey;
  Meeting get meeting => _meeting;

  Talkingpoints({
      int id, 
      int meetingId, 
      int creatorId, 
      String title, 
      int duration, 
      String description, 
      int order, 
      int laravelThroughKey, 
      Meeting meeting}){
    _id = id;
    _meetingId = meetingId;
    _creatorId = creatorId;
    _title = title;
    _duration = duration;
    _description = description;
    _order = order;
    _laravelThroughKey = laravelThroughKey;
    _meeting = meeting;
}

  Talkingpoints.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _creatorId = json['creator_id'];
    _title = json['title'];
    _duration = json['duration'];
    _description = json['description'];
    _order = json['order'];
    _laravelThroughKey = json['laravel_through_key'];
    _meeting = json['meeting'] != null ? Meeting.fromJson(json['meeting']) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['creator_id'] = _creatorId;
    map['title'] = _title;
    map['duration'] = _duration;
    map['description'] = _description;
    map['order'] = _order;
    map['laravel_through_key'] = _laravelThroughKey;
    if (_meeting != null) {
      map['meeting'] = _meeting.toJson();
    }
    return map;
  }

}


/// id : 166
/// meeting_id : 63
/// user_id : 21
/// user_email : ""
/// can_edit : 0
/// attendance_status : "Going"
/// status_reason : null
/// user : {"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null}
/// type : "Viewer"

class Current_member {
  int _id;
  int _meetingId;
  int _userId;
  String _userEmail;
  int _canEdit;
  String _attendanceStatus;
  dynamic _statusReason;
  User _user;
  String _type;

  int get id => _id;
  int get meetingId => _meetingId;
  int get userId => _userId;
  String get userEmail => _userEmail;
  int get canEdit => _canEdit;
  String get attendanceStatus => _attendanceStatus;
  dynamic get statusReason => _statusReason;
  User get user => _user;
  String get type => _type;

  Current_member({
      int id, 
      int meetingId, 
      int userId, 
      String userEmail, 
      int canEdit, 
      String attendanceStatus, 
      dynamic statusReason, 
      User user, 
      String type}){
    _id = id;
    _meetingId = meetingId;
    _userId = userId;
    _userEmail = userEmail;
    _canEdit = canEdit;
    _attendanceStatus = attendanceStatus;
    _statusReason = statusReason;
    _user = user;
    _type = type;
}

  Current_member.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _userId = json['user_id'];
    _userEmail = json['user_email'];
    _canEdit = json['can_edit'];
    _attendanceStatus = json['attendance_status'];
    _statusReason = json['status_reason'];
    _user = json['user'] != null ? User.fromJson(json['user']) : null;
    _type = json['type'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['user_id'] = _userId;
    map['user_email'] = _userEmail;
    map['can_edit'] = _canEdit;
    map['attendance_status'] = _attendanceStatus;
    map['status_reason'] = _statusReason;
    if (_user != null) {
      map['user'] = _user.toJson();
    }
    map['type'] = _type;
    return map;
  }

}



/// id : 35
/// name : "Mazin F"
/// email : "Mazin@ijtimaati.com"
/// role_id : 1
/// phone : "97038101"
/// birthdate : "1981-08-22"
/// team : 3
/// image : "http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg"
/// status : 1
/// position : "IT Support"
/// two_auth : "1"
/// verification_code : null
/// team_name : "Ijtimaati Team"
/// role_name : "Organization Admins"
/// pivot : {"type_id":32,"user_id":35}
/// committee : {"id":3,"name":"Ijtimaati Team","description":"This is Ijtimaati team","created_at":"2021-09-12T20:48:40.000000Z","updated_at":"2021-11-01T19:33:28.000000Z","deleted_at":null}
/// role : {"id":1,"name":"Organization Admins","slug":"admin","created_at":"2021-09-12T17:52:27.000000Z","updated_at":"2021-09-12T17:52:27.000000Z"}

class Share {
  int _id;
  String _name;
  String _email;
  int _roleId;
  String _phone;
  String _birthdate;
  int _team;
  String _image;
  int _status;
  String _position;
  String _twoAuth;
  dynamic _verificationCode;
  String _teamName;
  String _roleName;
  Pivot _pivot;
  Committee _committee;
  Role _role;

  int get id => _id;
  String get name => _name;
  String get email => _email;
  int get roleId => _roleId;
  String get phone => _phone;
  String get birthdate => _birthdate;
  int get team => _team;
  String get image => _image;
  int get status => _status;
  String get position => _position;
  String get twoAuth => _twoAuth;
  dynamic get verificationCode => _verificationCode;
  String get teamName => _teamName;
  String get roleName => _roleName;
  Pivot get pivot => _pivot;
  Committee get committee => _committee;
  Role get role => _role;

  Share({
      int id, 
      String name, 
      String email, 
      int roleId, 
      String phone, 
      String birthdate, 
      int team, 
      String image, 
      int status, 
      String position, 
      String twoAuth, 
      dynamic verificationCode, 
      String teamName, 
      String roleName, 
      Pivot pivot, 
      Committee committee, 
      Role role}){
    _id = id;
    _name = name;
    _email = email;
    _roleId = roleId;
    _phone = phone;
    _birthdate = birthdate;
    _team = team;
    _image = image;
    _status = status;
    _position = position;
    _twoAuth = twoAuth;
    _verificationCode = verificationCode;
    _teamName = teamName;
    _roleName = roleName;
    _pivot = pivot;
    _committee = committee;
    _role = role;
}

  Share.fromJson(dynamic json) {
    _id = json['id'];
    _name = json['name'];
    _email = json['email'];
    _roleId = json['role_id'];
    _phone = json['phone'];
    _birthdate = json['birthdate'];
    _team = json['team'];
    _image = json['image'];
    _status = json['status'];
    _position = json['position'];
    _twoAuth = json['two_auth'];
    _verificationCode = json['verification_code'];
    _teamName = json['team_name'];
    _roleName = json['role_name'];
    _pivot = json['pivot'] != null ? Pivot.fromJson(json['pivot']) : null;
    _committee = json['committee'] != null ? Committee.fromJson(json['committee']) : null;
    _role = json['role'] != null ? Role.fromJson(json['role']) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['name'] = _name;
    map['email'] = _email;
    map['role_id'] = _roleId;
    map['phone'] = _phone;
    map['birthdate'] = _birthdate;
    map['team'] = _team;
    map['image'] = _image;
    map['status'] = _status;
    map['position'] = _position;
    map['two_auth'] = _twoAuth;
    map['verification_code'] = _verificationCode;
    map['team_name'] = _teamName;
    map['role_name'] = _roleName;
    if (_pivot != null) {
      map['pivot'] = _pivot.toJson();
    }
    if (_committee != null) {
      map['committee'] = _committee.toJson();
    }
    if (_role != null) {
      map['role'] = _role.toJson();
    }
    return map;
  }

}

/// id : 1
/// name : "Organization Admins"
/// slug : "admin"
/// created_at : "2021-09-12T17:52:27.000000Z"
/// updated_at : "2021-09-12T17:52:27.000000Z"

class Role {
  int _id;
  String _name;
  String _slug;
  String _createdAt;
  String _updatedAt;

  int get id => _id;
  String get name => _name;
  String get slug => _slug;
  String get createdAt => _createdAt;
  String get updatedAt => _updatedAt;

  Role({
      int id, 
      String name, 
      String slug, 
      String createdAt, 
      String updatedAt}){
    _id = id;
    _name = name;
    _slug = slug;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
}

  Role.fromJson(dynamic json) {
    _id = json['id'];
    _name = json['name'];
    _slug = json['slug'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['name'] = _name;
    map['slug'] = _slug;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    return map;
  }

}

/// id : 3
/// name : "Ijtimaati Team"
/// description : "This is Ijtimaati team"
/// created_at : "2021-09-12T20:48:40.000000Z"
/// updated_at : "2021-11-01T19:33:28.000000Z"
/// deleted_at : null

class Committee {
  int _id;
  String _name;
  String _description;
  String _createdAt;
  String _updatedAt;
  dynamic _deletedAt;

  int get id => _id;
  String get name => _name;
  String get description => _description;
  String get createdAt => _createdAt;
  String get updatedAt => _updatedAt;
  dynamic get deletedAt => _deletedAt;

  Committee({
      int id, 
      String name, 
      String description, 
      String createdAt, 
      String updatedAt, 
      dynamic deletedAt}){
    _id = id;
    _name = name;
    _description = description;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
    _deletedAt = deletedAt;
}

  Committee.fromJson(dynamic json) {
    _id = json['id'];
    _name = json['name'];
    _description = json['description'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
    _deletedAt = json['deleted_at'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['name'] = _name;
    map['description'] = _description;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    map['deleted_at'] = _deletedAt;
    return map;
  }

}

/// type_id : 32
/// user_id : 35

class Pivot {
  int _typeId;
  int _userId;

  int get typeId => _typeId;
  int get userId => _userId;

  Pivot({
      int typeId, 
      int userId}){
    _typeId = typeId;
    _userId = userId;
}

  Pivot.fromJson(dynamic json) {
    _typeId = json['type_id'];
    _userId = json['user_id'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['type_id'] = _typeId;
    map['user_id'] = _userId;
    return map;
  }

}

/// talkingpoints : [{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":32,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":73,"meeting_id":103,"creator_id":21,"title":"Product updates","duration":30,"description":"product updates for all solutions","order":0,"laravel_through_key":32,"meeting":{"id":103,"title":"Ibrahim test 01","owner_id":21,"committee_id":8,"description":"test","start_date":"2021-11-16 17:39:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Ibrahim change attendance status to Going 2021-11-15 17:51:19","current_member":{"id":310,"meeting_id":103,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":310,"meeting_id":103,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":313,"meeting_id":103,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":311,"meeting_id":103,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":312,"meeting_id":103,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":309,"meeting_id":103,"user_id":58,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ibrahim","email":"ibrahim@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}},{"id":35,"meeting_id":63,"creator_id":21,"title":"IT Presentation","duration":60,"description":"test","order":0,"laravel_through_key":32,"meeting":{"id":63,"title":"IT Meeting","owner_id":21,"committee_id":23,"description":"IT","start_date":"2021-11-18 01:19:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Going","last_activity":"Ahmed Zaid update action induction program 2021-12-13 11:39:37","current_member":{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":166,"meeting_id":63,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":162,"meeting_id":63,"user_id":22,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":163,"meeting_id":63,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":164,"meeting_id":63,"user_id":37,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":165,"meeting_id":63,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":181,"meeting_id":63,"user_id":45,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":167,"meeting_id":63,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":335,"meeting_id":63,"user_id":59,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Abdullah","email":"abdullah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}]
/// decisions : []
/// actions : [{"id":29,"meeting_id":160,"creator_id":21,"title":"title","open_till":"2021-12-05 19:14:50","priority":"Low","description":null,"order":0,"laravel_through_key":32,"meeting":{"id":160,"title":"Testing team meeting","owner_id":21,"committee_id":23,"description":"Testing team meeting","start_date":"2021-12-06 23:08:00","duration":1320,"location":null,"meeting_status_id":2,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":"Ahmed Zaid Update this meeting 2021-12-06 21:59:27","current_member":null,"members":[{"id":353,"meeting_id":160,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":351,"meeting_id":160,"user_id":41,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":null,"type":"Admin"},{"id":352,"meeting_id":160,"user_id":78,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mohamed ismail","email":"mohamedismail120827@gmail.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}]

class Used_in {
  List<Talkingpoints> _talkingpoints;
  List<dynamic> _decisions;
  List<Actions> _actions;

  List<Talkingpoints> get talkingpoints => _talkingpoints;
  List<dynamic> get decisions => _decisions;
  List<Actions> get actions => _actions;

  Used_in({
      List<Talkingpoints> talkingpoints, 
      List<dynamic> decisions, 
      List<Actions> actions}){
    _talkingpoints = talkingpoints;
    _decisions = decisions;
    _actions = actions;
}

  Used_in.fromJson(dynamic json) {
    if (json['talkingpoints'] != null) {
      _talkingpoints = [];
      json['talkingpoints'].forEach((v) {
        _talkingpoints.add(Talkingpoints.fromJson(v));
      });
    }
    if (json['decisions'] != null) {
      _decisions = [];
      json['decisions'].forEach((v) {
        // _decisions.add(dynamic.fromJson(v));
      });
    }
    if (json['actions'] != null) {
      _actions = [];
      json['actions'].forEach((v) {
        _actions.add(Actions.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    if (_talkingpoints != null) {
      map['talkingpoints'] = _talkingpoints.map((v) => v.toJson()).toList();
    }
    if (_decisions != null) {
      map['decisions'] = _decisions.map((v) => v.toJson()).toList();
    }
    if (_actions != null) {
      map['actions'] = _actions.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 8
/// user_id : 21
/// name : "my"
/// parent_id : null
/// created_at : "2021-11-09T07:47:59.000000Z"
/// updated_at : "2021-11-09T07:47:59.000000Z"
/// dirs : [{"id":10,"user_id":21,"name":"test 1","parent_id":8,"created_at":"2021-11-11T00:11:44.000000Z","updated_at":"2021-11-11T00:11:44.000000Z","dirs":[],"files":[{"id":10,"user_id":21,"library_category_id":10,"name":"my.pdf","type":"application/pdf","created_at":"2021-11-08T04:49:16.000000Z","updated_at":"2021-11-13T16:26:29.000000Z","file_url":"http://test.app.ijtimaati.com/api/public/uploads/library/1636346956540519.pdf","size":"547.86 KB","used_in":{"talkingpoints":[{"id":41,"meeting_id":74,"creator_id":21,"title":"This is Test","duration":60,"description":"test","order":0,"laravel_through_key":10,"meeting":{"id":74,"title":"This is Test","owner_id":21,"committee_id":3,"description":"Test","start_date":"2021-11-08 11:23:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"saeed saleh change attendance status to Maybe 2021-11-30 22:30:47","current_member":{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":213,"meeting_id":74,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":208,"meeting_id":74,"user_id":31,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":209,"meeting_id":74,"user_id":35,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":215,"meeting_id":74,"user_id":36,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":"Manager","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":210,"meeting_id":74,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":211,"meeting_id":74,"user_id":38,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":216,"meeting_id":74,"user_id":45,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Admin"},{"id":218,"meeting_id":74,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[{"id":20,"meeting_id":7,"creator_id":3,"title":"test","deadline":"2021-10-23 21:49:09","description":null,"order":0,"laravel_through_key":10,"meeting":{"id":7,"title":"Est aut illum repu","owner_id":1,"committee_id":4,"description":"Adipisci aut et exer","start_date":"2021-10-20 22:55:00","duration":210,"location":"Ullam iste asperiore","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":null,"current_member":null,"members":[]}}],"actions":[]},"talkingpoints":[{"id":41,"meeting_id":74,"creator_id":21,"title":"This is Test","duration":60,"description":"test","order":0,"laravel_through_key":10,"meeting":{"id":74,"title":"This is Test","owner_id":21,"committee_id":3,"description":"Test","start_date":"2021-11-08 11:23:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"saeed saleh change attendance status to Maybe 2021-11-30 22:30:47","current_member":{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":213,"meeting_id":74,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":214,"meeting_id":74,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":208,"meeting_id":74,"user_id":31,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":209,"meeting_id":74,"user_id":35,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":215,"meeting_id":74,"user_id":36,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"mahmood","email":"mahmood.alfarsi@tra.gov.om","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":"Manager","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":210,"meeting_id":74,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":211,"meeting_id":74,"user_id":38,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":216,"meeting_id":74,"user_id":45,"user_email":null,"can_edit":2,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Admin"},{"id":218,"meeting_id":74,"user_id":53,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Salim","email":"ahmed@gcntoman.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/NOaT3lwIFu.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}],"decisions":[{"id":20,"meeting_id":7,"creator_id":3,"title":"test","deadline":"2021-10-23 21:49:09","description":null,"order":0,"laravel_through_key":10,"meeting":{"id":7,"title":"Est aut illum repu","owner_id":1,"committee_id":4,"description":"Adipisci aut et exer","start_date":"2021-10-20 22:55:00","duration":210,"location":"Ullam iste asperiore","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":null,"current_member":null,"members":[]}}],"actions":[]}],"share":[],"fav":[{"id":52,"user_id":21,"type":"dir","type_id":10,"created_at":"2021-11-29T00:26:38.000000Z","updated_at":"2021-11-29T00:26:38.000000Z"}]}]
/// files : [{"id":86,"user_id":21,"library_category_id":8,"name":"powerpoint.pot","type":"application/vnd.ms-powerpoint","created_at":"2021-11-26T20:40:18.000000Z","updated_at":"2021-11-26T20:40:18.000000Z","file_url":"http://test.app.ijtimaati.com/api/public/uploads/library/1637959218975777.pot","size":"2.00 B","used_in":{"talkingpoints":[],"decisions":[],"actions":[]},"talkingpoints":[],"decisions":[],"actions":[]}]
/// share : [{"id":1,"name":"saeed saleh","email":"test@test2.ijtimaati.local","role_id":1,"phone":"011118864400","birthdate":"1981-08-20","team":23,"image":"http://test.app.ijtimaati.com/api/public/uploads/images/FaNlH2ba4c.html","status":1,"position":null,"two_auth":"1","verification_code":null,"team_name":"IT Team","role_name":"Organization Admins","pivot":{"type_id":8,"user_id":1},"committee":{"id":23,"name":"IT Team","description":"Ijtimaati","created_at":"2021-10-31T07:30:08.000000Z","updated_at":"2021-11-01T19:34:55.000000Z","deleted_at":null},"role":{"id":1,"name":"Organization Admins","slug":"admin","created_at":"2021-09-12T17:52:27.000000Z","updated_at":"2021-09-12T17:52:27.000000Z"}},{"id":34,"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","role_id":31,"phone":"123112","birthdate":"1990-01-01","team":8,"image":"http://test.app.ijtimaati.com/api/public/avatar.png","status":1,"position":null,"two_auth":"1","verification_code":null,"team_name":"Ijtimaati","role_name":"Role2","pivot":{"type_id":8,"user_id":34},"committee":{"id":8,"name":"Ijtimaati","description":"This is test","created_at":"2021-09-26T07:50:11.000000Z","updated_at":"2021-11-01T06:40:45.000000Z","deleted_at":null},"role":{"id":31,"name":"Role2","slug":"Role2","created_at":"2021-12-05T17:46:39.000000Z","updated_at":"2021-12-05T17:47:07.000000Z"}}]
/// fav : [{"id":30,"user_id":21,"type":"dir","type_id":8,"created_at":"2021-11-19T10:57:57.000000Z","updated_at":"2021-11-19T10:57:57.000000Z"}]

class LibaryDirs {
  int _id;
  int _userId;
  String _name;
  dynamic _parentId;
  String _createdAt;
  String _updatedAt;
  List<LibaryDirs> _dirs;
  List<LibaryFiles> _files;
  List<Share> _share;
  List<Fav> _fav;

  int get id => _id;
  int get userId => _userId;
  String get name => _name;
  dynamic get parentId => _parentId;
  String get createdAt => _createdAt;
  String get updatedAt => _updatedAt;
  List<LibaryDirs> get dirs => _dirs;
  List<LibaryFiles> get files => _files;
  List<Share> get share => _share;
  List<Fav> get fav => _fav;

  LibaryDirs({
      int id, 
      int userId, 
      String name, 
      dynamic parentId, 
      String createdAt, 
      String updatedAt, 
      List<LibaryDirs> dirs,
      List<LibaryFiles> files,
      List<Share> share, 
      List<Fav> fav}){
    _id = id;
    _userId = userId;
    _name = name;
    _parentId = parentId;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
    _dirs = dirs;
    _files = files;
    _share = share;
    _fav = fav;
}

  LibaryDirs.fromJson(dynamic json) {
    _id = json['id'];
    _userId = json['user_id'];
    _name = json['name'];
    _parentId = json['parent_id'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
    if (json['dirs'] != null) {
      _dirs = [];
      json['dirs'].forEach((v) {
        _dirs.add(LibaryDirs.fromJson(v));
      });
    }
    if (json['files'] != null) {
      _files = [];
      json['files'].forEach((v) {
        _files.add(LibaryFiles.fromJson(v));
      });
    }
    if (json['share'] != null) {
      _share = [];
      json['share'].forEach((v) {
        _share.add(Share.fromJson(v));
      });
    }
    if (json['fav'] != null) {
      _fav = [];
      json['fav'].forEach((v) {
        _fav.add(Fav.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['user_id'] = _userId;
    map['name'] = _name;
    map['parent_id'] = _parentId;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    if (_dirs != null) {
      map['dirs'] = _dirs.map((v) => v.toJson()).toList();
    }
    if (_files != null) {
      map['files'] = _files.map((v) => v.toJson()).toList();
    }
    if (_share != null) {
      map['share'] = _share.map((v) => v.toJson()).toList();
    }
    if (_fav != null) {
      map['fav'] = _fav.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 30
/// user_id : 21
/// type : "dir"
/// type_id : 8
/// created_at : "2021-11-19T10:57:57.000000Z"
/// updated_at : "2021-11-19T10:57:57.000000Z"

class Fav {
  int _id;
  int _userId;
  String _type;
  int _typeId;
  String _createdAt;
  String _updatedAt;

  int get id => _id;
  int get userId => _userId;
  String get type => _type;
  int get typeId => _typeId;
  String get createdAt => _createdAt;
  String get updatedAt => _updatedAt;

  Fav({
      int id, 
      int userId, 
      String type, 
      int typeId, 
      String createdAt, 
      String updatedAt}){
    _id = id;
    _userId = userId;
    _type = type;
    _typeId = typeId;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
}

  Fav.fromJson(dynamic json) {
    _id = json['id'];
    _userId = json['user_id'];
    _type = json['type'];
    _typeId = json['type_id'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['user_id'] = _userId;
    map['type'] = _type;
    map['type_id'] = _typeId;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    return map;
  }

}


/// id : 20
/// meeting_id : 7
/// creator_id : 3
/// title : "test"
/// deadline : "2021-10-23 21:49:09"
/// description : null
/// order : 0
/// laravel_through_key : 10
/// meeting : {"id":7,"title":"Est aut illum repu","owner_id":1,"committee_id":4,"description":"Adipisci aut et exer","start_date":"2021-10-20 22:55:00","duration":210,"location":"Ullam iste asperiore","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":null,"last_activity":null,"current_member":null,"members":[]}

class Decisions {
  int _id;
  int _meetingId;
  int _creatorId;
  String _title;
  String _deadline;
  dynamic _description;
  int _order;
  int _laravelThroughKey;
  Meeting _meeting;

  int get id => _id;
  int get meetingId => _meetingId;
  int get creatorId => _creatorId;
  String get title => _title;
  String get deadline => _deadline;
  dynamic get description => _description;
  int get order => _order;
  int get laravelThroughKey => _laravelThroughKey;
  Meeting get meeting => _meeting;

  Decisions({
      int id, 
      int meetingId, 
      int creatorId, 
      String title, 
      String deadline, 
      dynamic description, 
      int order, 
      int laravelThroughKey, 
      Meeting meeting}){
    _id = id;
    _meetingId = meetingId;
    _creatorId = creatorId;
    _title = title;
    _deadline = deadline;
    _description = description;
    _order = order;
    _laravelThroughKey = laravelThroughKey;
    _meeting = meeting;
}

  Decisions.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _creatorId = json['creator_id'];
    _title = json['title'];
    _deadline = json['deadline'];
    _description = json['description'];
    _order = json['order'];
    _laravelThroughKey = json['laravel_through_key'];
    _meeting = json['meeting'] != null ? Meeting.fromJson(json['meeting']) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['creator_id'] = _creatorId;
    map['title'] = _title;
    map['deadline'] = _deadline;
    map['description'] = _description;
    map['order'] = _order;
    map['laravel_through_key'] = _laravelThroughKey;
    if (_meeting != null) {
      map['meeting'] = _meeting.toJson();
    }
    return map;
  }

}
