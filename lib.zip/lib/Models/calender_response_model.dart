/// one : [{"id":118,"title":"Molestiae voluptates","owner_id":21,"committee_id":3,"description":"Qui at delectus lau","start_date":"2022-01-01 01:41:00","duration":60,"location":"Et magna similique e","meeting_status_id":5,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change meeting status to Archived 2021-12-27 9:38 AM","current_member":{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":575,"meeting_id":118,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":565,"meeting_id":118,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":566,"meeting_id":118,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":577,"meeting_id":118,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":567,"meeting_id":118,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":568,"meeting_id":118,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":569,"meeting_id":118,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":570,"meeting_id":118,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":571,"meeting_id":118,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":572,"meeting_id":118,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":573,"meeting_id":118,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":574,"meeting_id":118,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":119,"title":"Dolor et ut necessit","owner_id":21,"committee_id":3,"description":"Aut architecto quas","start_date":"2022-01-01 14:44:00","duration":60,"location":"Praesentium commodi","meeting_status_id":5,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change meeting status to Archived 2022-01-12 10:05 PM","current_member":{"id":860,"meeting_id":119,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":859,"meeting_id":119,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":860,"meeting_id":119,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":849,"meeting_id":119,"user_id":31,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":850,"meeting_id":119,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":861,"meeting_id":119,"user_id":36,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Editor"},{"id":851,"meeting_id":119,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":852,"meeting_id":119,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":853,"meeting_id":119,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":854,"meeting_id":119,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":855,"meeting_id":119,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":856,"meeting_id":119,"user_id":61,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":857,"meeting_id":119,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":858,"meeting_id":119,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":862,"meeting_id":119,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// two : [{"id":118,"title":"Molestiae voluptates","owner_id":21,"committee_id":3,"description":"Qui at delectus lau","start_date":"2022-01-01 01:41:00","duration":60,"location":"Et magna similique e","meeting_status_id":5,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change meeting status to Archived 2021-12-27 9:38 AM","current_member":{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":575,"meeting_id":118,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":565,"meeting_id":118,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":566,"meeting_id":118,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":577,"meeting_id":118,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":567,"meeting_id":118,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":568,"meeting_id":118,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":569,"meeting_id":118,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":570,"meeting_id":118,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":571,"meeting_id":118,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":572,"meeting_id":118,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":573,"meeting_id":118,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":574,"meeting_id":118,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":119,"title":"Dolor et ut necessit","owner_id":21,"committee_id":3,"description":"Aut architecto quas","start_date":"2022-01-01 14:44:00","duration":60,"location":"Praesentium commodi","meeting_status_id":5,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change meeting status to Archived 2022-01-12 10:05 PM","current_member":{"id":860,"meeting_id":119,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":859,"meeting_id":119,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":860,"meeting_id":119,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":849,"meeting_id":119,"user_id":31,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":850,"meeting_id":119,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":861,"meeting_id":119,"user_id":36,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Editor"},{"id":851,"meeting_id":119,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":852,"meeting_id":119,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":853,"meeting_id":119,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":854,"meeting_id":119,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":855,"meeting_id":119,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":856,"meeting_id":119,"user_id":61,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":857,"meeting_id":119,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":858,"meeting_id":119,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":862,"meeting_id":119,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// three : [{"id":242,"title":"2022","owner_id":35,"committee_id":27,"description":"","start_date":"2022-01-03 09:00:00","duration":60,"location":"Muscat","meeting_status_id":5,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Pending","last_activity":"Mazin change meeting status to Archived 2022-01-09 9:05 PM","current_member":{"id":818,"meeting_id":242,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":818,"meeting_id":242,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":819,"meeting_id":242,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":261,"title":"Meeting test 2","owner_id":21,"committee_id":8,"description":"","start_date":"2022-01-03 14:00:00","duration":60,"location":null,"meeting_status_id":4,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"zoom","attendance_status":"Going","last_activity":"Ahmed Zaid change meeting status to Cancelled 2022-01-03 3:18 PM","current_member":{"id":914,"meeting_id":261,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":914,"meeting_id":261,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":913,"meeting_id":261,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"}]}]
/// four : [{"id":213,"title":"TEST Neque nihil consequa","owner_id":21,"committee_id":3,"description":"Eaque ex quasi excep","start_date":"2022-01-04 05:15:00","duration":60,"location":"Libero quidem esse","meeting_status_id":5,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"Ahmed Zaid change meeting status to Archived 2021-12-27 9:01 AM","current_member":{"id":537,"meeting_id":213,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":536,"meeting_id":213,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":537,"meeting_id":213,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":526,"meeting_id":213,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":527,"meeting_id":213,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":538,"meeting_id":213,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":528,"meeting_id":213,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":529,"meeting_id":213,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":530,"meeting_id":213,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":531,"meeting_id":213,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":532,"meeting_id":213,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":533,"meeting_id":213,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":534,"meeting_id":213,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":535,"meeting_id":213,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":246,"title":"TESSSSST","owner_id":21,"committee_id":3,"description":"Sit magna sit qui e","start_date":"2022-01-04 12:29:00","duration":60,"location":"Distinctio Facere v","meeting_status_id":2,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"Ahmed Zaid change attendance status to Maybe 2022-01-11 8:23 PM","current_member":{"id":909,"meeting_id":246,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":890,"meeting_id":246,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":909,"meeting_id":246,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":891,"meeting_id":246,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":880,"meeting_id":246,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":881,"meeting_id":246,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":892,"meeting_id":246,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":882,"meeting_id":246,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":883,"meeting_id":246,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":884,"meeting_id":246,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":885,"meeting_id":246,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":886,"meeting_id":246,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":887,"meeting_id":246,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":888,"meeting_id":246,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":889,"meeting_id":246,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":893,"meeting_id":246,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":262,"title":"Meeting Test 1","owner_id":34,"committee_id":29,"description":"description1","start_date":"2022-01-04 12:32:00","duration":60,"location":null,"meeting_status_id":5,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Pending","last_activity":"Mohammed Tarek change meeting status to Archived 2022-01-03 3:49 PM","current_member":{"id":915,"meeting_id":262,"user_id":21,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},"members":[{"id":918,"meeting_id":262,"user_id":3,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":915,"meeting_id":262,"user_id":21,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":920,"meeting_id":262,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":916,"meeting_id":262,"user_id":34,"user_email":null,"can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":921,"meeting_id":262,"user_id":34,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":922,"meeting_id":262,"user_id":78,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"}]},{"id":263,"title":"Meeting Test 3","owner_id":21,"committee_id":3,"description":"","start_date":"2022-01-04 19:02:00","duration":60,"location":null,"meeting_status_id":5,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Going","last_activity":"Mohammed Tarek change meeting status to Archived 2022-01-03 3:49 PM","current_member":{"id":917,"meeting_id":263,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":917,"meeting_id":263,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":923,"meeting_id":263,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":"k","token":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"}]},{"id":264,"title":"Meeting Test 4","owner_id":34,"committee_id":29,"description":"","start_date":"2022-01-04 20:36:00","duration":60,"location":"Muscat","meeting_status_id":5,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"zoom","attendance_status":"Going","last_activity":"Mohammed Tarek change meeting status to Archived 2022-01-03 3:49 PM","current_member":{"id":924,"meeting_id":264,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":924,"meeting_id":264,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":925,"meeting_id":264,"user_id":34,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":267,"title":"Meeting test 6","owner_id":34,"committee_id":29,"description":"","start_date":"2022-01-04 21:52:00","duration":60,"location":null,"meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"zoom","attendance_status":"Pending","last_activity":"Mohammed Tarek change meeting status to Live 2022-01-03 3:53 PM","current_member":{"id":927,"meeting_id":267,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":927,"meeting_id":267,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":268,"title":"Meeting test 7","owner_id":21,"committee_id":8,"description":"","start_date":"2022-01-04 23:53:00","duration":60,"location":null,"meeting_status_id":5,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"zoom","attendance_status":"Pending","last_activity":"Ahmed Zaid change meeting status to Archived 2022-01-03 3:54 PM","current_member":{"id":928,"meeting_id":268,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":928,"meeting_id":268,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":929,"meeting_id":268,"user_id":34,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":269,"title":"Meeting test 8","owner_id":21,"committee_id":29,"description":"","start_date":"2022-01-04 18:54:00","duration":60,"location":null,"meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Pending","last_activity":"Ahmed Zaid change meeting status to Live 2022-01-03 3:55 PM","current_member":{"id":931,"meeting_id":269,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":931,"meeting_id":269,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":930,"meeting_id":269,"user_id":34,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// five : [{"id":120,"title":"IJMEET Non eos quis ea iure","owner_id":21,"committee_id":3,"description":"Aliquip corporis ea  Non eos quis ea iure","start_date":"2022-01-05 14:49:00","duration":60,"location":"Mollitia adipisci au","meeting_status_id":5,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Maybe","last_activity":"Ahmed Zaid change meeting status to Archived 2022-01-04 6:15 AM","current_member":{"id":965,"meeting_id":120,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":951,"meeting_id":120,"user_id":1,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"test@test2.ijtimaati.local","image":"http://test.app.ijtimaati.com/api/public/uploads/images/FaNlH2ba4c.html","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":964,"meeting_id":120,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":965,"meeting_id":120,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":953,"meeting_id":120,"user_id":22,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":954,"meeting_id":120,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":955,"meeting_id":120,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":956,"meeting_id":120,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":957,"meeting_id":120,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":958,"meeting_id":120,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":959,"meeting_id":120,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":960,"meeting_id":120,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":961,"meeting_id":120,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":952,"meeting_id":120,"user_id":64,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"jojonavocy","email":"bupypo@mailinator.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":962,"meeting_id":120,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":963,"meeting_id":120,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":876,"meeting_id":120,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":245,"title":"Rem in quae et atque","owner_id":94,"committee_id":3,"description":"Eveniet quia culpa","start_date":"2022-01-05 01:15:00","duration":60,"location":"Muscat","meeting_status_id":2,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Not going","last_activity":"Mazin change attendance status to Maybe 2022-01-13 3:45 PM","current_member":{"id":906,"meeting_id":245,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Not going","status_reason":"not going","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":905,"meeting_id":245,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":906,"meeting_id":245,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Not going","status_reason":"not going","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":895,"meeting_id":245,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":896,"meeting_id":245,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":907,"meeting_id":245,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":897,"meeting_id":245,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":898,"meeting_id":245,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":899,"meeting_id":245,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":900,"meeting_id":245,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":901,"meeting_id":245,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":902,"meeting_id":245,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":903,"meeting_id":245,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":904,"meeting_id":245,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":908,"meeting_id":245,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":271,"title":"Ijtimaati New Test","owner_id":21,"committee_id":3,"description":"Test","start_date":"2022-01-05 18:19:00","duration":60,"location":"Muscat","meeting_status_id":2,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Maybe","last_activity":"yaser samra change attendance status to Maybe 2022-01-10 11:56 AM","current_member":{"id":979,"meeting_id":271,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":978,"meeting_id":271,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":979,"meeting_id":271,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":968,"meeting_id":271,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":969,"meeting_id":271,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":970,"meeting_id":271,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":971,"meeting_id":271,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":972,"meeting_id":271,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":973,"meeting_id":271,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":974,"meeting_id":271,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":975,"meeting_id":271,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":976,"meeting_id":271,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":977,"meeting_id":271,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":980,"meeting_id":271,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":280,"title":"Test Meeting","owner_id":94,"committee_id":3,"description":"asfdvfbvc","start_date":"2022-01-05 14:04:00","duration":180,"location":"Muscat","meeting_status_id":2,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"Mazin change attendance status to Going 2022-01-12 2:24 PM","current_member":{"id":1166,"meeting_id":280,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":"d2d2492da95438a36b06133c59c33420","user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1166,"meeting_id":280,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":"d2d2492da95438a36b06133c59c33420","user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1167,"meeting_id":280,"user_id":34,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":"26a63af627e9b56b02c1e16aa35e7cdc","user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1152,"meeting_id":280,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1153,"meeting_id":280,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1154,"meeting_id":280,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1155,"meeting_id":280,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1156,"meeting_id":280,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1157,"meeting_id":280,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1158,"meeting_id":280,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1159,"meeting_id":280,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1160,"meeting_id":280,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1073,"meeting_id":280,"user_id":94,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":"b6f0390f8f3fdcbfa4572e395d8c75f7","user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1163,"meeting_id":280,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":281,"title":"new","owner_id":94,"committee_id":3,"description":"test","start_date":"2022-01-05 19:17:00","duration":60,"location":"Muscat","meeting_status_id":1,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Not going","last_activity":"Ahmed Zaid change member type to Viewer 2022-01-07 6:47 PM","current_member":{"id":1139,"meeting_id":281,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Not going","status_reason":"no reason here","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1138,"meeting_id":281,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1139,"meeting_id":281,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Not going","status_reason":"no reason here","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1137,"meeting_id":281,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1165,"meeting_id":281,"user_id":34,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":"8342d6cd1c01fe402a62270bc6fba019","user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1126,"meeting_id":281,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1127,"meeting_id":281,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1128,"meeting_id":281,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1129,"meeting_id":281,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1130,"meeting_id":281,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1131,"meeting_id":281,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1132,"meeting_id":281,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1133,"meeting_id":281,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1140,"meeting_id":281,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// sex : [{"id":161,"title":"Next month meeting","owner_id":21,"committee_id":3,"description":"Next month meeting","start_date":"2022-01-06 19:37:00","duration":60,"location":"cairo","meeting_status_id":5,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"Ahmed Zaid change meeting status to Archived 2021-12-27 9:31 AM","current_member":{"id":563,"meeting_id":161,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":562,"meeting_id":161,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":563,"meeting_id":161,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":552,"meeting_id":161,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":553,"meeting_id":161,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":564,"meeting_id":161,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":554,"meeting_id":161,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":555,"meeting_id":161,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":556,"meeting_id":161,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":557,"meeting_id":161,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":558,"meeting_id":161,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":559,"meeting_id":161,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":560,"meeting_id":161,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":561,"meeting_id":161,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":272,"title":"This is test2","owner_id":21,"committee_id":3,"description":"ihouuh","start_date":"2022-01-06 18:53:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Pending","last_activity":"Ahmed Zaid change meeting status to Live 2022-01-04 7:07 PM","current_member":{"id":992,"meeting_id":272,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":991,"meeting_id":272,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":992,"meeting_id":272,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":982,"meeting_id":272,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":983,"meeting_id":272,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":984,"meeting_id":272,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":985,"meeting_id":272,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":986,"meeting_id":272,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":987,"meeting_id":272,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":988,"meeting_id":272,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":278,"title":"Meeting 4 Jan 22","owner_id":21,"committee_id":29,"description":"","start_date":"2022-01-06 23:06:00","duration":60,"location":null,"meeting_status_id":2,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"zoom","attendance_status":"Maybe","last_activity":"Ahmed Zaid add member Mohammed Tarek 2022-01-07 6:51 PM","current_member":{"id":1097,"meeting_id":278,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1096,"meeting_id":278,"user_id":1,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"test@test2.ijtimaati.local","image":"http://test.app.ijtimaati.com/api/public/uploads/images/FaNlH2ba4c.html","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1097,"meeting_id":278,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1169,"meeting_id":278,"user_id":34,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":"7227d81abb992221630deafe88cc2df0","user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// seven : [{"id":237,"title":"Nostrud nulla volupt","owner_id":94,"committee_id":3,"description":"Soluta rem dignissim","start_date":"2022-01-07 23:15:00","duration":60,"location":"Muscat","meeting_status_id":5,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"yaser samra change meeting status to Archived 2021-12-31 1:00 AM","current_member":{"id":753,"meeting_id":237,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":752,"meeting_id":237,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":753,"meeting_id":237,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":742,"meeting_id":237,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":743,"meeting_id":237,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":754,"meeting_id":237,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":744,"meeting_id":237,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":745,"meeting_id":237,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":746,"meeting_id":237,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":747,"meeting_id":237,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":748,"meeting_id":237,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":749,"meeting_id":237,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":750,"meeting_id":237,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":751,"meeting_id":237,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":755,"meeting_id":237,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":289,"title":"test11","owner_id":21,"committee_id":3,"description":"test11","start_date":"2022-01-07 19:45:00","duration":60,"location":null,"meeting_status_id":2,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Going","last_activity":"Ahmed Zaid Update this meeting 2022-01-07 7:36 PM","current_member":{"id":1176,"meeting_id":289,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":"f3f5131b934cf53703d2d363b1115429","user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1176,"meeting_id":289,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":"f3f5131b934cf53703d2d363b1115429","user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1170,"meeting_id":289,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Pending","status_reason":null,"token":"661a161614f09e9f7d44c56913b5e027","user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"}]},{"id":290,"title":"test12345","owner_id":21,"committee_id":3,"description":"test12345","start_date":"2022-01-07 22:45:00","duration":15,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"zoom","attendance_status":"Pending","last_activity":"Ahmed Zaid change meeting status to Live 2022-01-07 7:38 PM","current_member":{"id":1173,"meeting_id":290,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":"a399a5f6b9683d50a23a040a590a22a4","user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1173,"meeting_id":290,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":"a399a5f6b9683d50a23a040a590a22a4","user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1171,"meeting_id":290,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Pending","status_reason":null,"token":"c078096672b0fdce37e005965e30c959","user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"}]}]
/// eight : [{"id":275,"title":"Meeting four","owner_id":34,"committee_id":29,"description":"","start_date":"2022-01-08 21:06:00","duration":60,"location":"Muscat","meeting_status_id":4,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Going","last_activity":"Mohammed Tarek change meeting status to Cancelled 2022-01-12 10:15 PM","current_member":{"id":1015,"meeting_id":275,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":"ddgdgfdgdf","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1015,"meeting_id":275,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":"ddgdgfdgdf","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1014,"meeting_id":275,"user_id":34,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// nine : [{"id":118,"title":"Molestiae voluptates","owner_id":21,"committee_id":3,"description":"Qui at delectus lau","start_date":"2022-01-01 01:41:00","duration":60,"location":"Et magna similique e","meeting_status_id":5,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change meeting status to Archived 2021-12-27 9:38 AM","current_member":{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":575,"meeting_id":118,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":565,"meeting_id":118,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":566,"meeting_id":118,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":577,"meeting_id":118,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":567,"meeting_id":118,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":568,"meeting_id":118,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":569,"meeting_id":118,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":570,"meeting_id":118,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":571,"meeting_id":118,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":572,"meeting_id":118,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":573,"meeting_id":118,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":574,"meeting_id":118,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":119,"title":"Dolor et ut necessit","owner_id":21,"committee_id":3,"description":"Aut architecto quas","start_date":"2022-01-01 14:44:00","duration":60,"location":"Praesentium commodi","meeting_status_id":5,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change meeting status to Archived 2022-01-12 10:05 PM","current_member":{"id":860,"meeting_id":119,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":859,"meeting_id":119,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":860,"meeting_id":119,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":849,"meeting_id":119,"user_id":31,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":850,"meeting_id":119,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":861,"meeting_id":119,"user_id":36,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Editor"},{"id":851,"meeting_id":119,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":852,"meeting_id":119,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":853,"meeting_id":119,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":854,"meeting_id":119,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":855,"meeting_id":119,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":856,"meeting_id":119,"user_id":61,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":857,"meeting_id":119,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":858,"meeting_id":119,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":862,"meeting_id":119,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// ten : [{"id":118,"title":"Molestiae voluptates","owner_id":21,"committee_id":3,"description":"Qui at delectus lau","start_date":"2022-01-01 01:41:00","duration":60,"location":"Et magna similique e","meeting_status_id":5,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change meeting status to Archived 2021-12-27 9:38 AM","current_member":{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":575,"meeting_id":118,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":565,"meeting_id":118,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":566,"meeting_id":118,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":577,"meeting_id":118,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":567,"meeting_id":118,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":568,"meeting_id":118,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":569,"meeting_id":118,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":570,"meeting_id":118,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":571,"meeting_id":118,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":572,"meeting_id":118,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":573,"meeting_id":118,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":574,"meeting_id":118,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":119,"title":"Dolor et ut necessit","owner_id":21,"committee_id":3,"description":"Aut architecto quas","start_date":"2022-01-01 14:44:00","duration":60,"location":"Praesentium commodi","meeting_status_id":5,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change meeting status to Archived 2022-01-12 10:05 PM","current_member":{"id":860,"meeting_id":119,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":859,"meeting_id":119,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":860,"meeting_id":119,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":849,"meeting_id":119,"user_id":31,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":850,"meeting_id":119,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":861,"meeting_id":119,"user_id":36,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Editor"},{"id":851,"meeting_id":119,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":852,"meeting_id":119,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":853,"meeting_id":119,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":854,"meeting_id":119,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":855,"meeting_id":119,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":856,"meeting_id":119,"user_id":61,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":857,"meeting_id":119,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":858,"meeting_id":119,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":862,"meeting_id":119,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// eleven : [{"id":211,"title":"TEST Recusandae Qui veni","owner_id":21,"committee_id":3,"description":"Explicabo Sunt sequ","start_date":"2022-01-11 04:12:00","duration":180,"location":"Esse elit quia bla","meeting_status_id":4,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change meeting status to Cancelled 2021-12-27 9:06 AM","current_member":{"id":550,"meeting_id":211,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":549,"meeting_id":211,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":550,"meeting_id":211,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":539,"meeting_id":211,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":540,"meeting_id":211,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":551,"meeting_id":211,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":541,"meeting_id":211,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":542,"meeting_id":211,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":543,"meeting_id":211,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":544,"meeting_id":211,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":545,"meeting_id":211,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":546,"meeting_id":211,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":547,"meeting_id":211,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":548,"meeting_id":211,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// tweleve : [{"id":118,"title":"Molestiae voluptates","owner_id":21,"committee_id":3,"description":"Qui at delectus lau","start_date":"2022-01-01 01:41:00","duration":60,"location":"Et magna similique e","meeting_status_id":5,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change meeting status to Archived 2021-12-27 9:38 AM","current_member":{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":575,"meeting_id":118,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":565,"meeting_id":118,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":566,"meeting_id":118,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":577,"meeting_id":118,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":567,"meeting_id":118,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":568,"meeting_id":118,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":569,"meeting_id":118,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":570,"meeting_id":118,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":571,"meeting_id":118,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":572,"meeting_id":118,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":573,"meeting_id":118,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":574,"meeting_id":118,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":119,"title":"Dolor et ut necessit","owner_id":21,"committee_id":3,"description":"Aut architecto quas","start_date":"2022-01-01 14:44:00","duration":60,"location":"Praesentium commodi","meeting_status_id":5,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change meeting status to Archived 2022-01-12 10:05 PM","current_member":{"id":860,"meeting_id":119,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":859,"meeting_id":119,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":860,"meeting_id":119,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":849,"meeting_id":119,"user_id":31,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":850,"meeting_id":119,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":861,"meeting_id":119,"user_id":36,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Editor"},{"id":851,"meeting_id":119,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":852,"meeting_id":119,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":853,"meeting_id":119,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":854,"meeting_id":119,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":855,"meeting_id":119,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":856,"meeting_id":119,"user_id":61,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":857,"meeting_id":119,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":858,"meeting_id":119,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":862,"meeting_id":119,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// thirteen : [{"id":310,"title":"test","owner_id":35,"committee_id":8,"description":"","start_date":"2022-01-13 14:15:00","duration":60,"location":"Muscat","meeting_status_id":1,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"Ahmed Zaid Update this meeting 2022-01-12 3:59 PM","current_member":{"id":1333,"meeting_id":310,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1333,"meeting_id":310,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1350,"meeting_id":310,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Pending","status_reason":null,"token":"99604848945202b2143d5fdcccab0177","user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1334,"meeting_id":310,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1335,"meeting_id":310,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":313,"title":"Draft two meet","owner_id":21,"committee_id":3,"description":"Draft two meet","start_date":"2022-01-13 19:41:00","duration":60,"location":null,"meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Going","last_activity":"Mohammed Tarek change attendance status to Going 2022-01-12 10:14 PM","current_member":{"id":1356,"meeting_id":313,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":"415e4c94bc3d868babc562b8b785383a","user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1356,"meeting_id":313,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":"415e4c94bc3d868babc562b8b785383a","user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1355,"meeting_id":313,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"token":"fc0c55d3bfa9fad2d9f9a4f72307d294","user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"}]}]
/// fourteen : [{"id":317,"title":"Ijmeet Presentation01","owner_id":21,"committee_id":3,"description":"Test","start_date":"2022-01-14 10:15:00","duration":60,"location":null,"meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"zoom","attendance_status":"Pending","last_activity":"Mazin change attendance status to Going 2022-01-13 10:29 AM","current_member":{"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1382,"meeting_id":317,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1372,"meeting_id":317,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1373,"meeting_id":317,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1374,"meeting_id":317,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1375,"meeting_id":317,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1376,"meeting_id":317,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1377,"meeting_id":317,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1378,"meeting_id":317,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1379,"meeting_id":317,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1380,"meeting_id":317,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1381,"meeting_id":317,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1384,"meeting_id":317,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// fifteen : [{"id":211,"title":"TEST Recusandae Qui veni","owner_id":21,"committee_id":3,"description":"Explicabo Sunt sequ","start_date":"2022-01-11 04:12:00","duration":180,"location":"Esse elit quia bla","meeting_status_id":4,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change meeting status to Cancelled 2021-12-27 9:06 AM","current_member":{"id":550,"meeting_id":211,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":549,"meeting_id":211,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":550,"meeting_id":211,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":539,"meeting_id":211,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":540,"meeting_id":211,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":551,"meeting_id":211,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":541,"meeting_id":211,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":542,"meeting_id":211,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":543,"meeting_id":211,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":544,"meeting_id":211,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":545,"meeting_id":211,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":546,"meeting_id":211,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":547,"meeting_id":211,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":548,"meeting_id":211,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// sixteen : [{"id":118,"title":"Molestiae voluptates","owner_id":21,"committee_id":3,"description":"Qui at delectus lau","start_date":"2022-01-01 01:41:00","duration":60,"location":"Et magna similique e","meeting_status_id":5,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change meeting status to Archived 2021-12-27 9:38 AM","current_member":{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":575,"meeting_id":118,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":565,"meeting_id":118,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":566,"meeting_id":118,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":577,"meeting_id":118,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":567,"meeting_id":118,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":568,"meeting_id":118,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":569,"meeting_id":118,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":570,"meeting_id":118,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":571,"meeting_id":118,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":572,"meeting_id":118,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":573,"meeting_id":118,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":574,"meeting_id":118,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":119,"title":"Dolor et ut necessit","owner_id":21,"committee_id":3,"description":"Aut architecto quas","start_date":"2022-01-01 14:44:00","duration":60,"location":"Praesentium commodi","meeting_status_id":5,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change meeting status to Archived 2022-01-12 10:05 PM","current_member":{"id":860,"meeting_id":119,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":859,"meeting_id":119,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":860,"meeting_id":119,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":849,"meeting_id":119,"user_id":31,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":850,"meeting_id":119,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":861,"meeting_id":119,"user_id":36,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Editor"},{"id":851,"meeting_id":119,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":852,"meeting_id":119,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":853,"meeting_id":119,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":854,"meeting_id":119,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":855,"meeting_id":119,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":856,"meeting_id":119,"user_id":61,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":857,"meeting_id":119,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":858,"meeting_id":119,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":862,"meeting_id":119,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// seventeen : [{"id":310,"title":"test","owner_id":35,"committee_id":8,"description":"","start_date":"2022-01-13 14:15:00","duration":60,"location":"Muscat","meeting_status_id":1,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"Ahmed Zaid Update this meeting 2022-01-12 3:59 PM","current_member":{"id":1333,"meeting_id":310,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1333,"meeting_id":310,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1350,"meeting_id":310,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Pending","status_reason":null,"token":"99604848945202b2143d5fdcccab0177","user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1334,"meeting_id":310,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1335,"meeting_id":310,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":313,"title":"Draft two meet","owner_id":21,"committee_id":3,"description":"Draft two meet","start_date":"2022-01-13 19:41:00","duration":60,"location":null,"meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Going","last_activity":"Mohammed Tarek change attendance status to Going 2022-01-12 10:14 PM","current_member":{"id":1356,"meeting_id":313,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":"415e4c94bc3d868babc562b8b785383a","user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1356,"meeting_id":313,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":"415e4c94bc3d868babc562b8b785383a","user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1355,"meeting_id":313,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"token":"fc0c55d3bfa9fad2d9f9a4f72307d294","user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"}]}]
/// eighteen : [{"id":317,"title":"Ijmeet Presentation01","owner_id":21,"committee_id":3,"description":"Test","start_date":"2022-01-14 10:15:00","duration":60,"location":null,"meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"zoom","attendance_status":"Pending","last_activity":"Mazin change attendance status to Going 2022-01-13 10:29 AM","current_member":{"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1382,"meeting_id":317,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1372,"meeting_id":317,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1373,"meeting_id":317,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1374,"meeting_id":317,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1375,"meeting_id":317,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1376,"meeting_id":317,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1377,"meeting_id":317,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1378,"meeting_id":317,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1379,"meeting_id":317,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1380,"meeting_id":317,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1381,"meeting_id":317,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1384,"meeting_id":317,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// nineteen : [{"id":303,"title":"test88","owner_id":21,"committee_id":3,"description":"uig","start_date":"2022-01-19 17:42:00","duration":60,"location":"Muscat","meeting_status_id":5,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"Ahmed Zaid change meeting status to Archived 2022-01-12 10:04 PM","current_member":{"id":1272,"meeting_id":303,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1271,"meeting_id":303,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1272,"meeting_id":303,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1261,"meeting_id":303,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1262,"meeting_id":303,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Not going","status_reason":"test","token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1265,"meeting_id":303,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1266,"meeting_id":303,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1267,"meeting_id":303,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1268,"meeting_id":303,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1269,"meeting_id":303,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1270,"meeting_id":303,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1273,"meeting_id":303,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":308,"title":"Eveniet itaque obca","owner_id":94,"committee_id":3,"description":"In quia tenetur ut d","start_date":"2022-01-19 07:56:00","duration":60,"location":"Sit quis atque accu","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change attendance status to Going 2022-01-12 4:06 PM","current_member":{"id":1318,"meeting_id":308,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1317,"meeting_id":308,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1318,"meeting_id":308,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1307,"meeting_id":308,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1308,"meeting_id":308,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1309,"meeting_id":308,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1310,"meeting_id":308,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1311,"meeting_id":308,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1312,"meeting_id":308,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1313,"meeting_id":308,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1314,"meeting_id":308,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1315,"meeting_id":308,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1316,"meeting_id":308,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1319,"meeting_id":308,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// tweenty : [{"id":244,"title":"test7878","owner_id":21,"committee_id":3,"description":"trsr","start_date":"2022-01-20 14:36:00","duration":240,"location":"Muscat","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Maybe","last_activity":"saeed saleh change attendance status to Going 2022-01-03 8:55 PM","current_member":{"id":845,"meeting_id":244,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":844,"meeting_id":244,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":845,"meeting_id":244,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":834,"meeting_id":244,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":835,"meeting_id":244,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":846,"meeting_id":244,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":836,"meeting_id":244,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":837,"meeting_id":244,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":838,"meeting_id":244,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":839,"meeting_id":244,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":840,"meeting_id":244,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":841,"meeting_id":244,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":842,"meeting_id":244,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":843,"meeting_id":244,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":847,"meeting_id":244,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":304,"title":"Ahmed","owner_id":35,"committee_id":29,"description":"tret","start_date":"2022-01-20 17:46:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Pending","last_activity":"Mohammed Tarek change meeting status to Live 2022-01-12 10:27 PM","current_member":{"id":1274,"meeting_id":304,"user_id":21,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},"members":[{"id":1274,"meeting_id":304,"user_id":21,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1353,"meeting_id":304,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"token":"4670d18ae1781a39e16959c60d03d2e1","user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1277,"meeting_id":304,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1275,"meeting_id":304,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1276,"meeting_id":304,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// tweenty_one : [{"id":317,"title":"Ijmeet Presentation01","owner_id":21,"committee_id":3,"description":"Test","start_date":"2022-01-14 10:15:00","duration":60,"location":null,"meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"zoom","attendance_status":"Pending","last_activity":"Mazin change attendance status to Going 2022-01-13 10:29 AM","current_member":{"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1382,"meeting_id":317,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1372,"meeting_id":317,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1373,"meeting_id":317,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1374,"meeting_id":317,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1375,"meeting_id":317,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1376,"meeting_id":317,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1377,"meeting_id":317,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1378,"meeting_id":317,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1379,"meeting_id":317,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1380,"meeting_id":317,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1381,"meeting_id":317,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1384,"meeting_id":317,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// tweenty_two : [{"id":303,"title":"test88","owner_id":21,"committee_id":3,"description":"uig","start_date":"2022-01-19 17:42:00","duration":60,"location":"Muscat","meeting_status_id":5,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"Ahmed Zaid change meeting status to Archived 2022-01-12 10:04 PM","current_member":{"id":1272,"meeting_id":303,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1271,"meeting_id":303,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1272,"meeting_id":303,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1261,"meeting_id":303,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1262,"meeting_id":303,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Not going","status_reason":"test","token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1265,"meeting_id":303,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1266,"meeting_id":303,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1267,"meeting_id":303,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1268,"meeting_id":303,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1269,"meeting_id":303,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1270,"meeting_id":303,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1273,"meeting_id":303,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":308,"title":"Eveniet itaque obca","owner_id":94,"committee_id":3,"description":"In quia tenetur ut d","start_date":"2022-01-19 07:56:00","duration":60,"location":"Sit quis atque accu","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change attendance status to Going 2022-01-12 4:06 PM","current_member":{"id":1318,"meeting_id":308,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1317,"meeting_id":308,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1318,"meeting_id":308,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1307,"meeting_id":308,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1308,"meeting_id":308,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1309,"meeting_id":308,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1310,"meeting_id":308,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1311,"meeting_id":308,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1312,"meeting_id":308,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1313,"meeting_id":308,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1314,"meeting_id":308,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1315,"meeting_id":308,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1316,"meeting_id":308,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1319,"meeting_id":308,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// tweenty_three : [{"id":244,"title":"test7878","owner_id":21,"committee_id":3,"description":"trsr","start_date":"2022-01-20 14:36:00","duration":240,"location":"Muscat","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Maybe","last_activity":"saeed saleh change attendance status to Going 2022-01-03 8:55 PM","current_member":{"id":845,"meeting_id":244,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":844,"meeting_id":244,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":845,"meeting_id":244,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":834,"meeting_id":244,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":835,"meeting_id":244,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":846,"meeting_id":244,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":836,"meeting_id":244,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":837,"meeting_id":244,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":838,"meeting_id":244,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":839,"meeting_id":244,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":840,"meeting_id":244,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":841,"meeting_id":244,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":842,"meeting_id":244,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":843,"meeting_id":244,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":847,"meeting_id":244,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":304,"title":"Ahmed","owner_id":35,"committee_id":29,"description":"tret","start_date":"2022-01-20 17:46:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Pending","last_activity":"Mohammed Tarek change meeting status to Live 2022-01-12 10:27 PM","current_member":{"id":1274,"meeting_id":304,"user_id":21,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},"members":[{"id":1274,"meeting_id":304,"user_id":21,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1353,"meeting_id":304,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"token":"4670d18ae1781a39e16959c60d03d2e1","user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1277,"meeting_id":304,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1275,"meeting_id":304,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1276,"meeting_id":304,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// tweenty_four : [{"id":306,"title":"Vitae accusantium mi","owner_id":94,"committee_id":3,"description":"Elit illo in vitae","start_date":"2022-01-24 08:00:00","duration":60,"location":"Muscat","meeting_status_id":2,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"yaser samra change meeting status to Scheduled 2022-01-09 10:08 PM","current_member":{"id":1292,"meeting_id":306,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1291,"meeting_id":306,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1292,"meeting_id":306,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1281,"meeting_id":306,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1282,"meeting_id":306,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1283,"meeting_id":306,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1284,"meeting_id":306,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1285,"meeting_id":306,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1286,"meeting_id":306,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1287,"meeting_id":306,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1288,"meeting_id":306,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1289,"meeting_id":306,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1290,"meeting_id":306,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1293,"meeting_id":306,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1280,"meeting_id":306,"user_id":98,"user_email":null,"can_edit":1,"attendance_status":"Pending","status_reason":null,"token":"e433292457e0d470cf1d1af361e3c606","user":{"name":"yaser@moakt.cc","email":"yaser@moakt.cc","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"}]}]
/// tweenty_five : [{"id":291,"title":"Neque velit et quisq","owner_id":21,"committee_id":3,"description":"Aliquam reprehenderi","start_date":"2022-01-25 04:30:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"Ahmed Zaid change meeting status to Live 2022-01-10 9:39 AM","current_member":{"id":1188,"meeting_id":291,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1187,"meeting_id":291,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1188,"meeting_id":291,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1177,"meeting_id":291,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1178,"meeting_id":291,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1179,"meeting_id":291,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1180,"meeting_id":291,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1181,"meeting_id":291,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1182,"meeting_id":291,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1183,"meeting_id":291,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1184,"meeting_id":291,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1185,"meeting_id":291,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1186,"meeting_id":291,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1189,"meeting_id":291,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":292,"title":"Eveniet rerum nisi","owner_id":21,"committee_id":8,"description":"Magnam nihil atque c","start_date":"2022-01-25 03:15:00","duration":60,"location":"Sit deserunt et pra","meeting_status_id":2,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"yaser@moakt.cc Create talking point Agenda 2022-01-12 10:25 PM","current_member":{"id":1190,"meeting_id":292,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":"er","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1190,"meeting_id":292,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":"er","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1193,"meeting_id":292,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1191,"meeting_id":292,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1192,"meeting_id":292,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1194,"meeting_id":292,"user_id":98,"user_email":null,"can_edit":1,"attendance_status":"Pending","status_reason":null,"token":"f35114aaa329a6edbc979064aaa6e2b9","user":{"name":"yaser@moakt.cc","email":"yaser@moakt.cc","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"}]},{"id":294,"title":"Esse in facere ut n","owner_id":94,"committee_id":3,"description":"Voluptas ex providen","start_date":"2022-01-25 11:47:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Maybe","last_activity":"Ahmed Zaid change attendance status to Maybe 2022-01-11 8:11 PM","current_member":{"id":1207,"meeting_id":294,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":"ffffffff","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1206,"meeting_id":294,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1207,"meeting_id":294,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":"ffffffff","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1196,"meeting_id":294,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1197,"meeting_id":294,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1198,"meeting_id":294,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1199,"meeting_id":294,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1200,"meeting_id":294,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1201,"meeting_id":294,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1202,"meeting_id":294,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1203,"meeting_id":294,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1204,"meeting_id":294,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1205,"meeting_id":294,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1208,"meeting_id":294,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":297,"title":"Sit illo maiores nih","owner_id":94,"committee_id":3,"description":"Aliquip et sit ea c","start_date":"2022-01-25 13:15:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Pending","last_activity":"yaser samra change meeting status to Live 2022-01-09 2:06 PM","current_member":{"id":1233,"meeting_id":297,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1232,"meeting_id":297,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1233,"meeting_id":297,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1222,"meeting_id":297,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1223,"meeting_id":297,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1224,"meeting_id":297,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1225,"meeting_id":297,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1226,"meeting_id":297,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1227,"meeting_id":297,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1228,"meeting_id":297,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1229,"meeting_id":297,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1230,"meeting_id":297,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1231,"meeting_id":297,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1234,"meeting_id":297,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":298,"title":"Aut ea est minim ven","owner_id":94,"committee_id":3,"description":"Commodi dolor autem","start_date":"2022-01-25 12:06:00","duration":60,"location":"Quia ut esse saepe","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Going","last_activity":"Ahmed Zaid change attendance status to Going 2022-01-12 10:05 PM","current_member":{"id":1246,"meeting_id":298,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1245,"meeting_id":298,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1246,"meeting_id":298,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1235,"meeting_id":298,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1236,"meeting_id":298,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1237,"meeting_id":298,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1238,"meeting_id":298,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1239,"meeting_id":298,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1240,"meeting_id":298,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1241,"meeting_id":298,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1242,"meeting_id":298,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1243,"meeting_id":298,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1244,"meeting_id":298,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1247,"meeting_id":298,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":299,"title":"Natus ea consectetur","owner_id":94,"committee_id":3,"description":"Error quis consequat","start_date":"2022-01-25 14:30:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"zoom","attendance_status":"Pending","last_activity":"yaser samra change meeting status to Live 2022-01-09 2:09 PM","current_member":{"id":1259,"meeting_id":299,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1258,"meeting_id":299,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1259,"meeting_id":299,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1248,"meeting_id":299,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1249,"meeting_id":299,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1250,"meeting_id":299,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1251,"meeting_id":299,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1252,"meeting_id":299,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1253,"meeting_id":299,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1254,"meeting_id":299,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1255,"meeting_id":299,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1256,"meeting_id":299,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1257,"meeting_id":299,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1260,"meeting_id":299,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// tweenty_six : [{"id":317,"title":"Ijmeet Presentation01","owner_id":21,"committee_id":3,"description":"Test","start_date":"2022-01-14 10:15:00","duration":60,"location":null,"meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"zoom","attendance_status":"Pending","last_activity":"Mazin change attendance status to Going 2022-01-13 10:29 AM","current_member":{"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1382,"meeting_id":317,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1372,"meeting_id":317,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1373,"meeting_id":317,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1374,"meeting_id":317,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1375,"meeting_id":317,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1376,"meeting_id":317,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1377,"meeting_id":317,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1378,"meeting_id":317,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1379,"meeting_id":317,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1380,"meeting_id":317,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1381,"meeting_id":317,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1384,"meeting_id":317,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// tweenty_seven : [{"id":303,"title":"test88","owner_id":21,"committee_id":3,"description":"uig","start_date":"2022-01-19 17:42:00","duration":60,"location":"Muscat","meeting_status_id":5,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"Ahmed Zaid change meeting status to Archived 2022-01-12 10:04 PM","current_member":{"id":1272,"meeting_id":303,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1271,"meeting_id":303,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1272,"meeting_id":303,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1261,"meeting_id":303,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1262,"meeting_id":303,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Not going","status_reason":"test","token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1265,"meeting_id":303,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1266,"meeting_id":303,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1267,"meeting_id":303,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1268,"meeting_id":303,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1269,"meeting_id":303,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1270,"meeting_id":303,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1273,"meeting_id":303,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":308,"title":"Eveniet itaque obca","owner_id":94,"committee_id":3,"description":"In quia tenetur ut d","start_date":"2022-01-19 07:56:00","duration":60,"location":"Sit quis atque accu","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Ahmed Zaid change attendance status to Going 2022-01-12 4:06 PM","current_member":{"id":1318,"meeting_id":308,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1317,"meeting_id":308,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1318,"meeting_id":308,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1307,"meeting_id":308,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1308,"meeting_id":308,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1309,"meeting_id":308,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1310,"meeting_id":308,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1311,"meeting_id":308,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1312,"meeting_id":308,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1313,"meeting_id":308,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1314,"meeting_id":308,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1315,"meeting_id":308,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1316,"meeting_id":308,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1319,"meeting_id":308,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// tweenty_eight : [{"id":244,"title":"test7878","owner_id":21,"committee_id":3,"description":"trsr","start_date":"2022-01-20 14:36:00","duration":240,"location":"Muscat","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Maybe","last_activity":"saeed saleh change attendance status to Going 2022-01-03 8:55 PM","current_member":{"id":845,"meeting_id":244,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":844,"meeting_id":244,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":845,"meeting_id":244,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":834,"meeting_id":244,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":835,"meeting_id":244,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":846,"meeting_id":244,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":836,"meeting_id":244,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":837,"meeting_id":244,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":838,"meeting_id":244,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":839,"meeting_id":244,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":840,"meeting_id":244,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":841,"meeting_id":244,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":842,"meeting_id":244,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":843,"meeting_id":244,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":847,"meeting_id":244,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":304,"title":"Ahmed","owner_id":35,"committee_id":29,"description":"tret","start_date":"2022-01-20 17:46:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Pending","last_activity":"Mohammed Tarek change meeting status to Live 2022-01-12 10:27 PM","current_member":{"id":1274,"meeting_id":304,"user_id":21,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},"members":[{"id":1274,"meeting_id":304,"user_id":21,"user_email":"","can_edit":1,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1353,"meeting_id":304,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Going","status_reason":null,"token":"4670d18ae1781a39e16959c60d03d2e1","user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1277,"meeting_id":304,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1275,"meeting_id":304,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1276,"meeting_id":304,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// tweenty_nine : [{"id":306,"title":"Vitae accusantium mi","owner_id":94,"committee_id":3,"description":"Elit illo in vitae","start_date":"2022-01-24 08:00:00","duration":60,"location":"Muscat","meeting_status_id":2,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"yaser samra change meeting status to Scheduled 2022-01-09 10:08 PM","current_member":{"id":1292,"meeting_id":306,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1291,"meeting_id":306,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1292,"meeting_id":306,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1281,"meeting_id":306,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1282,"meeting_id":306,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1283,"meeting_id":306,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1284,"meeting_id":306,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1285,"meeting_id":306,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1286,"meeting_id":306,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1287,"meeting_id":306,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1288,"meeting_id":306,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1289,"meeting_id":306,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1290,"meeting_id":306,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1293,"meeting_id":306,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1280,"meeting_id":306,"user_id":98,"user_email":null,"can_edit":1,"attendance_status":"Pending","status_reason":null,"token":"e433292457e0d470cf1d1af361e3c606","user":{"name":"yaser@moakt.cc","email":"yaser@moakt.cc","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"}]}]
/// thirty : [{"id":291,"title":"Neque velit et quisq","owner_id":21,"committee_id":3,"description":"Aliquam reprehenderi","start_date":"2022-01-25 04:30:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"Ahmed Zaid change meeting status to Live 2022-01-10 9:39 AM","current_member":{"id":1188,"meeting_id":291,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1187,"meeting_id":291,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1188,"meeting_id":291,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1177,"meeting_id":291,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1178,"meeting_id":291,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1179,"meeting_id":291,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1180,"meeting_id":291,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1181,"meeting_id":291,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1182,"meeting_id":291,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1183,"meeting_id":291,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1184,"meeting_id":291,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1185,"meeting_id":291,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1186,"meeting_id":291,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1189,"meeting_id":291,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":292,"title":"Eveniet rerum nisi","owner_id":21,"committee_id":8,"description":"Magnam nihil atque c","start_date":"2022-01-25 03:15:00","duration":60,"location":"Sit deserunt et pra","meeting_status_id":2,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"yaser@moakt.cc Create talking point Agenda 2022-01-12 10:25 PM","current_member":{"id":1190,"meeting_id":292,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":"er","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1190,"meeting_id":292,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":"er","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1193,"meeting_id":292,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1191,"meeting_id":292,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1192,"meeting_id":292,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1194,"meeting_id":292,"user_id":98,"user_email":null,"can_edit":1,"attendance_status":"Pending","status_reason":null,"token":"f35114aaa329a6edbc979064aaa6e2b9","user":{"name":"yaser@moakt.cc","email":"yaser@moakt.cc","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"}]},{"id":294,"title":"Esse in facere ut n","owner_id":94,"committee_id":3,"description":"Voluptas ex providen","start_date":"2022-01-25 11:47:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Maybe","last_activity":"Ahmed Zaid change attendance status to Maybe 2022-01-11 8:11 PM","current_member":{"id":1207,"meeting_id":294,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":"ffffffff","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1206,"meeting_id":294,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1207,"meeting_id":294,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":"ffffffff","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1196,"meeting_id":294,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1197,"meeting_id":294,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1198,"meeting_id":294,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1199,"meeting_id":294,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1200,"meeting_id":294,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1201,"meeting_id":294,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1202,"meeting_id":294,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1203,"meeting_id":294,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1204,"meeting_id":294,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1205,"meeting_id":294,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1208,"meeting_id":294,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":297,"title":"Sit illo maiores nih","owner_id":94,"committee_id":3,"description":"Aliquip et sit ea c","start_date":"2022-01-25 13:15:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Pending","last_activity":"yaser samra change meeting status to Live 2022-01-09 2:06 PM","current_member":{"id":1233,"meeting_id":297,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1232,"meeting_id":297,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1233,"meeting_id":297,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1222,"meeting_id":297,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1223,"meeting_id":297,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1224,"meeting_id":297,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1225,"meeting_id":297,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1226,"meeting_id":297,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1227,"meeting_id":297,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1228,"meeting_id":297,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1229,"meeting_id":297,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1230,"meeting_id":297,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1231,"meeting_id":297,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1234,"meeting_id":297,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":298,"title":"Aut ea est minim ven","owner_id":94,"committee_id":3,"description":"Commodi dolor autem","start_date":"2022-01-25 12:06:00","duration":60,"location":"Quia ut esse saepe","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Going","last_activity":"Ahmed Zaid change attendance status to Going 2022-01-12 10:05 PM","current_member":{"id":1246,"meeting_id":298,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1245,"meeting_id":298,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1246,"meeting_id":298,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1235,"meeting_id":298,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1236,"meeting_id":298,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1237,"meeting_id":298,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1238,"meeting_id":298,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1239,"meeting_id":298,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1240,"meeting_id":298,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1241,"meeting_id":298,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1242,"meeting_id":298,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1243,"meeting_id":298,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1244,"meeting_id":298,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1247,"meeting_id":298,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":299,"title":"Natus ea consectetur","owner_id":94,"committee_id":3,"description":"Error quis consequat","start_date":"2022-01-25 14:30:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"zoom","attendance_status":"Pending","last_activity":"yaser samra change meeting status to Live 2022-01-09 2:09 PM","current_member":{"id":1259,"meeting_id":299,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1258,"meeting_id":299,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1259,"meeting_id":299,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1248,"meeting_id":299,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1249,"meeting_id":299,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1250,"meeting_id":299,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1251,"meeting_id":299,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1252,"meeting_id":299,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1253,"meeting_id":299,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1254,"meeting_id":299,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1255,"meeting_id":299,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1256,"meeting_id":299,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1257,"meeting_id":299,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1260,"meeting_id":299,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// thirty_one : [{"id":247,"title":"Enim aliquip qui off","owner_id":94,"committee_id":3,"description":"Rerum nostrum fugiat","start_date":"2022-01-31 02:12:00","duration":60,"location":"Muscat","meeting_status_id":5,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"Ahmed Zaid change meeting status to Archived 2022-01-03 11:47 AM","current_member":{"id":910,"meeting_id":247,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":910,"meeting_id":247,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":894,"meeting_id":247,"user_id":96,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"test yas","email":"test@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":270,"title":"Dolores enim neque d","owner_id":94,"committee_id":3,"description":"Qui omnis aut dolore","start_date":"2022-01-31 04:15:00","duration":60,"location":"Eligendi dolorem qui","meeting_status_id":2,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Going","last_activity":"Mazin change attendance status to Maybe 2022-01-13 3:48 PM","current_member":{"id":949,"meeting_id":270,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":"ssssssssssss","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":948,"meeting_id":270,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":949,"meeting_id":270,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":"ssssssssssss","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":946,"meeting_id":270,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1013,"meeting_id":270,"user_id":34,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":934,"meeting_id":270,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":947,"meeting_id":270,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":936,"meeting_id":270,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":288,"title":"YAS Atque et impedit co","owner_id":21,"committee_id":3,"description":"Quaerat illum recus","start_date":"2022-01-31 04:15:00","duration":60,"location":"Repudiandae unde fug","meeting_status_id":4,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"Ahmed Zaid change meeting status to Cancelled 2022-01-07 6:43 PM","current_member":{"id":1150,"meeting_id":288,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":"cef64c6acd7b4e994db8ad3a50ed8cec","user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1150,"meeting_id":288,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":"cef64c6acd7b4e994db8ad3a50ed8cec","user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1164,"meeting_id":288,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Pending","status_reason":null,"token":"911e3f8b42457d55ec2fc59e221bc1ec","user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1149,"meeting_id":288,"user_id":98,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":"98ad254463727a9a8afd6d5e3ef09b65","user":{"name":"yaser@moakt.cc","email":"yaser@moakt.cc","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":296,"title":"Deserunt tempor sed","owner_id":94,"committee_id":3,"description":"Eiusmod hic optio i","start_date":"2022-01-31 11:56:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"zoom","attendance_status":"Pending","last_activity":"yaser samra change meeting status to Live 2022-01-09 1:58 PM","current_member":{"id":1220,"meeting_id":296,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1219,"meeting_id":296,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1220,"meeting_id":296,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1209,"meeting_id":296,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1210,"meeting_id":296,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1211,"meeting_id":296,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1212,"meeting_id":296,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1213,"meeting_id":296,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1214,"meeting_id":296,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1215,"meeting_id":296,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1216,"meeting_id":296,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1217,"meeting_id":296,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1218,"meeting_id":296,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1221,"meeting_id":296,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":307,"title":"In esse pariatur Et","owner_id":94,"committee_id":3,"description":"Praesentium et moles","start_date":"2022-01-31 20:15:00","duration":270,"location":"Muscat","meeting_status_id":5,"virtual":0,"order":"TalkingPoints,Decisions,Actions","virtual_type":null,"attendance_status":"Pending","last_activity":"yaser samra change meeting status to Archived 2022-01-10 9:59 AM","current_member":{"id":1305,"meeting_id":307,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1304,"meeting_id":307,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1305,"meeting_id":307,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1294,"meeting_id":307,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1295,"meeting_id":307,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1296,"meeting_id":307,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1297,"meeting_id":307,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1298,"meeting_id":307,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1299,"meeting_id":307,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1300,"meeting_id":307,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1301,"meeting_id":307,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1302,"meeting_id":307,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1303,"meeting_id":307,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1306,"meeting_id":307,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":311,"title":"Ad adipisci tenetur","owner_id":21,"committee_id":3,"description":"Impedit quia molest","start_date":"2022-01-31 20:15:00","duration":60,"location":"Muscat","meeting_status_id":5,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Maybe","last_activity":"Ahmed Zaid change meeting status to Archived 2022-01-12 4:20 PM","current_member":{"id":1348,"meeting_id":311,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1347,"meeting_id":311,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1348,"meeting_id":311,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1337,"meeting_id":311,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1338,"meeting_id":311,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1339,"meeting_id":311,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1340,"meeting_id":311,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1341,"meeting_id":311,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1342,"meeting_id":311,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1343,"meeting_id":311,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1344,"meeting_id":311,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1345,"meeting_id":311,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1346,"meeting_id":311,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1349,"meeting_id":311,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]},{"id":319,"title":"Corporis doloremque","owner_id":94,"committee_id":3,"description":"Dolore quae aspernat","start_date":"2022-01-31 14:15:00","duration":60,"location":"Muscat","meeting_status_id":3,"virtual":1,"order":"TalkingPoints,Decisions,Actions","virtual_type":"ijmeet","attendance_status":"Pending","last_activity":"yaser samra change meeting status to Live 2022-01-13 3:24 PM","current_member":{"id":1396,"meeting_id":319,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":1395,"meeting_id":319,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1396,"meeting_id":319,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1386,"meeting_id":319,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1397,"meeting_id":319,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1387,"meeting_id":319,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1388,"meeting_id":319,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1389,"meeting_id":319,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1390,"meeting_id":319,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1391,"meeting_id":319,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1392,"meeting_id":319,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1393,"meeting_id":319,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1394,"meeting_id":319,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1398,"meeting_id":319,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]

class CalenderResponseModel {
  List<One> _one;
  List<Two> _two;
  List<Three> _three;
  List<Four> _four;
  List<Five> _five;
  List<Sex> _sex;
  List<Seven> _seven;
  List<Eight> _eight;
  List<Nine> _nine;
  List<Ten> _ten;
  List<Eleven> _eleven;
  List<Tweleve> _tweleve;
  List<Thirteen> _thirteen;
  List<Fourteen> _fourteen;
  List<Fifteen> _fifteen;
  List<Sixteen> _sixteen;
  List<Seventeen> _seventeen;
  List<Eighteen> _eighteen;
  List<Nineteen> _nineteen;
  List<Tweenty> _tweenty;
  List<Tweenty_one> _tweentyOne;
  List<Tweenty_two> _tweentyTwo;
  List<Tweenty_three> _tweentyThree;
  List<Tweenty_four> _tweentyFour;
  List<Tweenty_five> _tweentyFive;
  List<Tweenty_six> _tweentySix;
  List<Tweenty_seven> _tweentySeven;
  List<Tweenty_eight> _tweentyEight;
  List<Tweenty_nine> _tweentyNine;
  List<Thirty> _thirty;
  List<Thirty_one> _thirtyOne;

  List<One> get one => _one;
  List<Two> get two => _two;
  List<Three> get three => _three;
  List<Four> get four => _four;
  List<Five> get five => _five;
  List<Sex> get sex => _sex;
  List<Seven> get seven => _seven;
  List<Eight> get eight => _eight;
  List<Nine> get nine => _nine;
  List<Ten> get ten => _ten;
  List<Eleven> get eleven => _eleven;
  List<Tweleve> get tweleve => _tweleve;
  List<Thirteen> get thirteen => _thirteen;
  List<Fourteen> get fourteen => _fourteen;
  List<Fifteen> get fifteen => _fifteen;
  List<Sixteen> get sixteen => _sixteen;
  List<Seventeen> get seventeen => _seventeen;
  List<Eighteen> get eighteen => _eighteen;
  List<Nineteen> get nineteen => _nineteen;
  List<Tweenty> get tweenty => _tweenty;
  List<Tweenty_one> get tweentyOne => _tweentyOne;
  List<Tweenty_two> get tweentyTwo => _tweentyTwo;
  List<Tweenty_three> get tweentyThree => _tweentyThree;
  List<Tweenty_four> get tweentyFour => _tweentyFour;
  List<Tweenty_five> get tweentyFive => _tweentyFive;
  List<Tweenty_six> get tweentySix => _tweentySix;
  List<Tweenty_seven> get tweentySeven => _tweentySeven;
  List<Tweenty_eight> get tweentyEight => _tweentyEight;
  List<Tweenty_nine> get tweentyNine => _tweentyNine;
  List<Thirty> get thirty => _thirty;
  List<Thirty_one> get thirtyOne => _thirtyOne;

  CalenderResponseModel({
      List<One> one, 
      List<Two> two, 
      List<Three> three, 
      List<Four> four, 
      List<Five> five, 
      List<Sex> sex, 
      List<Seven> seven, 
      List<Eight> eight, 
      List<Nine> nine, 
      List<Ten> ten, 
      List<Eleven> eleven, 
      List<Tweleve> tweleve, 
      List<Thirteen> thirteen, 
      List<Fourteen> fourteen, 
      List<Fifteen> fifteen, 
      List<Sixteen> sixteen, 
      List<Seventeen> seventeen, 
      List<Eighteen> eighteen, 
      List<Nineteen> nineteen, 
      List<Tweenty> tweenty, 
      List<Tweenty_one> tweentyOne, 
      List<Tweenty_two> tweentyTwo, 
      List<Tweenty_three> tweentyThree, 
      List<Tweenty_four> tweentyFour, 
      List<Tweenty_five> tweentyFive, 
      List<Tweenty_six> tweentySix, 
      List<Tweenty_seven> tweentySeven, 
      List<Tweenty_eight> tweentyEight, 
      List<Tweenty_nine> tweentyNine, 
      List<Thirty> thirty, 
      List<Thirty_one> thirtyOne}){
    _one = one;
    _two = two;
    _three = three;
    _four = four;
    _five = five;
    _sex = sex;
    _seven = seven;
    _eight = eight;
    _nine = nine;
    _ten = ten;
    _eleven = eleven;
    _tweleve = tweleve;
    _thirteen = thirteen;
    _fourteen = fourteen;
    _fifteen = fifteen;
    _sixteen = sixteen;
    _seventeen = seventeen;
    _eighteen = eighteen;
    _nineteen = nineteen;
    _tweenty = tweenty;
    _tweentyOne = tweentyOne;
    _tweentyTwo = tweentyTwo;
    _tweentyThree = tweentyThree;
    _tweentyFour = tweentyFour;
    _tweentyFive = tweentyFive;
    _tweentySix = tweentySix;
    _tweentySeven = tweentySeven;
    _tweentyEight = tweentyEight;
    _tweentyNine = tweentyNine;
    _thirty = thirty;
    _thirtyOne = thirtyOne;
}

  CalenderResponseModel.fromJson(dynamic json) {
    if (json['01'] != null) {
      _one = [];
      json['01'].forEach((v) {
        _one.add(One.fromJson(v));
      });
    }
    if (json['02'] != null) {
      _two = [];
      json['02'].forEach((v) {
        _two.add(Two.fromJson(v));
      });
    }
    if (json['03'] != null) {
      _three = [];
      json['03'].forEach((v) {
        _three.add(Three.fromJson(v));
      });
    }
    if (json['04'] != null) {
      _four = [];
      json['04'].forEach((v) {
        _four.add(Four.fromJson(v));
      });
    }
    if (json['05'] != null) {
      _five = [];
      json['05'].forEach((v) {
        _five.add(Five.fromJson(v));
      });
    }
    if (json['06'] != null) {
      _sex = [];
      json['06'].forEach((v) {
        _sex.add(Sex.fromJson(v));
      });
    }
    if (json['07'] != null) {
      _seven = [];
      json['07'].forEach((v) {
        _seven.add(Seven.fromJson(v));
      });
    }
    if (json['08'] != null) {
      _eight = [];
      json['08'].forEach((v) {
        _eight.add(Eight.fromJson(v));
      });
    }
    if (json['09'] != null) {
      _nine = [];
      json['09'].forEach((v) {
        _nine.add(Nine.fromJson(v));
      });
    }
    if (json['10'] != null) {
      _ten = [];
      json['10'].forEach((v) {
        _ten.add(Ten.fromJson(v));
      });
    }
    if (json['11'] != null) {
      _eleven = [];
      json['11'].forEach((v) {
        _eleven.add(Eleven.fromJson(v));
      });
    }
    if (json['12'] != null) {
      _tweleve = [];
      json['12'].forEach((v) {
        _tweleve.add(Tweleve.fromJson(v));
      });
    }
    if (json['13'] != null) {
      _thirteen = [];
      json['13'].forEach((v) {
        _thirteen.add(Thirteen.fromJson(v));
      });
    }
    if (json['14'] != null) {
      _fourteen = [];
      json['14'].forEach((v) {
        _fourteen.add(Fourteen.fromJson(v));
      });
    }
    if (json['15'] != null) {
      _fifteen = [];
      json['15'].forEach((v) {
        _fifteen.add(Fifteen.fromJson(v));
      });
    }
    if (json['16'] != null) {
      _sixteen = [];
      json['16'].forEach((v) {
        _sixteen.add(Sixteen.fromJson(v));
      });
    }
    if (json['17'] != null) {
      _seventeen = [];
      json['17'].forEach((v) {
        _seventeen.add(Seventeen.fromJson(v));
      });
    }
    if (json['18'] != null) {
      _eighteen = [];
      json['18'].forEach((v) {
        _eighteen.add(Eighteen.fromJson(v));
      });
    }
    if (json['19'] != null) {
      _nineteen = [];
      json['19'].forEach((v) {
        _nineteen.add(Nineteen.fromJson(v));
      });
    }
    if (json['20'] != null) {
      _tweenty = [];
      json['20'].forEach((v) {
        _tweenty.add(Tweenty.fromJson(v));
      });
    }
    if (json['21'] != null) {
      _tweentyOne = [];
      json['21'].forEach((v) {
        _tweentyOne.add(Tweenty_one.fromJson(v));
      });
    }
    if (json['22'] != null) {
      _tweentyTwo = [];
      json['22'].forEach((v) {
        _tweentyTwo.add(Tweenty_two.fromJson(v));
      });
    }
    if (json['23'] != null) {
      _tweentyThree = [];
      json['23'].forEach((v) {
        _tweentyThree.add(Tweenty_three.fromJson(v));
      });
    }
    if (json['24'] != null) {
      _tweentyFour = [];
      json['24'].forEach((v) {
        _tweentyFour.add(Tweenty_four.fromJson(v));
      });
    }
    if (json['25'] != null) {
      _tweentyFive = [];
      json['25'].forEach((v) {
        _tweentyFive.add(Tweenty_five.fromJson(v));
      });
    }
    if (json['26'] != null) {
      _tweentySix = [];
      json['26'].forEach((v) {
        _tweentySix.add(Tweenty_six.fromJson(v));
      });
    }
    if (json['27'] != null) {
      _tweentySeven = [];
      json['27'].forEach((v) {
        _tweentySeven.add(Tweenty_seven.fromJson(v));
      });
    }
    if (json['28'] != null) {
      _tweentyEight = [];
      json['28'].forEach((v) {
        _tweentyEight.add(Tweenty_eight.fromJson(v));
      });
    }
    if (json['29'] != null) {
      _tweentyNine = [];
      json['29'].forEach((v) {
        _tweentyNine.add(Tweenty_nine.fromJson(v));
      });
    }
    if (json['30'] != null) {
      _thirty = [];
      json['30'].forEach((v) {
        _thirty.add(Thirty.fromJson(v));
      });
    }
    if (json['31'] != null) {
      _thirtyOne = [];
      json['31'].forEach((v) {
        _thirtyOne.add(Thirty_one.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    if (_one != null) {
      map['01'] = _one.map((v) => v.toJson()).toList();
    }
    if (_two != null) {
      map['02'] = _two.map((v) => v.toJson()).toList();
    }
    if (_three != null) {
      map['03'] = _three.map((v) => v.toJson()).toList();
    }
    if (_four != null) {
      map['04'] = _four.map((v) => v.toJson()).toList();
    }
    if (_five != null) {
      map['05'] = _five.map((v) => v.toJson()).toList();
    }
    if (_sex != null) {
      map['06'] = _sex.map((v) => v.toJson()).toList();
    }
    if (_seven != null) {
      map['07'] = _seven.map((v) => v.toJson()).toList();
    }
    if (_eight != null) {
      map['08'] = _eight.map((v) => v.toJson()).toList();
    }
    if (_nine != null) {
      map['09'] = _nine.map((v) => v.toJson()).toList();
    }
    if (_ten != null) {
      map['10'] = _ten.map((v) => v.toJson()).toList();
    }
    if (_eleven != null) {
      map['11'] = _eleven.map((v) => v.toJson()).toList();
    }
    if (_tweleve != null) {
      map['12'] = _tweleve.map((v) => v.toJson()).toList();
    }
    if (_thirteen != null) {
      map['13'] = _thirteen.map((v) => v.toJson()).toList();
    }
    if (_fourteen != null) {
      map['14'] = _fourteen.map((v) => v.toJson()).toList();
    }
    if (_fifteen != null) {
      map['15'] = _fifteen.map((v) => v.toJson()).toList();
    }
    if (_sixteen != null) {
      map['16'] = _sixteen.map((v) => v.toJson()).toList();
    }
    if (_seventeen != null) {
      map['17'] = _seventeen.map((v) => v.toJson()).toList();
    }
    if (_eighteen != null) {
      map['18'] = _eighteen.map((v) => v.toJson()).toList();
    }
    if (_nineteen != null) {
      map['19'] = _nineteen.map((v) => v.toJson()).toList();
    }
    if (_tweenty != null) {
      map['20'] = _tweenty.map((v) => v.toJson()).toList();
    }
    if (_tweentyOne != null) {
      map['21'] = _tweentyOne.map((v) => v.toJson()).toList();
    }
    if (_tweentyTwo != null) {
      map['22'] = _tweentyTwo.map((v) => v.toJson()).toList();
    }
    if (_tweentyThree != null) {
      map['23'] = _tweentyThree.map((v) => v.toJson()).toList();
    }
    if (_tweentyFour != null) {
      map['24'] = _tweentyFour.map((v) => v.toJson()).toList();
    }
    if (_tweentyFive != null) {
      map['25'] = _tweentyFive.map((v) => v.toJson()).toList();
    }
    if (_tweentySix != null) {
      map['26'] = _tweentySix.map((v) => v.toJson()).toList();
    }
    if (_tweentySeven != null) {
      map['27'] = _tweentySeven.map((v) => v.toJson()).toList();
    }
    if (_tweentyEight != null) {
      map['28'] = _tweentyEight.map((v) => v.toJson()).toList();
    }
    if (_tweentyNine != null) {
      map['29'] = _tweentyNine.map((v) => v.toJson()).toList();
    }
    if (_thirty != null) {
      map['30'] = _thirty.map((v) => v.toJson()).toList();
    }
    if (_thirtyOne != null) {
      map['31'] = _thirtyOne.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 247
/// title : "Enim aliquip qui off"
/// owner_id : 94
/// committee_id : 3
/// description : "Rerum nostrum fugiat"
/// start_date : "2022-01-31 02:12:00"
/// duration : 60
/// location : "Muscat"
/// meeting_status_id : 5
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Pending"
/// last_activity : "Ahmed Zaid change meeting status to Archived 2022-01-03 11:47 AM"
/// current_member : {"id":910,"meeting_id":247,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":910,"meeting_id":247,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":894,"meeting_id":247,"user_id":96,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"test yas","email":"test@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Thirty_one {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Thirty_one({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Thirty_one.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 910
/// meeting_id : 247
/// user_id : 21
/// user_email : null
/// can_edit : 0
/// attendance_status : "Pending"
/// status_reason : null
/// token : null
/// user : {"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null}
/// type : "Viewer"

class MembersCalender {
  int _id;
  int _meetingId;
  int _userId;
  dynamic _userEmail;
  int _canEdit;
  String _attendanceStatus;
  dynamic _statusReason;
  dynamic _token;
  User _user;
  String _type;

  int get id => _id;
  int get meetingId => _meetingId;
  int get userId => _userId;
  dynamic get userEmail => _userEmail;
  int get canEdit => _canEdit;
  String get attendanceStatus => _attendanceStatus;
  dynamic get statusReason => _statusReason;
  dynamic get token => _token;
  User get user => _user;
  String get type => _type;

  MembersCalender({
      int id, 
      int meetingId, 
      int userId, 
      dynamic userEmail, 
      int canEdit, 
      String attendanceStatus, 
      dynamic statusReason, 
      dynamic token, 
      User user, 
      String type}){
    _id = id;
    _meetingId = meetingId;
    _userId = userId;
    _userEmail = userEmail;
    _canEdit = canEdit;
    _attendanceStatus = attendanceStatus;
    _statusReason = statusReason;
    _token = token;
    _user = user;
    _type = type;
}

  MembersCalender.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _userId = json['user_id'];
    _userEmail = json['user_email'];
    _canEdit = json['can_edit'];
    _attendanceStatus = json['attendance_status'];
    _statusReason = json['status_reason'];
    _token = json['token'];
    _user = json['user'] != null ? User.fromJson(json['user']) : null;
    _type = json['type'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['user_id'] = _userId;
    map['user_email'] = _userEmail;
    map['can_edit'] = _canEdit;
    map['attendance_status'] = _attendanceStatus;
    map['status_reason'] = _statusReason;
    map['token'] = _token;
    if (_user != null) {
      map['user'] = _user.toJson();
    }
    map['type'] = _type;
    return map;
  }

}

/// name : "Ahmed Zaid"
/// email : "ahmed@ijtimaati.com"
/// image : "http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg"
/// position : "Security"
/// team_name : ""
/// role_name : ""
/// committee : null
/// role : null

class User {
  String _name;
  String _email;
  String _image;
  String _position;
  String _teamName;
  String _roleName;
  dynamic _committee;
  dynamic _role;

  String get name => _name;
  String get email => _email;
  String get image => _image;
  String get position => _position;
  String get teamName => _teamName;
  String get roleName => _roleName;
  dynamic get committee => _committee;
  dynamic get role => _role;

  User({
      String name, 
      String email, 
      String image, 
      String position, 
      String teamName, 
      String roleName, 
      dynamic committee, 
      dynamic role}){
    _name = name;
    _email = email;
    _image = image;
    _position = position;
    _teamName = teamName;
    _roleName = roleName;
    _committee = committee;
    _role = role;
}

  User.fromJson(dynamic json) {
    _name = json['name'];
    _email = json['email'];
    _image = json['image'];
    _position = json['position'];
    _teamName = json['team_name'];
    _roleName = json['role_name'];
    _committee = json['committee'];
    _role = json['role'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['name'] = _name;
    map['email'] = _email;
    map['image'] = _image;
    map['position'] = _position;
    map['team_name'] = _teamName;
    map['role_name'] = _roleName;
    map['committee'] = _committee;
    map['role'] = _role;
    return map;
  }

}

/// id : 910
/// meeting_id : 247
/// user_id : 21
/// user_email : null
/// can_edit : 0
/// attendance_status : "Pending"
/// status_reason : null
/// token : null
/// user : {"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null}
/// type : "Viewer"

class Current_member {
  int _id;
  int _meetingId;
  int _userId;
  dynamic _userEmail;
  int _canEdit;
  String _attendanceStatus;
  dynamic _statusReason;
  dynamic _token;
  User _user;
  String _type;

  int get id => _id;
  int get meetingId => _meetingId;
  int get userId => _userId;
  dynamic get userEmail => _userEmail;
  int get canEdit => _canEdit;
  String get attendanceStatus => _attendanceStatus;
  dynamic get statusReason => _statusReason;
  dynamic get token => _token;
  User get user => _user;
  String get type => _type;

  Current_member({
      int id, 
      int meetingId, 
      int userId, 
      dynamic userEmail, 
      int canEdit, 
      String attendanceStatus, 
      dynamic statusReason, 
      dynamic token, 
      User user, 
      String type}){
    _id = id;
    _meetingId = meetingId;
    _userId = userId;
    _userEmail = userEmail;
    _canEdit = canEdit;
    _attendanceStatus = attendanceStatus;
    _statusReason = statusReason;
    _token = token;
    _user = user;
    _type = type;
}

  Current_member.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _userId = json['user_id'];
    _userEmail = json['user_email'];
    _canEdit = json['can_edit'];
    _attendanceStatus = json['attendance_status'];
    _statusReason = json['status_reason'];
    _token = json['token'];
    _user = json['user'] != null ? User.fromJson(json['user']) : null;
    _type = json['type'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['user_id'] = _userId;
    map['user_email'] = _userEmail;
    map['can_edit'] = _canEdit;
    map['attendance_status'] = _attendanceStatus;
    map['status_reason'] = _statusReason;
    map['token'] = _token;
    if (_user != null) {
      map['user'] = _user.toJson();
    }
    map['type'] = _type;
    return map;
  }

}


/// id : 291
/// title : "Neque velit et quisq"
/// owner_id : 21
/// committee_id : 3
/// description : "Aliquam reprehenderi"
/// start_date : "2022-01-25 04:30:00"
/// duration : 60
/// location : "Muscat"
/// meeting_status_id : 3
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Pending"
/// last_activity : "Ahmed Zaid change meeting status to Live 2022-01-10 9:39 AM"
/// current_member : {"id":1188,"meeting_id":291,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":1187,"meeting_id":291,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1188,"meeting_id":291,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1177,"meeting_id":291,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1178,"meeting_id":291,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1179,"meeting_id":291,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1180,"meeting_id":291,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1181,"meeting_id":291,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1182,"meeting_id":291,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1183,"meeting_id":291,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1184,"meeting_id":291,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1185,"meeting_id":291,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1186,"meeting_id":291,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1189,"meeting_id":291,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Thirty {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Thirty({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Thirty.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}



/// id : 306
/// title : "Vitae accusantium mi"
/// owner_id : 94
/// committee_id : 3
/// description : "Elit illo in vitae"
/// start_date : "2022-01-24 08:00:00"
/// duration : 60
/// location : "Muscat"
/// meeting_status_id : 2
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Pending"
/// last_activity : "yaser samra change meeting status to Scheduled 2022-01-09 10:08 PM"
/// current_member : {"id":1292,"meeting_id":306,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":1291,"meeting_id":306,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1292,"meeting_id":306,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1281,"meeting_id":306,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1282,"meeting_id":306,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1283,"meeting_id":306,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1284,"meeting_id":306,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1285,"meeting_id":306,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1286,"meeting_id":306,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1287,"meeting_id":306,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1288,"meeting_id":306,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1289,"meeting_id":306,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1290,"meeting_id":306,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1293,"meeting_id":306,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1280,"meeting_id":306,"user_id":98,"user_email":null,"can_edit":1,"attendance_status":"Pending","status_reason":null,"token":"e433292457e0d470cf1d1af361e3c606","user":{"name":"yaser@moakt.cc","email":"yaser@moakt.cc","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"}]

class Tweenty_nine {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Tweenty_nine({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Tweenty_nine.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 244
/// title : "test7878"
/// owner_id : 21
/// committee_id : 3
/// description : "trsr"
/// start_date : "2022-01-20 14:36:00"
/// duration : 240
/// location : "Muscat"
/// meeting_status_id : 3
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Maybe"
/// last_activity : "saeed saleh change attendance status to Going 2022-01-03 8:55 PM"
/// current_member : {"id":845,"meeting_id":244,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":844,"meeting_id":244,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":845,"meeting_id":244,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":834,"meeting_id":244,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":835,"meeting_id":244,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":846,"meeting_id":244,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":836,"meeting_id":244,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":837,"meeting_id":244,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":838,"meeting_id":244,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":839,"meeting_id":244,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":840,"meeting_id":244,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":841,"meeting_id":244,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":842,"meeting_id":244,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":843,"meeting_id":244,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":847,"meeting_id":244,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Tweenty_eight {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Tweenty_eight({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Tweenty_eight.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}



/// id : 303
/// title : "test88"
/// owner_id : 21
/// committee_id : 3
/// description : "uig"
/// start_date : "2022-01-19 17:42:00"
/// duration : 60
/// location : "Muscat"
/// meeting_status_id : 5
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Pending"
/// last_activity : "Ahmed Zaid change meeting status to Archived 2022-01-12 10:04 PM"
/// current_member : {"id":1272,"meeting_id":303,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":1271,"meeting_id":303,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1272,"meeting_id":303,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1261,"meeting_id":303,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1262,"meeting_id":303,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Not going","status_reason":"test","token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1265,"meeting_id":303,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1266,"meeting_id":303,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1267,"meeting_id":303,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1268,"meeting_id":303,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1269,"meeting_id":303,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1270,"meeting_id":303,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1273,"meeting_id":303,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Tweenty_seven {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Tweenty_seven({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Tweenty_seven.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 317
/// title : "Ijmeet Presentation01"
/// owner_id : 21
/// committee_id : 3
/// description : "Test"
/// start_date : "2022-01-14 10:15:00"
/// duration : 60
/// location : null
/// meeting_status_id : 3
/// virtual : 1
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : "zoom"
/// attendance_status : "Pending"
/// last_activity : "Mazin change attendance status to Going 2022-01-13 10:29 AM"
/// current_member : {"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":1382,"meeting_id":317,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1372,"meeting_id":317,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1373,"meeting_id":317,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1374,"meeting_id":317,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1375,"meeting_id":317,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1376,"meeting_id":317,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1377,"meeting_id":317,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1378,"meeting_id":317,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1379,"meeting_id":317,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1380,"meeting_id":317,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1381,"meeting_id":317,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1384,"meeting_id":317,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Tweenty_six {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  dynamic _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  String _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  dynamic get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  String get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Tweenty_six({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      dynamic location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      String virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Tweenty_six.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 291
/// title : "Neque velit et quisq"
/// owner_id : 21
/// committee_id : 3
/// description : "Aliquam reprehenderi"
/// start_date : "2022-01-25 04:30:00"
/// duration : 60
/// location : "Muscat"
/// meeting_status_id : 3
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Pending"
/// last_activity : "Ahmed Zaid change meeting status to Live 2022-01-10 9:39 AM"
/// current_member : {"id":1188,"meeting_id":291,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":1187,"meeting_id":291,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1188,"meeting_id":291,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1177,"meeting_id":291,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1178,"meeting_id":291,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1179,"meeting_id":291,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1180,"meeting_id":291,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1181,"meeting_id":291,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1182,"meeting_id":291,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1183,"meeting_id":291,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1184,"meeting_id":291,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1185,"meeting_id":291,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1186,"meeting_id":291,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1189,"meeting_id":291,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Tweenty_five {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Tweenty_five({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Tweenty_five.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}



/// id : 306
/// title : "Vitae accusantium mi"
/// owner_id : 94
/// committee_id : 3
/// description : "Elit illo in vitae"
/// start_date : "2022-01-24 08:00:00"
/// duration : 60
/// location : "Muscat"
/// meeting_status_id : 2
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Pending"
/// last_activity : "yaser samra change meeting status to Scheduled 2022-01-09 10:08 PM"
/// current_member : {"id":1292,"meeting_id":306,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":1291,"meeting_id":306,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1292,"meeting_id":306,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1281,"meeting_id":306,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1282,"meeting_id":306,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1283,"meeting_id":306,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1284,"meeting_id":306,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1285,"meeting_id":306,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1286,"meeting_id":306,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1287,"meeting_id":306,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1288,"meeting_id":306,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1289,"meeting_id":306,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1290,"meeting_id":306,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1293,"meeting_id":306,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1280,"meeting_id":306,"user_id":98,"user_email":null,"can_edit":1,"attendance_status":"Pending","status_reason":null,"token":"e433292457e0d470cf1d1af361e3c606","user":{"name":"yaser@moakt.cc","email":"yaser@moakt.cc","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"}]

class Tweenty_four {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Tweenty_four({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Tweenty_four.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}



/// id : 244
/// title : "test7878"
/// owner_id : 21
/// committee_id : 3
/// description : "trsr"
/// start_date : "2022-01-20 14:36:00"
/// duration : 240
/// location : "Muscat"
/// meeting_status_id : 3
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Maybe"
/// last_activity : "saeed saleh change attendance status to Going 2022-01-03 8:55 PM"
/// current_member : {"id":845,"meeting_id":244,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":844,"meeting_id":244,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":845,"meeting_id":244,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":834,"meeting_id":244,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":835,"meeting_id":244,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":846,"meeting_id":244,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":836,"meeting_id":244,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":837,"meeting_id":244,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":838,"meeting_id":244,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":839,"meeting_id":244,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":840,"meeting_id":244,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":841,"meeting_id":244,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":842,"meeting_id":244,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":843,"meeting_id":244,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":847,"meeting_id":244,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Tweenty_three {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Tweenty_three({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Tweenty_three.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 303
/// title : "test88"
/// owner_id : 21
/// committee_id : 3
/// description : "uig"
/// start_date : "2022-01-19 17:42:00"
/// duration : 60
/// location : "Muscat"
/// meeting_status_id : 5
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Pending"
/// last_activity : "Ahmed Zaid change meeting status to Archived 2022-01-12 10:04 PM"
/// current_member : {"id":1272,"meeting_id":303,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":1271,"meeting_id":303,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1272,"meeting_id":303,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1261,"meeting_id":303,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1262,"meeting_id":303,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Not going","status_reason":"test","token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1265,"meeting_id":303,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1266,"meeting_id":303,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1267,"meeting_id":303,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1268,"meeting_id":303,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1269,"meeting_id":303,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1270,"meeting_id":303,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1273,"meeting_id":303,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Tweenty_two {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Tweenty_two({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Tweenty_two.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 317
/// title : "Ijmeet Presentation01"
/// owner_id : 21
/// committee_id : 3
/// description : "Test"
/// start_date : "2022-01-14 10:15:00"
/// duration : 60
/// location : null
/// meeting_status_id : 3
/// virtual : 1
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : "zoom"
/// attendance_status : "Pending"
/// last_activity : "Mazin change attendance status to Going 2022-01-13 10:29 AM"
/// current_member : {"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":1382,"meeting_id":317,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1372,"meeting_id":317,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1373,"meeting_id":317,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1374,"meeting_id":317,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1375,"meeting_id":317,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1376,"meeting_id":317,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1377,"meeting_id":317,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1378,"meeting_id":317,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1379,"meeting_id":317,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1380,"meeting_id":317,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1381,"meeting_id":317,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1384,"meeting_id":317,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Tweenty_one {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  dynamic _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  String _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  dynamic get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  String get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Tweenty_one({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      dynamic location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      String virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Tweenty_one.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}



/// id : 244
/// title : "test7878"
/// owner_id : 21
/// committee_id : 3
/// description : "trsr"
/// start_date : "2022-01-20 14:36:00"
/// duration : 240
/// location : "Muscat"
/// meeting_status_id : 3
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Maybe"
/// last_activity : "saeed saleh change attendance status to Going 2022-01-03 8:55 PM"
/// current_member : {"id":845,"meeting_id":244,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":844,"meeting_id":244,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":845,"meeting_id":244,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":834,"meeting_id":244,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":835,"meeting_id":244,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":846,"meeting_id":244,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":836,"meeting_id":244,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":837,"meeting_id":244,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":838,"meeting_id":244,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":839,"meeting_id":244,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":840,"meeting_id":244,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":841,"meeting_id":244,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":842,"meeting_id":244,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":843,"meeting_id":244,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":847,"meeting_id":244,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Tweenty {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Tweenty({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Tweenty.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}



/// id : 303
/// title : "test88"
/// owner_id : 21
/// committee_id : 3
/// description : "uig"
/// start_date : "2022-01-19 17:42:00"
/// duration : 60
/// location : "Muscat"
/// meeting_status_id : 5
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Pending"
/// last_activity : "Ahmed Zaid change meeting status to Archived 2022-01-12 10:04 PM"
/// current_member : {"id":1272,"meeting_id":303,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":1271,"meeting_id":303,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1272,"meeting_id":303,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1261,"meeting_id":303,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1262,"meeting_id":303,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Not going","status_reason":"test","token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1265,"meeting_id":303,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1266,"meeting_id":303,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1267,"meeting_id":303,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1268,"meeting_id":303,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1269,"meeting_id":303,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1270,"meeting_id":303,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1273,"meeting_id":303,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Nineteen {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Nineteen({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Nineteen.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 317
/// title : "Ijmeet Presentation01"
/// owner_id : 21
/// committee_id : 3
/// description : "Test"
/// start_date : "2022-01-14 10:15:00"
/// duration : 60
/// location : null
/// meeting_status_id : 3
/// virtual : 1
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : "zoom"
/// attendance_status : "Pending"
/// last_activity : "Mazin change attendance status to Going 2022-01-13 10:29 AM"
/// current_member : {"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":1382,"meeting_id":317,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1372,"meeting_id":317,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1373,"meeting_id":317,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1374,"meeting_id":317,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1375,"meeting_id":317,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1376,"meeting_id":317,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1377,"meeting_id":317,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1378,"meeting_id":317,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1379,"meeting_id":317,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1380,"meeting_id":317,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1381,"meeting_id":317,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1384,"meeting_id":317,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Eighteen {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  dynamic _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  String _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  dynamic get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  String get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Eighteen({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      dynamic location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      String virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Eighteen.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 310
/// title : "test"
/// owner_id : 35
/// committee_id : 8
/// description : ""
/// start_date : "2022-01-13 14:15:00"
/// duration : 60
/// location : "Muscat"
/// meeting_status_id : 1
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Pending"
/// last_activity : "Ahmed Zaid Update this meeting 2022-01-12 3:59 PM"
/// current_member : {"id":1333,"meeting_id":310,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":1333,"meeting_id":310,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1350,"meeting_id":310,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Pending","status_reason":null,"token":"99604848945202b2143d5fdcccab0177","user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1334,"meeting_id":310,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1335,"meeting_id":310,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Seventeen {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Seventeen({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Seventeen.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 118
/// title : "Molestiae voluptates"
/// owner_id : 21
/// committee_id : 3
/// description : "Qui at delectus lau"
/// start_date : "2022-01-01 01:41:00"
/// duration : 60
/// location : "Et magna similique e"
/// meeting_status_id : 5
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Going"
/// last_activity : "Ahmed Zaid change meeting status to Archived 2021-12-27 9:38 AM"
/// current_member : {"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":575,"meeting_id":118,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":565,"meeting_id":118,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":566,"meeting_id":118,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":577,"meeting_id":118,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":567,"meeting_id":118,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":568,"meeting_id":118,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":569,"meeting_id":118,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":570,"meeting_id":118,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":571,"meeting_id":118,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":572,"meeting_id":118,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":573,"meeting_id":118,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":574,"meeting_id":118,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Sixteen {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Sixteen({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Sixteen.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}



/// id : 211
/// title : "TEST Recusandae Qui veni"
/// owner_id : 21
/// committee_id : 3
/// description : "Explicabo Sunt sequ"
/// start_date : "2022-01-11 04:12:00"
/// duration : 180
/// location : "Esse elit quia bla"
/// meeting_status_id : 4
/// virtual : 1
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Going"
/// last_activity : "Ahmed Zaid change meeting status to Cancelled 2021-12-27 9:06 AM"
/// current_member : {"id":550,"meeting_id":211,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":549,"meeting_id":211,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":550,"meeting_id":211,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":539,"meeting_id":211,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":540,"meeting_id":211,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":551,"meeting_id":211,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":541,"meeting_id":211,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":542,"meeting_id":211,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":543,"meeting_id":211,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":544,"meeting_id":211,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":545,"meeting_id":211,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":546,"meeting_id":211,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":547,"meeting_id":211,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":548,"meeting_id":211,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Fifteen {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Fifteen({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Fifteen.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}



/// id : 317
/// title : "Ijmeet Presentation01"
/// owner_id : 21
/// committee_id : 3
/// description : "Test"
/// start_date : "2022-01-14 10:15:00"
/// duration : 60
/// location : null
/// meeting_status_id : 3
/// virtual : 1
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : "zoom"
/// attendance_status : "Pending"
/// last_activity : "Mazin change attendance status to Going 2022-01-13 10:29 AM"
/// current_member : {"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":1382,"meeting_id":317,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1383,"meeting_id":317,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1372,"meeting_id":317,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1373,"meeting_id":317,"user_id":35,"user_email":"","can_edit":1,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1374,"meeting_id":317,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1375,"meeting_id":317,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1376,"meeting_id":317,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1377,"meeting_id":317,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1378,"meeting_id":317,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1379,"meeting_id":317,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1380,"meeting_id":317,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1381,"meeting_id":317,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1384,"meeting_id":317,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Fourteen {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  dynamic _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  String _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  dynamic get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  String get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Fourteen({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      dynamic location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      String virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Fourteen.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}



/// id : 310
/// title : "test"
/// owner_id : 35
/// committee_id : 8
/// description : ""
/// start_date : "2022-01-13 14:15:00"
/// duration : 60
/// location : "Muscat"
/// meeting_status_id : 1
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Pending"
/// last_activity : "Ahmed Zaid Update this meeting 2022-01-12 3:59 PM"
/// current_member : {"id":1333,"meeting_id":310,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":1333,"meeting_id":310,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1350,"meeting_id":310,"user_id":34,"user_email":null,"can_edit":1,"attendance_status":"Pending","status_reason":null,"token":"99604848945202b2143d5fdcccab0177","user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Editor"},{"id":1334,"meeting_id":310,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1335,"meeting_id":310,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Thirteen {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Thirteen({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Thirteen.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 118
/// title : "Molestiae voluptates"
/// owner_id : 21
/// committee_id : 3
/// description : "Qui at delectus lau"
/// start_date : "2022-01-01 01:41:00"
/// duration : 60
/// location : "Et magna similique e"
/// meeting_status_id : 5
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Going"
/// last_activity : "Ahmed Zaid change meeting status to Archived 2021-12-27 9:38 AM"
/// current_member : {"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":575,"meeting_id":118,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":565,"meeting_id":118,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":566,"meeting_id":118,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":577,"meeting_id":118,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":567,"meeting_id":118,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":568,"meeting_id":118,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":569,"meeting_id":118,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":570,"meeting_id":118,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":571,"meeting_id":118,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":572,"meeting_id":118,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":573,"meeting_id":118,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":574,"meeting_id":118,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Tweleve {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Tweleve({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Tweleve.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 211
/// title : "TEST Recusandae Qui veni"
/// owner_id : 21
/// committee_id : 3
/// description : "Explicabo Sunt sequ"
/// start_date : "2022-01-11 04:12:00"
/// duration : 180
/// location : "Esse elit quia bla"
/// meeting_status_id : 4
/// virtual : 1
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Going"
/// last_activity : "Ahmed Zaid change meeting status to Cancelled 2021-12-27 9:06 AM"
/// current_member : {"id":550,"meeting_id":211,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":549,"meeting_id":211,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":550,"meeting_id":211,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":539,"meeting_id":211,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":540,"meeting_id":211,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":551,"meeting_id":211,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":541,"meeting_id":211,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":542,"meeting_id":211,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":543,"meeting_id":211,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":544,"meeting_id":211,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":545,"meeting_id":211,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":546,"meeting_id":211,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":547,"meeting_id":211,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":548,"meeting_id":211,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Eleven {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Eleven({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Eleven.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 118
/// title : "Molestiae voluptates"
/// owner_id : 21
/// committee_id : 3
/// description : "Qui at delectus lau"
/// start_date : "2022-01-01 01:41:00"
/// duration : 60
/// location : "Et magna similique e"
/// meeting_status_id : 5
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Going"
/// last_activity : "Ahmed Zaid change meeting status to Archived 2021-12-27 9:38 AM"
/// current_member : {"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":575,"meeting_id":118,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":565,"meeting_id":118,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":566,"meeting_id":118,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":577,"meeting_id":118,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":567,"meeting_id":118,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":568,"meeting_id":118,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":569,"meeting_id":118,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":570,"meeting_id":118,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":571,"meeting_id":118,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":572,"meeting_id":118,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":573,"meeting_id":118,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":574,"meeting_id":118,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Ten {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Ten({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Ten.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}



/// id : 118
/// title : "Molestiae voluptates"
/// owner_id : 21
/// committee_id : 3
/// description : "Qui at delectus lau"
/// start_date : "2022-01-01 01:41:00"
/// duration : 60
/// location : "Et magna similique e"
/// meeting_status_id : 5
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Going"
/// last_activity : "Ahmed Zaid change meeting status to Archived 2021-12-27 9:38 AM"
/// current_member : {"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":575,"meeting_id":118,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":565,"meeting_id":118,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":566,"meeting_id":118,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":577,"meeting_id":118,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":567,"meeting_id":118,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":568,"meeting_id":118,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":569,"meeting_id":118,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":570,"meeting_id":118,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":571,"meeting_id":118,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":572,"meeting_id":118,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":573,"meeting_id":118,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":574,"meeting_id":118,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Nine {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Nine({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Nine.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 275
/// title : "Meeting four"
/// owner_id : 34
/// committee_id : 29
/// description : ""
/// start_date : "2022-01-08 21:06:00"
/// duration : 60
/// location : "Muscat"
/// meeting_status_id : 4
/// virtual : 1
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : "ijmeet"
/// attendance_status : "Going"
/// last_activity : "Mohammed Tarek change meeting status to Cancelled 2022-01-12 10:15 PM"
/// current_member : {"id":1015,"meeting_id":275,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":"ddgdgfdgdf","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":1015,"meeting_id":275,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":"ddgdgfdgdf","token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":1014,"meeting_id":275,"user_id":34,"user_email":null,"can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Mohammed Tarek","email":"mohammed94.turki@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Rk3WxvTHHf.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Eight {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  String _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  String get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Eight({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      String virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Eight.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 237
/// title : "Nostrud nulla volupt"
/// owner_id : 94
/// committee_id : 3
/// description : "Soluta rem dignissim"
/// start_date : "2022-01-07 23:15:00"
/// duration : 60
/// location : "Muscat"
/// meeting_status_id : 5
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Pending"
/// last_activity : "yaser samra change meeting status to Archived 2021-12-31 1:00 AM"
/// current_member : {"id":753,"meeting_id":237,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":752,"meeting_id":237,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":753,"meeting_id":237,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":742,"meeting_id":237,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":743,"meeting_id":237,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":754,"meeting_id":237,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":744,"meeting_id":237,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":745,"meeting_id":237,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":746,"meeting_id":237,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":747,"meeting_id":237,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":748,"meeting_id":237,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":749,"meeting_id":237,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":750,"meeting_id":237,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":751,"meeting_id":237,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":755,"meeting_id":237,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Seven {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Seven({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Seven.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}



/// id : 161
/// title : "Next month meeting"
/// owner_id : 21
/// committee_id : 3
/// description : "Next month meeting"
/// start_date : "2022-01-06 19:37:00"
/// duration : 60
/// location : "cairo"
/// meeting_status_id : 5
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Pending"
/// last_activity : "Ahmed Zaid change meeting status to Archived 2021-12-27 9:31 AM"
/// current_member : {"id":563,"meeting_id":161,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":562,"meeting_id":161,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":563,"meeting_id":161,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":552,"meeting_id":161,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":553,"meeting_id":161,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":564,"meeting_id":161,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":554,"meeting_id":161,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":555,"meeting_id":161,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":556,"meeting_id":161,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":557,"meeting_id":161,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":558,"meeting_id":161,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":559,"meeting_id":161,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":560,"meeting_id":161,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":561,"meeting_id":161,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Sex {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Sex({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Sex.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}



/// id : 120
/// title : "IJMEET Non eos quis ea iure"
/// owner_id : 21
/// committee_id : 3
/// description : "Aliquip corporis ea  Non eos quis ea iure"
/// start_date : "2022-01-05 14:49:00"
/// duration : 60
/// location : "Mollitia adipisci au"
/// meeting_status_id : 5
/// virtual : 1
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Maybe"
/// last_activity : "Ahmed Zaid change meeting status to Archived 2022-01-04 6:15 AM"
/// current_member : {"id":965,"meeting_id":120,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":951,"meeting_id":120,"user_id":1,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"test@test2.ijtimaati.local","image":"http://test.app.ijtimaati.com/api/public/uploads/images/FaNlH2ba4c.html","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":964,"meeting_id":120,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":965,"meeting_id":120,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Maybe","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":953,"meeting_id":120,"user_id":22,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com2","image":"http://test.app.ijtimaati.com/api/public/uploads/images/bxXwm4A9Sb.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":954,"meeting_id":120,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":955,"meeting_id":120,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":956,"meeting_id":120,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":957,"meeting_id":120,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":958,"meeting_id":120,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":959,"meeting_id":120,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":960,"meeting_id":120,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":961,"meeting_id":120,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":952,"meeting_id":120,"user_id":64,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"jojonavocy","email":"bupypo@mailinator.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":962,"meeting_id":120,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":963,"meeting_id":120,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":876,"meeting_id":120,"user_id":94,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"yaser samra","email":"yaser2@tmpbox.net","image":"http://test.app.ijtimaati.com/api/public/uploads/images/baCRizZygW.png","position":"test","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Five {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Five({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Five.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 213
/// title : "TEST Neque nihil consequa"
/// owner_id : 21
/// committee_id : 3
/// description : "Eaque ex quasi excep"
/// start_date : "2022-01-04 05:15:00"
/// duration : 60
/// location : "Libero quidem esse"
/// meeting_status_id : 5
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Pending"
/// last_activity : "Ahmed Zaid change meeting status to Archived 2021-12-27 9:01 AM"
/// current_member : {"id":537,"meeting_id":213,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":536,"meeting_id":213,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":537,"meeting_id":213,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":526,"meeting_id":213,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":527,"meeting_id":213,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":538,"meeting_id":213,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":528,"meeting_id":213,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":529,"meeting_id":213,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":530,"meeting_id":213,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":531,"meeting_id":213,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":532,"meeting_id":213,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":533,"meeting_id":213,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":534,"meeting_id":213,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":535,"meeting_id":213,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Four {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Four({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Four.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 242
/// title : "2022"
/// owner_id : 35
/// committee_id : 27
/// description : ""
/// start_date : "2022-01-03 09:00:00"
/// duration : 60
/// location : "Muscat"
/// meeting_status_id : 5
/// virtual : 1
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : "ijmeet"
/// attendance_status : "Pending"
/// last_activity : "Mazin change meeting status to Archived 2022-01-09 9:05 PM"
/// current_member : {"id":818,"meeting_id":242,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":818,"meeting_id":242,"user_id":21,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":819,"meeting_id":242,"user_id":37,"user_email":null,"can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Three {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  String _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  String get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Three({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      String virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Three.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 118
/// title : "Molestiae voluptates"
/// owner_id : 21
/// committee_id : 3
/// description : "Qui at delectus lau"
/// start_date : "2022-01-01 01:41:00"
/// duration : 60
/// location : "Et magna similique e"
/// meeting_status_id : 5
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Going"
/// last_activity : "Ahmed Zaid change meeting status to Archived 2021-12-27 9:38 AM"
/// current_member : {"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":575,"meeting_id":118,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":565,"meeting_id":118,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":566,"meeting_id":118,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":577,"meeting_id":118,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":567,"meeting_id":118,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":568,"meeting_id":118,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":569,"meeting_id":118,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":570,"meeting_id":118,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":571,"meeting_id":118,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":572,"meeting_id":118,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":573,"meeting_id":118,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":574,"meeting_id":118,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Two {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  Two({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Two.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


/// id : 118
/// title : "Molestiae voluptates"
/// owner_id : 21
/// committee_id : 3
/// description : "Qui at delectus lau"
/// start_date : "2022-01-01 01:41:00"
/// duration : 60
/// location : "Et magna similique e"
/// meeting_status_id : 5
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// virtual_type : null
/// attendance_status : "Going"
/// last_activity : "Ahmed Zaid change meeting status to Archived 2021-12-27 9:38 AM"
/// current_member : {"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":575,"meeting_id":118,"user_id":3,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"saeed saleh","email":"said.sale7@gmail.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/oNBWLjycUr.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":576,"meeting_id":118,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"token":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/CxVN8FGmpl.jpg","position":"Security","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":565,"meeting_id":118,"user_id":31,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Maryam AL Rasbi","email":"Maryam@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":566,"meeting_id":118,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mazin","email":"Mazin@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/Vcb3WznMGA.jpg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":577,"meeting_id":118,"user_id":36,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":null,"type":"Viewer"},{"id":567,"meeting_id":118,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":568,"meeting_id":118,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":569,"meeting_id":118,"user_id":45,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Mr. Abdulaziz","email":"abdulaziz@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/uploads/images/jdNrfSL35P.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":570,"meeting_id":118,"user_id":57,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Salah Al Ghailani","email":"salah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":571,"meeting_id":118,"user_id":60,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Rayah Al Rasbi","email":"rayah@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":572,"meeting_id":118,"user_id":61,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Al Reem","email":"alreem@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":573,"meeting_id":118,"user_id":71,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Abeer","email":"abeer@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":574,"meeting_id":118,"user_id":75,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"token":null,"user":{"name":"Zainab Al- Ajmi","email":"zainab@ijtimaati.com","image":"http://test.app.ijtimaati.com/api/public/avatar.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class One {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  String _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  dynamic _virtualType;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<MembersCalender> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  String get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  dynamic get virtualType => _virtualType;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<MembersCalender> get members => _members;

  One({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      String location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      dynamic virtualType, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<MembersCalender> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _virtualType = virtualType;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  One.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _virtualType = json['virtual_type'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(MembersCalender.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['virtual_type'] = _virtualType;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}


