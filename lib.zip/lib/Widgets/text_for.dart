import 'package:flutter/material.dart';
import 'package:itimaaty/View/FontsStyle.dart';


Widget customText ({ String  text, Color color,double size }) => 
    Text(text,style: blueColorStyleMediumWithColor(18, color),);